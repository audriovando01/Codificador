import sqlite3
import openpyxl
import os

# ============================================================
# CONFIGURACIÓN
# ============================================================

ARCHIVO_EXCEL = r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN\REVISION DE CODIFICACION\HISTORICO CODIFICACION.xlsx"

HOJA_HISTORICA = "BASE HISTORICA"

# La base de datos está en la misma carpeta que este programa
ARCHIVO_BD = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "base_datos.db"
)

# ============================================================
# VERIFICAR ARCHIVO
# ============================================================

if not os.path.exists(ARCHIVO_EXCEL):
    print("ERROR: No se encontró el archivo Excel.")
    print(ARCHIVO_EXCEL)
    input("\nPresiona ENTER para salir...")
    exit()

# ============================================================
# ABRIR EXCEL
# ============================================================

print("Abriendo archivo Excel...")

libro = openpyxl.load_workbook(
    ARCHIVO_EXCEL,
    read_only=True,
    data_only=True
)

if HOJA_HISTORICA not in libro.sheetnames:
    print(f"ERROR: No existe la hoja '{HOJA_HISTORICA}'.")
    print("Hojas encontradas:", libro.sheetnames)
    input("\nPresiona ENTER para salir...")
    exit()

hoja = libro[HOJA_HISTORICA]

# ============================================================
# LOCALIZAR COLUMNA CODIGOS
# ============================================================

fila_encabezados = next(hoja.iter_rows(min_row=1, max_row=1, values_only=True))

columna_codigos = None

for posicion, encabezado in enumerate(fila_encabezados, start=1):
    if encabezado is not None:
        if str(encabezado).strip().upper() == "CODIGOS":
            columna_codigos = posicion
            break

if columna_codigos is None:
    print("ERROR: No se encontró la columna 'Codigos'.")
    input("\nPresiona ENTER para salir...")
    exit()

print(f"Columna 'Codigos' encontrada: {columna_codigos}")

# ============================================================
# CONECTAR CON BASE DE DATOS
# ============================================================

conexion = sqlite3.connect(ARCHIVO_BD)
cursor = conexion.cursor()

# ============================================================
# CARGAR CÓDIGOS
# ============================================================

total_leidos = 0
total_insertados = 0
total_existentes = 0
total_vacios = 0

for fila in hoja.iter_rows(
    min_row=2,
    min_col=columna_codigos,
    max_col=columna_codigos,
    values_only=True
):

    codigo = fila[0]

    if codigo is None:
        total_vacios += 1
        continue

    codigo = str(codigo).strip()

    if not codigo:
        total_vacios += 1
        continue

    total_leidos += 1

    # IMPORTANTE:
    # El código se guarda como texto para conservar
    # los ceros a la izquierda.

    cursor.execute(
        """
        INSERT OR IGNORE INTO articulos_historico
        (codigo, grupo, subgrupo, descripcion, usuario, um, mes)
        VALUES (?, NULL, NULL, NULL, NULL, NULL, 'HISTORICO')
        """,
        (codigo,)
    )

    if cursor.rowcount == 1:
        total_insertados += 1
    else:
        total_existentes += 1

# ============================================================
# GUARDAR
# ============================================================

conexion.commit()

# ============================================================
# RESULTADOS
# ============================================================

print("\n========================================")
print("       CARGA HISTÓRICO COMPLETADA")
print("========================================")
print(f"Códigos leídos:       {total_leidos}")
print(f"Códigos insertados:   {total_insertados}")
print(f"Códigos ya existentes:{total_existentes}")
print(f"Celdas vacías:        {total_vacios}")
print("========================================")

# Verificación final
cursor.execute(
    "SELECT COUNT(*) FROM articulos_historico"
)

total_bd = cursor.fetchone()[0]

print(f"\nTotal de registros en la base: {total_bd}")

conexion.close()
libro.close()

input("\nPresiona ENTER para salir...")