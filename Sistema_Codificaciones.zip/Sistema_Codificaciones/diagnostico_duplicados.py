import os
import re
import glob
import unicodedata
from difflib import SequenceMatcher
from collections import defaultdict

import pandas as pd

# ============================================================
# CONFIGURACION
# ============================================================

BASE_REVISION = r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN\REVISION DE CODIFICACION"

# Umbrales deliberadamente conservadores para reducir falsos positivos.
UMBRAL_MISMO_GRUPO_SUBGRUPO = 0.90

PALABRAS_POCO_INFORMATIVAS = {
    "DE",
    "DEL",
    "LA",
    "LAS",
    "EL",
    "LOS",
    "PARA",
    "CON",
    "SIN",
    "TIPO",
    "MODELO",
    "MARCA",
    "NO",
    "NUMERO",
    "NUM",
    "Y",
}

# ============================================================
# UTILIDADES
# ============================================================


def quitar_acentos(texto):
    texto = "" if pd.isna(texto) else str(texto)
    return "".join(
        c
        for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )


def normalizar_codigo(valor):
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    return texto


def normalizar_clave(valor):
    """Normaliza grupo/subgrupo sin destruir ceros iniciales si ya existen."""
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    return texto


def normalizar_descripcion(texto):
    texto = quitar_acentos(texto).upper()

    # Unificar variantes frecuentes.
    reemplazos = {
        " PULGADAS ": ' " ',
        " PULGADA ": ' " ',
        " PULG ": ' " ',
        " INCH ": ' " ',
        " SCH ": " CEDULA ",
        " CED ": " CEDULA ",
        " ACERO AL CARBONO ": " ACERO AL CARBON ",
    }

    texto = f" {texto} "
    for origen, destino in reemplazos.items():
        texto = texto.replace(origen, destino)

    # Mantener letras, números y símbolos técnicos relevantes.
    texto = re.sub(r"[^A-Z0-9/#.%+\-\" ]+", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()

    return texto


def tokens_informativos(texto_normalizado):
    tokens = re.findall(
        r'[A-Z0-9]+(?:/[A-Z0-9]+)?|(?:\d+(?:\.\d+)?)|["#%]', texto_normalizado
    )
    return [t for t in tokens if t not in PALABRAS_POCO_INFORMATIVAS and len(t) > 1]


def firma_numerica(texto_normalizado):
    """
    Extrae números para evitar comparar como duplicados artículos muy parecidos
    pero con medidas/capacidades diferentes.
    """
    numeros = re.findall(r"\d+(?:\.\d+)?(?:/\d+)?", texto_normalizado)
    return tuple(numeros)


def jaccard_tokens(a, b):
    sa = set(tokens_informativos(a))
    sb = set(tokens_informativos(b))

    if not sa and not sb:
        return 1.0
    if not sa or not sb:
        return 0.0

    return len(sa & sb) / len(sa | sb)


def similitud_secuencia(a, b):
    return SequenceMatcher(None, a, b).ratio()


def similitud_total(a, b):
    """
    Combina similitud de secuencia y coincidencia de palabras.
    Da mayor peso a la estructura completa.
    """
    sec = similitud_secuencia(a, b)
    jac = jaccard_tokens(a, b)
    return 0.65 * sec + 0.35 * jac


def numeros_compatibles(a, b):
    """
    Si ambas descripciones contienen números, exige coincidencia fuerte.
    Esto evita marcar, por ejemplo, una válvula de 1" como duplicado de una de 2".
    """
    na = firma_numerica(a)
    nb = firma_numerica(b)

    if not na or not nb:
        return True

    return na == nb


def extraer_atributo(texto_normalizado, nombres):
    """
    Extrae el valor que aparece después de una etiqueta como TALLA o COLOR.
    Ejemplos:
      TALLA M
      TALL L
      COLOR AZUL MARINO

    El valor se corta al encontrar coma implícita normalizada, otra etiqueta
    conocida o después de un máximo razonable de palabras.
    """
    etiquetas_fin = {
        "TALLA",
        "TALL",
        "COLOR",
        "MARCA",
        "MODELO",
        "MATERIAL",
        "TIPO",
        "MEDIDA",
        "TAMANO",
        "TAMAÑO",
        "GENERO",
        "SEXO",
        "PRESENTACION",
        "CAPACIDAD",
    }

    palabras = texto_normalizado.split()

    for i, palabra in enumerate(palabras):
        if palabra in nombres:
            valores = []

            for siguiente in palabras[i + 1 : i + 5]:
                if siguiente in etiquetas_fin:
                    break
                valores.append(siguiente)

            if valores:
                return " ".join(valores).strip()

    return ""


def atributos_variantes_compatibles(a, b):
    """
    TALLA y COLOR son atributos que distinguen artículos.
    Si ambos artículos especifican el atributo y los valores son distintos,
    NO pueden considerarse duplicados.
    """
    talla_a = extraer_atributo(a, {"TALLA", "TALL"})
    talla_b = extraer_atributo(b, {"TALLA", "TALL"})

    if talla_a and talla_b and talla_a != talla_b:
        return False

    color_a = extraer_atributo(a, {"COLOR"})
    color_b = extraer_atributo(b, {"COLOR"})

    if color_a and color_b and color_a != color_b:
        return False

    return True


def buscar_archivo_resultado():
    patron = os.path.join(BASE_REVISION, "RESULTADO_*.xlsx")
    archivos = glob.glob(patron)

    if not archivos:
        raise FileNotFoundError(
            f"No se encontro ningun archivo RESULTADO_*.xlsx en:\n{BASE_REVISION}"
        )

    # Evitar tomar un diagnóstico como entrada, por seguridad.
    archivos = [
        a for a in archivos if "DIAGNOSTICO_" not in os.path.basename(a).upper()
    ]

    if not archivos:
        raise FileNotFoundError("No se encontro un RESULTADO_*.xlsx valido.")

    return max(archivos, key=os.path.getmtime)


def nombre_salida(archivo_entrada):
    base = os.path.basename(archivo_entrada)
    periodo = os.path.splitext(base)[0].replace("RESULTADO_", "")
    return os.path.join(BASE_REVISION, f"DIAGNOSTICO_DUPLICADOS_{periodo}.xlsx")


# ============================================================
# DETECCION
# ============================================================


def detectar_duplicados(df):
    df = df.copy()

    # Detectar columnas tolerando acentos y mayúsculas.
    mapa = {}
    for col in df.columns:
        clave = quitar_acentos(col).upper().strip()
        mapa[clave] = col

    requeridas = ["CODIGO", "ESTADO", "GRUPO", "SUBGRUPO", "DESCRIPCION"]
    faltantes = [c for c in requeridas if c not in mapa]

    if faltantes:
        raise ValueError(
            "Faltan columnas requeridas en el archivo: " + ", ".join(faltantes)
        )

    c_codigo = mapa["CODIGO"]
    c_estado = mapa["ESTADO"]
    c_grupo = mapa["GRUPO"]
    c_subgrupo = mapa["SUBGRUPO"]
    c_desc = mapa["DESCRIPCION"]

    nuevos = df[df[c_estado].astype(str).str.strip().str.upper().eq("NUEVO")].copy()

    nuevos["_codigo"] = nuevos[c_codigo].apply(normalizar_codigo)
    nuevos["_grupo"] = nuevos[c_grupo].apply(normalizar_clave)
    nuevos["_subgrupo"] = nuevos[c_subgrupo].apply(normalizar_clave)
    nuevos["_desc_norm"] = nuevos[c_desc].apply(normalizar_descripcion)

    # Preparar grupos de comparación.
    por_grupo_subgrupo = defaultdict(list)

    for idx, fila in nuevos.iterrows():
        por_grupo_subgrupo[(fila["_grupo"], fila["_subgrupo"])].append(idx)

    candidatos = []

    # -------------------------------
    # 1) Mismo grupo + mismo subgrupo
    # -------------------------------
    for clave, indices in por_grupo_subgrupo.items():
        for i_pos in range(len(indices)):
            for j_pos in range(i_pos + 1, len(indices)):
                i = indices[i_pos]
                j = indices[j_pos]
                a = nuevos.at[i, "_desc_norm"]
                b = nuevos.at[j, "_desc_norm"]

                if not a or not b:
                    continue

                exacto = a == b
                score = 1.0 if exacto else similitud_total(a, b)

                if not exacto:
                    if score < UMBRAL_MISMO_GRUPO_SUBGRUPO:
                        continue
                    if not numeros_compatibles(a, b):
                        continue

                # TALLA y COLOR distintos convierten los artículos en variantes,
                # no en duplicados, aunque el resto de la descripción coincida.
                if not atributos_variantes_compatibles(a, b):
                    continue

                candidatos.append(
                    {
                        "idx_a": i,
                        "idx_b": j,
                        "tipo": "MISMO GRUPO Y SUBGRUPO",
                        "similitud": score,
                        "exacto": exacto,
                    }
                )

    # Para cada artículo, conservar la mejor coincidencia.
    mejor_por_idx = {}

    for cand in candidatos:
        i = cand["idx_a"]
        j = cand["idx_b"]

        for origen, otro in [(i, j), (j, i)]:
            actual = mejor_por_idx.get(origen)
            if actual is None or cand["similitud"] > actual["similitud"]:
                mejor_por_idx[origen] = {
                    **cand,
                    "otro_idx": otro,
                }

    filas_salida = []

    for idx, fila in nuevos.iterrows():
        mejor = mejor_por_idx.get(idx)

        if mejor is None:
            filas_salida.append(
                {
                    "Codigo": fila["_codigo"],
                    "Grupo": fila["_grupo"],
                    "Subgrupo": fila["_subgrupo"],
                    "Descripción": fila[c_desc],
                    "Observación propuesta": "OK",
                    "Subobservación propuesta": "OK",
                    "Código duplicado": "",
                    "Descripción duplicada": "",
                    "Tipo de coincidencia": "",
                    "Similitud %": "",
                    "Detalle": "",
                }
            )
            continue

        otro = nuevos.loc[mejor["otro_idx"]]
        porcentaje = round(mejor["similitud"] * 100, 1)

        if mejor["exacto"]:
            detalle = "Descripción normalizada idéntica a otro artículo NUEVO del mismo Grupo/Subgrupo."
        else:
            detalle = "Descripción muy similar a otro artículo NUEVO del mismo Grupo/Subgrupo."

        filas_salida.append(
            {
                "Codigo": fila["_codigo"],
                "Grupo": fila["_grupo"],
                "Subgrupo": fila["_subgrupo"],
                "Descripción": fila[c_desc],
                "Observación propuesta": "DUPLICADO",
                "Subobservación propuesta": "ARTICULO DUPLICADO",
                "Código duplicado": otro["_codigo"],
                "Descripción duplicada": otro[c_desc],
                "Tipo de coincidencia": mejor["tipo"],
                "Similitud %": porcentaje,
                "Detalle": detalle,
            }
        )

    resultado = pd.DataFrame(filas_salida)

    # Hoja separada solo con casos detectados.
    duplicados = resultado[resultado["Observación propuesta"].eq("DUPLICADO")].copy()

    return resultado, duplicados, len(nuevos), len(candidatos)


# ============================================================
# MAIN
# ============================================================


def main():
    print("=" * 72)
    print("DIAGNOSTICO DE DUPLICADOS - SOLO ARTICULOS DEL MES")
    print("=" * 72)

    entrada = buscar_archivo_resultado()
    salida = nombre_salida(entrada)

    print(f"Entrada: {entrada}")
    print()
    print("Criterio:")
    print("- Solo se comparan articulos con Estado = NUEVO.")
    print("- NO se comparan contra articulos historicos.")
    print("- Solo se comparan artículos del mismo Grupo + mismo Subgrupo.")
    print("- Si el Subgrupo es diferente, NO entra en el análisis de DUPLICADOS.")
    print("- TALLA o COLOR diferentes se consideran variantes, NO duplicados.")
    print()

    df = pd.read_excel(entrada, dtype=str, engine="openpyxl")

    resultado, duplicados, total_nuevos, total_pares = detectar_duplicados(df)

    resumen = pd.DataFrame(
        [
            ["Articulos NUEVO analizados", total_nuevos],
            ["Articulos marcados como DUPLICADO", len(duplicados)],
            ["Articulos sin duplicado fuerte", total_nuevos - len(duplicados)],
            ["Pares candidatos detectados", total_pares],
            [
                "Umbral mismo Grupo/Subgrupo",
                f"{UMBRAL_MISMO_GRUPO_SUBGRUPO * 100:.0f}%",
            ],
        ],
        columns=["Concepto", "Resultado"],
    )

    with pd.ExcelWriter(salida, engine="openpyxl") as writer:
        resumen.to_excel(writer, sheet_name="RESUMEN", index=False)
        duplicados.to_excel(writer, sheet_name="DUPLICADOS", index=False)
        resultado.to_excel(writer, sheet_name="DIAGNOSTICO", index=False)

        # Ajustes visuales básicos.
        for hoja in writer.book.worksheets:
            hoja.freeze_panes = "A2"
            hoja.auto_filter.ref = hoja.dimensions

            for columna in hoja.columns:
                letra = columna[0].column_letter
                max_len = 0

                for celda in columna:
                    valor = "" if celda.value is None else str(celda.value)
                    max_len = max(max_len, min(len(valor), 80))

                hoja.column_dimensions[letra].width = max(12, min(max_len + 2, 60))

    print("Diagnostico terminado correctamente.")
    print("-" * 72)
    print(f"Articulos NUEVO analizados:         {total_nuevos}")
    print(f"Articulos marcados DUPLICADO:       {len(duplicados)}")
    print(f"Sin duplicado fuerte:               {total_nuevos - len(duplicados)}")
    print(f"Pares candidatos detectados:        {total_pares}")
    print()
    print("Archivo generado:")
    print(salida)
    print("=" * 72)


if __name__ == "__main__":
    main()
