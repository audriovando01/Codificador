import sqlite3
import pandas as pd
import re
import unicodedata
from pathlib import Path

# ============================================================
# CONFIGURACION
# ============================================================

BASE_PROYECTO = Path(r"C:\Users\aovandon\Documents\Sistema_Codificaciones")
DB_PATH = BASE_PROYECTO / "base_datos.db"

# Coloca los 8 archivos en esta carpeta.
CARPETA_HISTORICOS = BASE_PROYECTO / "historicos_revision"

ARCHIVOS = {
    "ENERO": "01 Revisión Articulos Almacen.xlsx",
    "FEBRERO": "02 Revisión Articulos Almacen.xlsx",
    "MARZO": "03 Revisión Articulos Almacen.xlsx",
    "ABRIL": "04 Revisión Articulos Almacen Abril.xlsx",
    "MAYO": "Articulos Almacen Mayo 2026.xlsx",
    "JUNIO": "Codificación Junio.xlsx",
    "JULIO": "Codificación Julio.xlsx",
    "AGOSTO": "Codificación Agosto_Observaciones IA.xlsx",
}

ANIO = 2026


# ============================================================
# UTILIDADES
# ============================================================


def quitar_acentos(texto):
    texto = "" if pd.isna(texto) else str(texto)
    return "".join(
        c
        for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )


def normalizar_encabezado(texto):
    texto = quitar_acentos(texto).strip().lower()
    texto = re.sub(r"\s+", " ", texto)
    return texto


def limpiar_texto(valor):
    if pd.isna(valor):
        return ""
    return str(valor).strip()


def limpiar_codigo(valor):
    if pd.isna(valor):
        return ""

    # Excel puede devolver algunos números como 101117.0.
    if isinstance(valor, float) and valor.is_integer():
        valor = int(valor)

    texto = str(valor).strip()

    if texto.endswith(".0") and texto[:-2].isdigit():
        texto = texto[:-2]

    return texto


def limpiar_clave(valor):
    """
    Grupo y subgrupo deben conservar ceros a la izquierda.
    """
    texto = limpiar_codigo(valor)

    if texto.isdigit() and len(texto) == 1:
        texto = texto.zfill(2)

    return texto


def nombre_hoja_articulos(ruta):
    """
    Soporta tanto 'Articulos' como 'Artículos'.
    """
    xls = pd.ExcelFile(ruta)

    for hoja in xls.sheet_names:
        if normalizar_encabezado(hoja) == "articulos":
            return hoja

    raise ValueError(f"No se encontro la hoja Articulos/Artículos en: {ruta.name}")


def localizar_columna(columnas, *opciones):
    mapa = {normalizar_encabezado(col): col for col in columnas}

    for opcion in opciones:
        clave = normalizar_encabezado(opcion)
        if clave in mapa:
            return mapa[clave]

    return None


def normalizar_observacion(valor):
    texto = quitar_acentos(valor).upper().strip()
    texto = re.sub(r"\s+", " ", texto)
    return texto


def estado_clasificacion(observacion, subobservacion):
    """
    Interpreta exactamente el criterio usado en las revisiones manuales:

    CLASIFICACION_CORRECTA
        No se marcó GRUPO INCORRECTO ni SUBGRUPO INCORRECTO.
        Incluye OK, ortografía, especificación técnica, duplicado, etc.

    GRUPO_INCORRECTO
        Observación CLASIFICACION + subobservación GRUPO INCORRECTO.
        El grupo y, por consecuencia, la clasificación completa no se
        consideran ejemplos positivos.

    SUBGRUPO_INCORRECTO
        Observación CLASIFICACION + subobservación SUBGRUPO INCORRECTO.
        El GRUPO sí queda respaldado, pero ese SUBGRUPO no.

    SIN_REVISION
        Solo cuando ambas celdas están realmente vacías.
    """
    obs = normalizar_observacion(observacion)
    sub = normalizar_observacion(subobservacion)

    if not obs and not sub:
        return "SIN_REVISION"

    if sub == "GRUPO INCORRECTO":
        return "GRUPO_INCORRECTO"

    if sub == "SUBGRUPO INCORRECTO":
        return "SUBGRUPO_INCORRECTO"

    # Si por alguna anomalía aparece CLASIFICACION sin una de las dos
    # subobservaciones oficiales, no asumimos que sea correcta.
    if obs == "CLASIFICACION":
        return "SIN_REVISION"

    return "CLASIFICACION_CORRECTA"


def estado_revision(observacion, subobservacion):
    obs = normalizar_observacion(observacion)
    sub = normalizar_observacion(subobservacion)

    if obs == "OK" and sub == "OK":
        return "OK"

    if obs or sub:
        return "CON_DESVIACION"

    return "SIN_REVISION"


# ============================================================
# BASE DE DATOS
# ============================================================


def crear_tabla(con):
    con.execute("""
        CREATE TABLE IF NOT EXISTS revisiones_historicas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT NOT NULL,
            grupo TEXT,
            nombre_grupo TEXT,
            subgrupo TEXT,
            nombre_subgrupo TEXT,
            descripcion TEXT,
            usuario TEXT,
            nombre_usuario TEXT,
            um TEXT,
            observacion TEXT,
            subobservacion TEXT,
            notas TEXT,
            mes TEXT NOT NULL,
            anio INTEGER NOT NULL,

            -- Interpretacion de la revision manual
            estado_revision TEXT NOT NULL,
            estado_clasificacion TEXT NOT NULL,

            UNIQUE(codigo, mes, anio)
        )
    """)

    con.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_revisiones_codigo
        ON revisiones_historicas(codigo)
    """)

    con.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_revisiones_clasificacion
        ON revisiones_historicas(
            grupo,
            subgrupo,
            estado_clasificacion
        )
    """)

    con.execute("""
        CREATE INDEX IF NOT EXISTS
        idx_revisiones_mes
        ON revisiones_historicas(anio, mes)
    """)

    con.commit()


# ============================================================
# LECTURA DE CADA EXCEL
# ============================================================


def leer_mes(ruta, mes):
    hoja = nombre_hoja_articulos(ruta)

    df = pd.read_excel(
        ruta,
        sheet_name=hoja,
        dtype=object,
    )

    # Detectar columnas por encabezado para que no importe si Observacion
    # está en AK, AL, AF, AH, AN, AO o AI.
    c_codigo = localizar_columna(df.columns, "Codigo", "Código")
    c_grupo = localizar_columna(df.columns, "Grupo")
    c_nombre_grupo = localizar_columna(
        df.columns,
        "Nombre Grupo",
        "Nombre de Grupo",
    )
    c_subgrupo = localizar_columna(df.columns, "Subgrupo")
    c_nombre_subgrupo = localizar_columna(
        df.columns,
        "Nombre Subgrupo",
        "Nombre de Subgrupo",
    )
    c_descripcion = localizar_columna(
        df.columns,
        "Descripción",
        "Descripcion",
    )
    c_usuario = localizar_columna(df.columns, "Usuario")
    c_nombre_usuario = localizar_columna(
        df.columns,
        "Nombre de Usuario",
        "Nombre Usuario",
    )
    c_um = localizar_columna(df.columns, "UM")
    c_observacion = localizar_columna(
        df.columns,
        "Observación",
        "Observacion",
    )
    c_subobservacion = localizar_columna(
        df.columns,
        "Subobservación",
        "Subobservacion",
    )
    c_notas = localizar_columna(
        df.columns,
        "Notas/Comentarios",
        "Notas",
        "Comentarios",
    )

    obligatorias = {
        "Codigo": c_codigo,
        "Grupo": c_grupo,
        "Subgrupo": c_subgrupo,
        "Descripcion": c_descripcion,
        "Observacion": c_observacion,
        "Subobservacion": c_subobservacion,
    }

    faltantes = [nombre for nombre, columna in obligatorias.items() if columna is None]

    if faltantes:
        raise ValueError(
            f"{ruta.name}: faltan columnas requeridas: " + ", ".join(faltantes)
        )

    registros = []

    for _, fila in df.iterrows():
        codigo = limpiar_codigo(fila[c_codigo])

        if not codigo:
            continue

        observacion = limpiar_texto(fila[c_observacion])
        subobservacion = limpiar_texto(fila[c_subobservacion])

        registros.append(
            {
                "codigo": codigo,
                "grupo": limpiar_clave(fila[c_grupo]),
                "nombre_grupo": (
                    limpiar_texto(fila[c_nombre_grupo]) if c_nombre_grupo else ""
                ),
                "subgrupo": limpiar_clave(fila[c_subgrupo]),
                "nombre_subgrupo": (
                    limpiar_texto(fila[c_nombre_subgrupo]) if c_nombre_subgrupo else ""
                ),
                "descripcion": limpiar_texto(fila[c_descripcion]),
                "usuario": (limpiar_codigo(fila[c_usuario]) if c_usuario else ""),
                "nombre_usuario": (
                    limpiar_texto(fila[c_nombre_usuario]) if c_nombre_usuario else ""
                ),
                "um": (limpiar_texto(fila[c_um]) if c_um else ""),
                "observacion": observacion,
                "subobservacion": subobservacion,
                "notas": (limpiar_texto(fila[c_notas]) if c_notas else ""),
                "mes": mes,
                "anio": ANIO,
                "estado_revision": estado_revision(
                    observacion,
                    subobservacion,
                ),
                "estado_clasificacion": estado_clasificacion(
                    observacion,
                    subobservacion,
                ),
            }
        )

    return registros


# ============================================================
# IMPORTACION
# ============================================================


def guardar_registros(con, registros):
    sql = """
        INSERT INTO revisiones_historicas (
            codigo,
            grupo,
            nombre_grupo,
            subgrupo,
            nombre_subgrupo,
            descripcion,
            usuario,
            nombre_usuario,
            um,
            observacion,
            subobservacion,
            notas,
            mes,
            anio,
            estado_revision,
            estado_clasificacion
        )
        VALUES (
            :codigo,
            :grupo,
            :nombre_grupo,
            :subgrupo,
            :nombre_subgrupo,
            :descripcion,
            :usuario,
            :nombre_usuario,
            :um,
            :observacion,
            :subobservacion,
            :notas,
            :mes,
            :anio,
            :estado_revision,
            :estado_clasificacion
        )
        ON CONFLICT(codigo, mes, anio)
        DO UPDATE SET
            grupo = excluded.grupo,
            nombre_grupo = excluded.nombre_grupo,
            subgrupo = excluded.subgrupo,
            nombre_subgrupo = excluded.nombre_subgrupo,
            descripcion = excluded.descripcion,
            usuario = excluded.usuario,
            nombre_usuario = excluded.nombre_usuario,
            um = excluded.um,
            observacion = excluded.observacion,
            subobservacion = excluded.subobservacion,
            notas = excluded.notas,
            estado_revision = excluded.estado_revision,
            estado_clasificacion = excluded.estado_clasificacion
    """

    con.executemany(sql, registros)
    con.commit()


def resumen_base(con):
    total = con.execute("""
        SELECT COUNT(*)
        FROM revisiones_historicas
    """).fetchone()[0]

    correcta = con.execute("""
        SELECT COUNT(*)
        FROM revisiones_historicas
        WHERE estado_clasificacion = 'CLASIFICACION_CORRECTA'
    """).fetchone()[0]

    grupo_mal = con.execute("""
        SELECT COUNT(*)
        FROM revisiones_historicas
        WHERE estado_clasificacion = 'GRUPO_INCORRECTO'
    """).fetchone()[0]

    subgrupo_mal = con.execute("""
        SELECT COUNT(*)
        FROM revisiones_historicas
        WHERE estado_clasificacion = 'SUBGRUPO_INCORRECTO'
    """).fetchone()[0]

    sin_revision = con.execute("""
        SELECT COUNT(*)
        FROM revisiones_historicas
        WHERE estado_clasificacion = 'SIN_REVISION'
    """).fetchone()[0]

    print("\n" + "=" * 94)
    print("RESUMEN DE REVISIONES HISTORICAS")
    print("=" * 94)
    print(f"Total registros:                    {total}")
    print(f"Clasificacion correcta:             {correcta}")
    print(f"Grupo incorrecto:                   {grupo_mal}")
    print(f"Subgrupo incorrecto:                {subgrupo_mal}")
    print(f"Sin revision interpretable:         {sin_revision}")
    print("-" * 94)

    filas = con.execute("""
        SELECT
            mes,
            COUNT(*) AS total,
            SUM(CASE
                WHEN estado_clasificacion = 'CLASIFICACION_CORRECTA'
                THEN 1 ELSE 0 END
            ) AS correcta,
            SUM(CASE
                WHEN estado_clasificacion = 'GRUPO_INCORRECTO'
                THEN 1 ELSE 0 END
            ) AS grupo_mal,
            SUM(CASE
                WHEN estado_clasificacion = 'SUBGRUPO_INCORRECTO'
                THEN 1 ELSE 0 END
            ) AS subgrupo_mal,
            SUM(CASE
                WHEN estado_clasificacion = 'SIN_REVISION'
                THEN 1 ELSE 0 END
            ) AS sin_revision
        FROM revisiones_historicas
        GROUP BY mes
        ORDER BY CASE mes
            WHEN 'ENERO' THEN 1
            WHEN 'FEBRERO' THEN 2
            WHEN 'MARZO' THEN 3
            WHEN 'ABRIL' THEN 4
            WHEN 'MAYO' THEN 5
            WHEN 'JUNIO' THEN 6
            WHEN 'JULIO' THEN 7
            WHEN 'AGOSTO' THEN 8
            ELSE 99
        END
    """).fetchall()

    print(
        f"{'MES':<12}"
        f"{'TOTAL':>9}"
        f"{'CORRECTA':>13}"
        f"{'GRUPO MAL':>13}"
        f"{'SUBGRUPO MAL':>15}"
        f"{'SIN REV.':>12}"
    )

    for mes, total_mes, ok, gmal, smal, sinrev in filas:
        print(
            f"{mes:<12}"
            f"{total_mes:>9}"
            f"{(ok or 0):>13}"
            f"{(gmal or 0):>13}"
            f"{(smal or 0):>15}"
            f"{(sinrev or 0):>12}"
        )

    print("=" * 94)


def main():
    print("=" * 78)
    print("IMPORTACION DE REVISIONES HISTORICAS ENERO-AGOSTO 2026")
    print("=" * 78)
    print(f"Base de datos: {DB_PATH}")
    print(f"Carpeta Excel: {CARPETA_HISTORICOS}")
    print()

    if not DB_PATH.exists():
        raise FileNotFoundError(f"No se encontro la base de datos:\n{DB_PATH}")

    if not CARPETA_HISTORICOS.exists():
        CARPETA_HISTORICOS.mkdir(parents=True, exist_ok=True)
        raise FileNotFoundError(
            "Se creo la carpeta:\n"
            f"{CARPETA_HISTORICOS}\n\n"
            "Copia ahi los 8 Excel de enero a agosto y vuelve "
            "a ejecutar el programa."
        )

    con = sqlite3.connect(DB_PATH)

    try:
        crear_tabla(con)

        importados = 0

        for mes, nombre_archivo in ARCHIVOS.items():
            ruta = CARPETA_HISTORICOS / nombre_archivo

            if not ruta.exists():
                print(f"[FALTA] {mes}: {nombre_archivo}")
                continue

            registros = leer_mes(ruta, mes)
            guardar_registros(con, registros)

            importados += len(registros)

            correctas = sum(
                r["estado_clasificacion"] == "CLASIFICACION_CORRECTA" for r in registros
            )
            grupos_mal = sum(
                r["estado_clasificacion"] == "GRUPO_INCORRECTO" for r in registros
            )
            subgrupos_mal = sum(
                r["estado_clasificacion"] == "SUBGRUPO_INCORRECTO" for r in registros
            )

            print(
                f"[OK] {mes:<10} "
                f"{len(registros):>5} registros | "
                f"correcta: {correctas:>5} | "
                f"grupo mal: {grupos_mal:>4} | "
                f"subgrupo mal: {subgrupos_mal:>3}"
            )

        if importados == 0:
            print("\nNo se importo ningun archivo.")
            print(
                "Verifica que los nombres de los Excel coincidan "
                "con los indicados en ARCHIVOS."
            )
            return

        resumen_base(con)

        print("\nIMPORTACION TERMINADA CORRECTAMENTE.")
        print(
            "Los Excel historicos ya no tendran que ser consultados "
            "por el clasificador mensual."
        )

    finally:
        con.close()


if __name__ == "__main__":
    main()
