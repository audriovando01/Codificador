import sqlite3

conexion = sqlite3.connect("base_datos.db")

cursor = conexion.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS prueba (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL
)
""")

cursor.execute(
    "INSERT INTO prueba (nombre) VALUES (?)",
    ("Prueba de conexión",)
)

conexion.commit()

cursor.execute("SELECT * FROM prueba")

datos = cursor.fetchall()

print(datos)

conexion.close()