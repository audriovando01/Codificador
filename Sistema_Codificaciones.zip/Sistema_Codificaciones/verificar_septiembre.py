import sqlite3

conexion = sqlite3.connect("base_datos.db")
cursor = conexion.cursor()

print("=" * 40)
print("   VERIFICACIÓN DE SEPTIEMBRE")
print("=" * 40)

# Total de registros de septiembre
cursor.execute("""
    SELECT COUNT(*)
    FROM articulos_historico
    WHERE mes = 'SEPTIEMBRE'
""")

total_septiembre = cursor.fetchone()[0]

print(f"\nRegistros de SEPTIEMBRE: {total_septiembre}")

# Mostrar algunos registros
cursor.execute("""
    SELECT codigo, grupo, subgrupo, descripcion, usuario, um, mes
    FROM articulos_historico
    WHERE mes = 'SEPTIEMBRE'
    ORDER BY codigo
    LIMIT 10
""")

registros = cursor.fetchall()

print("\nPrimeros 10 registros:")

for registro in registros:
    codigo, grupo, subgrupo, descripcion, usuario, um, mes = registro

    print("\nCódigo:", codigo)
    print("Grupo:", grupo)
    print("Subgrupo:", subgrupo)
    print("Descripción:", descripcion)
    print("Usuario:", usuario)
    print("UM:", um)
    print("Mes:", mes)

# Comprobar campos vacíos
cursor.execute("""
    SELECT COUNT(*)
    FROM articulos_historico
    WHERE mes = 'SEPTIEMBRE'
      AND (
          grupo IS NULL OR grupo = ''
          OR subgrupo IS NULL OR subgrupo = ''
          OR descripcion IS NULL OR descripcion = ''
          OR usuario IS NULL OR usuario = ''
          OR um IS NULL OR um = ''
      )
""")

incompletos = cursor.fetchone()[0]

print("\n" + "=" * 40)
print("      RESULTADO DE VERIFICACIÓN")
print("=" * 40)

print(f"Registros de SEPTIEMBRE: {total_septiembre}")
print(f"Registros con datos incompletos: {incompletos}")

print("=" * 40)

conexion.close()

input("\nPresiona ENTER para salir...")