import os
import re
import glob
import sqlite3
import unicodedata
from collections import Counter

import pandas as pd

BASE_REVISION = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "base_datos.db")

UMBRAL_MARCAR = 0.80
UMBRAL_REVISAR = 0.58
MARGEN_MINIMO = 0.16

# Evidencia histórica: se usa de forma conservadora.
HIST_SIM_MINIMA = 0.40
HIST_SIM_FUERTE = 0.62
HIST_CONSENSO_FUERTE = 0.72
HIST_MARGEN_MINIMO = 0.12
HIST_MAX_VECINOS = 30

CLASIFICACIONES_GENERICAS = {
    ("12", "08"),
}

# Contextos técnicos que tienen prioridad sobre una coincidencia genérica
# del nombre del artículo. No son excepciones por código: son reglas
# reutilizables para familias completas.
PATRONES_CONTEXTO_ACTUAL = {
    # ACCESORIOS TUBING
    ("02", "16"): [
        r"\bRACOR\b",
        r"\bOD\b",
        r"\bNPTM\b",
        r"\bDOBLE\s+FER(?:UL|RUL|ULA)\b",
        r"\bCOMPRESION\b",
    ],
    # ACCESORIOS R.C.I. / RED CONTRA INCENDIO
    ("02", "19"): [
        r"\bUL\s*/\s*FM\b",
        r"\bCERTIFICACION\s+UL\b",
        r"\bEXTREMO[S]?\s+RANURAD",
    ],
    # CONEXIONES PARA MANGUERA
    ("06", "04"): [
        r"\bESPIGA\b",
        r"\bGARRAS?\b",
        r"\bFLARE\b",
        r"\bMANGUERA\b",
        r"\bCAMPANA\s+CARA\s+PLANA\b",
    ],
    # VALVULAS PARA INSTRUMENTOS
    ("07", "10"): [
        r"\bOD\b",
        r"\bMONTAJE\s+EN\s+PANEL\b",
        r"\bNO\s+VIAS\b",
        r"\b3\s+VIAS\b",
        r"\bINSTRUMENT",
    ],
    # PLOMERIA
    ("12", "01"): [
        r"\bCPVC\b",
        r"\bPVC\b",
        r"\bPLOMERIA\b",
    ],
    # HERRAMIENTAS MANUALES
    ("15", "01"): [
        r"^\s*CORTA(?:DOR|DORA)?\b",
        r"^\s*LLAVE\b",
        r"^\s*PINZA[S]?\b",
        r"^\s*EXTRACTOR\b",
        r"^\s*HERRAMIENTA\b",
    ],
    # ACCESORIOS ELECTRICOS DE CONSTRUCCION
    ("20", "03"): [
        r"\bCONDUIT\b",
        r"\bCROUSE[\s-]*HIND",
        r"\bEATON\b",
        r"\bUNY[-\s]?\d*",
        r"\bUNF[-\s]?\d*",
        r"\bCLASIFICACION\s+DE\s+AREA\b",
        r"\bCLASE\s+I\b",
        r"\bDIV\.?\s*[12]\b",
    ],
    # EPP Y EPPE
    ("40", "09"): [
        r"\bARCO\s+ELECT",
        r"\bCAL\s*/\s*CM2\b",
        r"\bCHAQUETA\b",
        r"\bOVEROL\b",
        r"\bCASCO\b",
        r"\bCARETA\b",
        r"\bCAPUCHA\b",
        r"\bPASAMONTANAS\b",
        r"\bSALISBURY\b",
    ],
    # SISTEMA DE FRENOS
    ("61", "05"): [
        r"\bFRENO[S]?\b",
        r"\bBOMBA\s+DE\s+FRENO\b",
        r"\bBALATA[S]?\b",
        r"\bDISCO[S]?\s+DE\s+FRENO\b",
    ],
}

STOPWORDS = {
    "DE",
    "DEL",
    "LA",
    "EL",
    "LOS",
    "LAS",
    "PARA",
    "CON",
    "SIN",
    "EN",
    "Y",
    "O",
    "A",
    "AL",
    "POR",
    "TIPO",
    "MARCA",
    "MODELO",
    "MATERIAL",
    "ESPECIFICACION",
    "ESPECIFICACIÓN",
    "CLASE",
    "DIAMETRO",
    "DIÁMETRO",
    "LONGITUD",
    "LARGO",
    "ANCHO",
    "ALTO",
    "ALTURA",
    "ESPESOR",
    "COLOR",
    "ACABADO",
    "MEDIDA",
    "NO",
    "NUMERO",
    "NÚMERO",
    "PZA",
    "PZAS",
    "UNIDAD",
    "UNIDADES",
    "SERIE",
    "FABRICANTE",
    "NORMA",
    "NORMATIVA",
    "GRADO",
    "CAPACIDAD",
    "PRESION",
    "PRESIÓN",
    "VOLTAJE",
    "CORRIENTE",
}

PALABRAS_DEBILES = {
    "GENERAL",
    "GENERALES",
    "ACCESORIO",
    "ACCESORIOS",
    "MATERIAL",
    "MATERIALES",
    "EQUIPO",
    "EQUIPOS",
    "SISTEMA",
    "SISTEMAS",
    "SERVICIO",
    "SERVICIOS",
    "TECNICO",
    "TECNICOS",
    "MECANICA",
    "MECANICO",
    "MECANICOS",
    "PROCESO",
    "PROCESOS",
    "SEGURIDAD",
    "CALIDAD",
    "CANAL",
    "REFACCION",
    "REFACCIONES",
    "REPUESTO",
    "REPUESTOS",
}

TERMINOS_CONTEXTUALES = {
    "MOTOR",
    "COMPRESOR",
    "BOMBA",
    "MADERA",
    "CEMENTO",
    "COMBUSTIBLE",
    "ANTICONGELANTE",
    "CANAL",
    "SEGURIDAD",
    "PROCESOS",
    "MECANICA",
    "O-RING",
    "ORING",
    "PEAD",
    "PVC",
    "CPVC",
    "ACERO",
    "INOXIDABLE",
    "CARBONO",
    "ALUMINIO",
    "LATON",
    "BRONCE",
    "PLASTICO",
    "CAUCHO",
    "GRAFITO",
    "POLIETILENO",
    "CONDUIT",
}


def quitar_acentos(texto):
    texto = "" if pd.isna(texto) else str(texto)
    return "".join(
        c
        for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )


def normalizar(texto):
    texto = quitar_acentos(texto).upper()
    texto = texto.replace("Ø", " ")
    texto = re.sub(r"[^A-Z0-9/#.+\- ]+", " ", texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def tokenizar(texto):
    return [t for t in normalizar(texto).split() if len(t) >= 2 and t not in STOPWORDS]


def normalizar_codigo(valor):
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    return texto


def normalizar_clave(valor):
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    if texto.isdigit() and len(texto) < 2:
        texto = texto.zfill(2)
    return texto


def contiene_frase(texto, frase):
    texto_norm = normalizar(texto)
    frase_norm = normalizar(frase)
    if not frase_norm:
        return False

    return (
        re.search(
            rf"(?<![A-Z0-9]){re.escape(frase_norm)}(?![A-Z0-9])",
            texto_norm,
        )
        is not None
    )


def primer_segmento(texto):
    """
    Conserva la puntuación hasta separar el primer segmento.
    Antes se normalizaba primero y las comas/punto y coma desaparecían,
    por lo que se podían mezclar atributos con el objeto principal.
    """
    raw = quitar_acentos(texto).upper()
    if not raw.strip():
        return ""

    raw = re.split(r"[,;]", raw, maxsplit=1)[0]
    return normalizar(raw)


def objeto_principal(texto):
    seg = primer_segmento(texto)
    if not seg:
        return ""
    return " ".join(seg.split()[:10])


def tokens_objeto(texto):
    return [t for t in tokenizar(objeto_principal(texto)) if t not in PALABRAS_DEBILES]


def detectar_especializaciones(texto):
    t = normalizar(texto)
    return [termino for termino in TERMINOS_CONTEXTUALES if contiene_frase(t, termino)]


def es_mencion_secundaria(descripcion, termino):
    desc = normalizar(descripcion)
    obj = objeto_principal(descripcion)
    termino = normalizar(termino)

    if not termino:
        return True

    if not contiene_frase(obj, termino):
        return True

    patron = (
        rf"\b(?:PARA|DE|DEL|CON|EN|USO|APLICACION|APLICACIÓN)\s+"
        rf"(?:[A-Z0-9\-]+\s+){{0,3}}{re.escape(termino)}\b"
    )

    if re.search(patron, desc):
        return True

    return False


def buscar_archivo_resultado():
    archivos = glob.glob(os.path.join(BASE_REVISION, "RESULTADO_*.xlsx"))

    if not archivos:
        raise FileNotFoundError(
            "No se encontro ningun RESULTADO_*.xlsx en:\n" + BASE_REVISION
        )

    return max(archivos, key=os.path.getmtime)


def nombre_salida(archivo_entrada):
    base = os.path.basename(archivo_entrada)
    periodo = os.path.splitext(base)[0].replace("RESULTADO_", "")

    return os.path.join(
        BASE_REVISION,
        f"DIAGNOSTICO_CLASIFICACION_{periodo}.xlsx",
    )


def cargar_catalogo():
    conn = sqlite3.connect(DB_PATH)

    catalogo = pd.read_sql_query(
        """
        SELECT
            grupo,
            subgrupo,
            especialidad,
            nombre_grupo,
            nombre_subgrupo,
            ica,
            um,
            determinante
        FROM catalogo_subgrupos
        """,
        conn,
    )

    campos = pd.read_sql_query(
        """
        SELECT
            grupo,
            subgrupo,
            orden,
            elemento,
            tipo_elemento,
            obligatorio
        FROM campos_plantilla
        ORDER BY grupo, subgrupo, orden
        """,
        conn,
    )

    conn.close()

    for tabla in (catalogo, campos):
        tabla["grupo"] = tabla["grupo"].map(normalizar_clave)
        tabla["subgrupo"] = tabla["subgrupo"].map(normalizar_clave)

    return catalogo, campos


def cargar_revisiones_historicas():
    """
    Carga únicamente la tabla SQLite. Los Excel de enero-agosto NO se
    consultan durante el diagnóstico mensual.
    """
    conn = sqlite3.connect(DB_PATH)

    historico = pd.read_sql_query(
        """
        SELECT
            codigo,
            grupo,
            subgrupo,
            descripcion,
            mes,
            estado_clasificacion
        FROM revisiones_historicas
        WHERE COALESCE(TRIM(descripcion), '') <> ''
          AND estado_clasificacion <> 'SIN_REVISION'
        """,
        conn,
    )

    conn.close()

    historico["grupo"] = historico["grupo"].map(normalizar_clave)
    historico["subgrupo"] = historico["subgrupo"].map(normalizar_clave)

    return historico


def tokens_historicos(texto):
    """
    Tokens técnicos normalizados para comparación histórica.
    Se eliminan palabras débiles y se unifican plurales simples.
    """
    resultado = set()

    for token in tokenizar(texto):
        raiz = raiz_token(token)

        if not raiz:
            continue

        if raiz in PALABRAS_DEBILES:
            continue

        if len(raiz) < 3:
            continue

        resultado.add(raiz)

    return resultado


def construir_indice_historico(historico):
    """
    Índice invertido token -> registros históricos.
    Evita comparar cada artículo nuevo contra los 11 mil registros.
    """
    registros = []
    indice = {}

    for _, fila in historico.iterrows():
        tokens = tokens_historicos(fila["descripcion"])

        if not tokens:
            continue

        registro = {
            "codigo": normalizar_codigo(fila["codigo"]),
            "clave": (
                normalizar_clave(fila["grupo"]),
                normalizar_clave(fila["subgrupo"]),
            ),
            "descripcion": str(fila["descripcion"]),
            "mes": str(fila["mes"]),
            "estado": str(fila["estado_clasificacion"]).strip().upper(),
            "tokens": tokens,
        }

        idx = len(registros)
        registros.append(registro)

        for token in tokens:
            indice.setdefault(token, set()).add(idx)

    return {
        "registros": registros,
        "indice": indice,
    }


def similitud_historica(tokens_a, tokens_b):
    """
    Dice sobre tokens técnicos. Es deliberadamente conservadora:
    una sola palabra compartida no basta para dar una clasificación.
    """
    if not tokens_a or not tokens_b:
        return 0.0, 0

    comunes = tokens_a & tokens_b
    n_comunes = len(comunes)

    if n_comunes == 0:
        return 0.0, 0

    score = (2.0 * n_comunes) / (len(tokens_a) + len(tokens_b))

    return score, n_comunes


def evaluar_evidencia_historica(
    descripcion,
    clave_actual,
    indice_historico,
):
    """
    Resume antecedentes parecidos.

    Positivos:
      CLASIFICACION_CORRECTA -> respalda grupo + subgrupo.

    Negativos:
      GRUPO_INCORRECTO -> evidencia contra ese grupo.
      SUBGRUPO_INCORRECTO -> respalda el grupo, pero evidencia contra
      ese subgrupo.

    Los conteos brutos por mes NO deciden. Solo cuentan antecedentes
    cuya descripción es suficientemente parecida al artículo nuevo.
    """
    vacio = {
        "disponible": False,
        "actual_score": 0.0,
        "actual_count": 0,
        "mejor_clave": None,
        "mejor_score": 0.0,
        "mejor_count": 0,
        "segundo_score": 0.0,
        "neg_grupo_actual": 0.0,
        "neg_subgrupo_actual": 0.0,
        "ejemplos_actual": [],
        "ejemplos_mejor": [],
        "detalle": "",
    }

    if not indice_historico:
        return vacio

    q_tokens = tokens_historicos(descripcion)

    if len(q_tokens) < 2:
        return vacio

    candidatos = set()

    for token in q_tokens:
        candidatos.update(indice_historico["indice"].get(token, set()))

    if not candidatos:
        return vacio

    vecinos = []

    for idx in candidatos:
        reg = indice_historico["registros"][idx]
        sim, comunes = similitud_historica(
            q_tokens,
            reg["tokens"],
        )

        # Una descripción corta necesita una semejanza mayor.
        minimo = HIST_SIM_MINIMA
        if len(q_tokens) <= 4:
            minimo = 0.50

        if sim < minimo:
            continue

        if comunes < 2:
            continue

        vecinos.append((sim, comunes, reg))

    if not vecinos:
        return vacio

    vecinos.sort(
        key=lambda x: (x[0], x[1]),
        reverse=True,
    )
    vecinos = vecinos[:HIST_MAX_VECINOS]

    positivos = {}
    negativos_grupo = {}
    negativos_subgrupo = {}

    def agregar(dic, clave, sim, reg):
        bloque = dic.setdefault(
            clave,
            {"pesos": [], "ejemplos": []},
        )
        # Elevar al cuadrado evita que muchos parecidos débiles ganen
        # frente a pocos antecedentes muy similares.
        bloque["pesos"].append(sim**2)
        if len(bloque["ejemplos"]) < 3:
            bloque["ejemplos"].append(
                (
                    reg["codigo"],
                    reg["mes"],
                    sim,
                )
            )

    for sim, _, reg in vecinos:
        clave = reg["clave"]
        estado = reg["estado"]

        if estado == "CLASIFICACION_CORRECTA":
            agregar(positivos, clave, sim, reg)

        elif estado == "GRUPO_INCORRECTO":
            agregar(
                negativos_grupo,
                clave[0],
                sim,
                reg,
            )

        elif estado == "SUBGRUPO_INCORRECTO":
            # El grupo sí fue aceptado.
            agregar(
                positivos,
                (clave[0], "__GRUPO__"),
                sim * 0.80,
                reg,
            )
            agregar(
                negativos_subgrupo,
                clave,
                sim,
                reg,
            )

    def resumir_bloque(bloque):
        if not bloque:
            return 0.0, 0, []

        pesos = sorted(
            bloque["pesos"],
            reverse=True,
        )[:5]

        # Score de consenso: combina la mejor similitud con repetición.
        mejor = pesos[0] ** 0.5
        repeticion = min(1.0, len(pesos) / 3.0)
        score = min(
            1.0,
            (0.78 * mejor) + (0.22 * repeticion),
        )

        return score, len(pesos), bloque["ejemplos"]

    positivos_exactos = []

    for clave, bloque in positivos.items():
        if clave[1] == "__GRUPO__":
            continue

        score, count, ejemplos = resumir_bloque(bloque)
        positivos_exactos.append((score, count, clave, ejemplos))

    positivos_exactos.sort(reverse=True)

    mejor_score = positivos_exactos[0][0] if positivos_exactos else 0.0
    mejor_count = positivos_exactos[0][1] if positivos_exactos else 0
    mejor_clave = positivos_exactos[0][2] if positivos_exactos else None
    ejemplos_mejor = positivos_exactos[0][3] if positivos_exactos else []

    segundo_score = positivos_exactos[1][0] if len(positivos_exactos) > 1 else 0.0

    actual_score = 0.0
    actual_count = 0
    ejemplos_actual = []

    if clave_actual in positivos:
        (
            actual_score,
            actual_count,
            ejemplos_actual,
        ) = resumir_bloque(positivos[clave_actual])

    neg_grupo_actual = 0.0
    if clave_actual[0] in negativos_grupo:
        neg_grupo_actual = resumir_bloque(negativos_grupo[clave_actual[0]])[0]

    neg_subgrupo_actual = 0.0
    if clave_actual in negativos_subgrupo:
        neg_subgrupo_actual = resumir_bloque(negativos_subgrupo[clave_actual])[0]

    def formatear_ejemplos(ejemplos):
        return ", ".join(
            f"{codigo} ({mes}, {sim:.0%})" for codigo, mes, sim in ejemplos
        )

    partes = []

    if actual_score:
        partes.append(
            "histórico respalda actual "
            f"{clave_actual[0]}/{clave_actual[1]} "
            f"({actual_score:.0%}; {actual_count} antecedente(s))"
        )

    if mejor_clave:
        partes.append(
            "mejor histórico "
            f"{mejor_clave[0]}/{mejor_clave[1]} "
            f"({mejor_score:.0%}; {mejor_count} antecedente(s))"
        )

    if neg_grupo_actual:
        partes.append(f"histórico cuestiona grupo actual ({neg_grupo_actual:.0%})")

    if neg_subgrupo_actual:
        partes.append(
            f"histórico cuestiona subgrupo actual " f"({neg_subgrupo_actual:.0%})"
        )

    return {
        "disponible": True,
        "actual_score": actual_score,
        "actual_count": actual_count,
        "mejor_clave": mejor_clave,
        "mejor_score": mejor_score,
        "mejor_count": mejor_count,
        "segundo_score": segundo_score,
        "neg_grupo_actual": neg_grupo_actual,
        "neg_subgrupo_actual": neg_subgrupo_actual,
        "ejemplos_actual": ejemplos_actual,
        "ejemplos_mejor": ejemplos_mejor,
        "detalle": "; ".join(partes),
        "ejemplos_actual_txt": formatear_ejemplos(ejemplos_actual),
        "ejemplos_mejor_txt": formatear_ejemplos(ejemplos_mejor),
    }


def construir_perfiles(catalogo, campos):
    perfiles = {}

    campos_por_clave = {}
    for clave, bloque in campos.groupby(["grupo", "subgrupo"]):
        campos_por_clave[clave] = bloque.to_dict("records")

    for _, fila in catalogo.iterrows():
        grupo = normalizar_clave(fila["grupo"])
        subgrupo = normalizar_clave(fila["subgrupo"])
        clave = (grupo, subgrupo)

        textos_fijos = []
        obligatorios = []

        for campo in campos_por_clave.get(clave, []):
            elemento = str(campo["elemento"]).strip()

            if campo["tipo_elemento"] == "TEXTO_FIJO":
                textos_fijos.append(elemento)
            elif int(campo["obligatorio"]) == 1:
                obligatorios.append(elemento)

        perfiles[clave] = {
            "grupo": grupo,
            "subgrupo": subgrupo,
            "especialidad": (
                "" if pd.isna(fila["especialidad"]) else str(fila["especialidad"])
            ),
            "nombre_grupo": (
                "" if pd.isna(fila["nombre_grupo"]) else str(fila["nombre_grupo"])
            ),
            "nombre_subgrupo": (
                "" if pd.isna(fila["nombre_subgrupo"]) else str(fila["nombre_subgrupo"])
            ),
            "um": "" if pd.isna(fila["um"]) else str(fila["um"]),
            "determinante": (
                "" if pd.isna(fila["determinante"]) else str(fila["determinante"])
            ),
            "textos_fijos": textos_fijos,
            "obligatorios": obligatorios,
        }

    return perfiles


def es_servicio(perfil):
    texto = normalizar(
        " ".join(
            [
                perfil.get("especialidad", ""),
                perfil.get("nombre_grupo", ""),
                perfil.get("nombre_subgrupo", ""),
            ]
        )
    )
    return "SERVICIO" in texto


def articulo_actual_es_servicio(descripcion, um, perfil_actual):
    if normalizar(um) == "SV":
        return True
    if perfil_actual:
        return es_servicio(perfil_actual)
    return objeto_principal(descripcion).startswith("SERVICIO")


def raiz_token(token):
    """
    Normalización lexical muy conservadora para comparar singular/plural.
    No pretende ser un stemmer lingüístico completo.
    """
    t = normalizar(token)

    if len(t) <= 4:
        return t

    # MANGUERAS -> MANGUERA, VALVULAS -> VALVULA, BOMBAS -> BOMBA
    if t.endswith("ES") and len(t) > 6:
        return t[:-2]

    if t.endswith("S") and len(t) > 5:
        return t[:-1]

    return t


def tokens_raiz(texto):
    return {raiz_token(t) for t in tokenizar(texto) if t not in PALABRAS_DEBILES}


def evidencia_actual_suficiente(
    descripcion,
    perfil_actual,
    clave_actual,
):
    """
    Busca evidencia positiva para CONFIRMAR la clasificación actual.

    Es deliberadamente más flexible que la lógica utilizada para acusar
    una clasificación incorrecta. Para marcar un error seguimos exigiendo
    evidencia fuerte; para confirmar la clasificación actual basta una
    coincidencia técnica coherente y que no exista una alternativa fuerte.
    """
    if not perfil_actual:
        return False, []

    evidencias = []

    # 1. Reglas técnicas específicas ya definidas para la familia actual.
    contexto, senales = contexto_actual_fuerte(
        descripcion,
        clave_actual,
    )
    if contexto:
        evidencias.append("CONTEXTO TECNICO ACTUAL")
        return True, evidencias

    obj = objeto_principal(descripcion)
    obj_raices = tokens_raiz(obj)

    # 2. Coincidencia con el nombre del subgrupo, admitiendo singular/plural.
    sub_raices = tokens_raiz(perfil_actual.get("nombre_subgrupo", ""))

    comunes_sub = sorted(obj_raices & sub_raices)

    if comunes_sub:
        evidencias.append("SUBGRUPO ACTUAL: " + ", ".join(comunes_sub))
        return True, evidencias

    # 3. Texto fijo de la plantilla actual presente en el objeto.
    for fijo in perfil_actual.get("textos_fijos", []):
        fijo_norm = normalizar(fijo)

        if (
            fijo_norm
            and fijo_norm not in PALABRAS_DEBILES
            and contiene_frase(obj, fijo_norm)
        ):
            evidencias.append("TEXTO FIJO ACTUAL: " + fijo_norm)
            return True, evidencias

    # 4. Familia actual. Solo se usa si no es una familia genérica.
    grupo = normalizar(perfil_actual.get("nombre_grupo", ""))

    familias_genericas = {
        "ARTICULOS DE FERRETERIA",
        "MATERIALES PARA OBRA CIVIL",
        "REPUESTOS",
        "REFACCIONES",
        "EQUIPOS",
    }

    if grupo not in familias_genericas:
        grupo_raices = tokens_raiz(grupo)
        comunes_grupo = sorted(obj_raices & grupo_raices)

        if comunes_grupo:
            evidencias.append("FAMILIA ACTUAL: " + ", ".join(comunes_grupo))
            return True, evidencias

    return False, evidencias


def regla_negocio_directa(descripcion):
    """
    No hay reglas manuales de clasificación forzada.
    La decisión se basa en catálogo, plantilla, contexto técnico
    y revisiones históricas almacenadas en SQLite.
    """
    return None, ""


def tokens_nombre_utiles(nombre):
    return [t for t in tokenizar(nombre) if t not in PALABRAS_DEBILES]


def puntuar_familia(descripcion, perfil):
    desc_tokens = set(tokenizar(descripcion))
    grupo_tokens = set(tokens_nombre_utiles(perfil["nombre_grupo"]))

    if not grupo_tokens:
        return 0.0, []

    comunes = grupo_tokens & desc_tokens
    if not comunes:
        return 0.0, []

    proporcion = len(comunes) / len(grupo_tokens)
    score = min(0.18, 0.18 * proporcion)

    return score, ["FAMILIA: " + ", ".join(sorted(comunes))]


def puntuar_objeto(descripcion, perfil):
    obj = objeto_principal(descripcion)
    nombre = perfil["nombre_subgrupo"]

    if not obj or not nombre:
        return 0.0, [], False

    evidencias = []
    score = 0.0
    ancla = False

    nombre_norm = normalizar(nombre)

    if (
        nombre_norm not in PALABRAS_DEBILES
        and contiene_frase(obj, nombre_norm)
        and not es_mencion_secundaria(descripcion, nombre_norm)
    ):
        score += 0.62
        evidencias.append(f"OBJETO PRINCIPAL: {nombre}")
        ancla = True

    else:
        tokens_nombre = tokens_nombre_utiles(nombre)
        tokens_obj = set(tokens_objeto(descripcion))

        if len(tokens_nombre) >= 2:
            presentes = [t for t in tokens_nombre if t in tokens_obj]
            proporcion = len(presentes) / len(tokens_nombre) if tokens_nombre else 0

            if proporcion >= 0.80:
                score += 0.48
                evidencias.append("OBJETO PARCIAL: " + ", ".join(presentes))
                ancla = True
            elif proporcion >= 0.60:
                score += 0.30
                evidencias.append("OBJETO PARCIAL: " + ", ".join(presentes))

    for texto in perfil["textos_fijos"]:
        texto_norm = normalizar(texto)

        if not texto_norm or texto_norm in PALABRAS_DEBILES:
            continue

        if contiene_frase(obj, texto_norm) and not es_mencion_secundaria(
            descripcion, texto_norm
        ):
            score += 0.24
            evidencias.append(f"TEXTO FIJO: {texto}")
            ancla = True
            break

    return min(0.86, score), evidencias, ancla


def puntuar_especializacion(descripcion, perfil):
    especializaciones = detectar_especializaciones(descripcion)

    if not especializaciones:
        return 0.0, []

    texto_perfil = normalizar(
        perfil["nombre_grupo"]
        + " "
        + perfil["nombre_subgrupo"]
        + " "
        + perfil["determinante"]
    )

    coincidencias = [e for e in especializaciones if contiene_frase(texto_perfil, e)]

    if not coincidencias:
        return 0.0, []

    return min(0.18, 0.09 * len(coincidencias)), [
        "ESPECIALIZACION: " + ", ".join(coincidencias[:3])
    ]


def puntuar_campos(descripcion, perfil):
    obligatorios = perfil["obligatorios"]

    if not obligatorios:
        return 0.0, []

    detectados = []

    for campo in obligatorios:
        campo_norm = normalizar(campo)
        if campo_norm and contiene_frase(descripcion, campo_norm):
            detectados.append(campo)

    if not detectados:
        return 0.0, []

    proporcion = len(detectados) / len(obligatorios)
    score = min(0.08, 0.08 * proporcion)

    return score, ["CAMPOS: " + ", ".join(detectados[:4])]


def puntuar_perfil(descripcion, perfil):
    score_familia, evid_familia = puntuar_familia(descripcion, perfil)
    score_objeto, evid_objeto, ancla = puntuar_objeto(descripcion, perfil)
    score_especial, evid_especial = puntuar_especializacion(descripcion, perfil)
    score_campos, evid_campos = puntuar_campos(descripcion, perfil)

    if score_objeto < 0.30:
        score_especial *= 0.25
        score_familia *= 0.50
        score_campos *= 0.50

    total = score_objeto + score_especial + score_familia + score_campos

    return {
        "score": min(1.0, total),
        "score_objeto": score_objeto,
        "score_especial": score_especial,
        "score_familia": score_familia,
        "score_campos": score_campos,
        "ancla": ancla,
        "evidencias": (evid_objeto + evid_especial + evid_familia + evid_campos),
    }


def especializacion_actual_respaldada(descripcion, perfil_actual):
    if not perfil_actual:
        return False, []

    texto_perfil = normalizar(
        perfil_actual["nombre_grupo"] + " " + perfil_actual["nombre_subgrupo"]
    )

    encontrados = []

    for termino in detectar_especializaciones(descripcion):
        if contiene_frase(texto_perfil, termino):
            encontrados.append(termino)

    if encontrados:
        return True, encontrados

    return False, []


def tokens_contexto_perfil(perfil):
    """
    Tokens representativos de la familia actual. Se usan para evitar
    saltos entre dominios técnicos cuando la descripción respalda
    claramente la familia donde ya está dado de alta el artículo.
    """
    texto = (
        perfil.get("especialidad", "")
        + " "
        + perfil.get("nombre_grupo", "")
        + " "
        + perfil.get("nombre_subgrupo", "")
    )

    ignorar = PALABRAS_DEBILES | {
        "ARTICULO",
        "ARTICULOS",
        "GENERAL",
        "GENERALES",
        "ACCESORIO",
        "ACCESORIOS",
        "MATERIAL",
        "MATERIALES",
    }

    return {t for t in tokenizar(texto) if t not in ignorar and len(t) >= 3}


def familia_actual_respaldada(descripcion, perfil_actual):
    """
    Detecta si la descripción contiene vocabulario técnico que respalda
    la familia actual (eléctrico, instrumentación, tubing, PEAD, etc.).
    """
    if not perfil_actual:
        return False, []

    desc = set(tokenizar(descripcion))
    familia = tokens_contexto_perfil(perfil_actual)
    comunes = sorted(desc & familia)

    return bool(comunes), comunes


def candidato_cambia_familia_respaldada(
    descripcion,
    perfil_actual,
    perfil_candidato,
):
    """
    Si la familia actual está explícitamente respaldada por la descripción,
    una alternativa de otro grupo necesita conservar ese contexto o se
    considera una pérdida de información.
    """
    if not perfil_actual or not perfil_candidato:
        return False, []

    respaldada, comunes = familia_actual_respaldada(
        descripcion,
        perfil_actual,
    )

    if not respaldada:
        return False, []

    if normalizar_clave(perfil_actual.get("grupo", "")) == normalizar_clave(
        perfil_candidato.get("grupo", "")
    ):
        return False, []

    candidato_tokens = tokens_contexto_perfil(perfil_candidato)
    conservados = [t for t in comunes if t in candidato_tokens]

    if conservados:
        return False, []

    return True, comunes


def candidato_es_mas_generico(
    descripcion,
    perfil_actual,
    perfil_candidato,
):
    """
    Protege clasificaciones especializadas frente a categorías que solo
    nombran el objeto genérico.

    Ejemplos:
      ACCESORIOS PEAD -> CODO
      VALVULAS PARA INSTRUMENTOS -> VALVULA DE BOLA
      ACCESORIOS TUBING -> TAPON
    """
    if not perfil_actual or not perfil_candidato:
        return False, []

    actual_texto = normalizar(
        perfil_actual.get("nombre_grupo", "")
        + " "
        + perfil_actual.get("nombre_subgrupo", "")
    )
    candidato_texto = normalizar(
        perfil_candidato.get("nombre_grupo", "")
        + " "
        + perfil_candidato.get("nombre_subgrupo", "")
    )

    especializaciones = []

    for termino in (
        "PEAD",
        "PVC",
        "CPVC",
        "TUBING",
        "CONDUIT",
        "INSTRUMENTACION",
        "INSTRUMENTOS",
        "ELECTRICO",
        "ELECTRICA",
        "FRENOS",
        "VEHICULAR",
        "AUTOMOTRIZ",
    ):
        if (
            contiene_frase(actual_texto, termino)
            and contiene_frase(descripcion, termino)
            and not contiene_frase(candidato_texto, termino)
        ):
            especializaciones.append(termino)

    return bool(especializaciones), especializaciones


def objeto_es_herramienta_o_accesorio_funcional(descripcion):
    """
    Detecta encabezados cuyo primer término describe una herramienta o
    accesorio funcional y donde el término posterior es el material/equipo
    sobre el que trabaja. Evita clasificar CORTA TUBING como TUBING.
    """
    obj = objeto_principal(descripcion)
    tokens = normalizar(obj).split()

    if not tokens:
        return False

    prefijos = (
        "CORTA",
        "CORTADOR",
        "CORTADORA",
        "LLAVE",
        "PINZA",
        "PINZAS",
        "EXTRACTOR",
        "ADAPTADOR",
        "SOPORTE",
        "HERRAMIENTA",
        "KIT",
    )

    return tokens[0] in prefijos


def candidato_pierde_especializacion(
    descripcion,
    perfil_actual,
    perfil_candidato,
):
    protegido, especializaciones = especializacion_actual_respaldada(
        descripcion,
        perfil_actual,
    )

    if not protegido:
        return False, []

    texto_candidato = normalizar(
        perfil_candidato["nombre_grupo"] + " " + perfil_candidato["nombre_subgrupo"]
    )

    perdidas = [e for e in especializaciones if not contiene_frase(texto_candidato, e)]

    return bool(perdidas), perdidas


def contexto_actual_fuerte(descripcion, clave_actual):
    """
    Comprueba si la descripción contiene señales técnicas propias del
    grupo/subgrupo actual. Dos señales dan protección fuerte; una señal
    especialmente distintiva también puede bastar.
    """
    patrones = PATRONES_CONTEXTO_ACTUAL.get(clave_actual, [])
    if not patrones:
        return False, []

    texto = normalizar(descripcion)
    encontrados = []

    for patron in patrones:
        if re.search(patron, texto, flags=re.IGNORECASE):
            encontrados.append(patron)

    # Una sola señal es suficiente en familias cuyos indicadores son
    # muy distintivos; en el resto se piden dos.
    familias_una_senal = {
        ("02", "19"),  # UL/FM o ranurado
        ("06", "04"),  # espiga / flare / garras
        ("15", "01"),  # herramienta al inicio
        ("20", "03"),  # conduit / UNY / Crouse-Hinds
        ("40", "09"),  # EPP / arco eléctrico
        ("61", "05"),  # frenos
    }

    minimo = 1 if clave_actual in familias_una_senal else 2
    return len(encontrados) >= minimo, encontrados


def termino_candidato_es_unidad_o_atributo(descripcion, perfil_candidato):
    """
    Evita que unidades, materiales o atributos secundarios se conviertan
    en el objeto principal. Caso típico: 20 CAL/CM2 no es 'CAL' material.
    """
    desc = normalizar(descripcion)
    nombre = normalizar(perfil_candidato.get("nombre_subgrupo", ""))

    if nombre == "CAL":
        if re.search(r"\b\d+(?:\.\d+)?\s*CAL(?:\s*/\s*CM2|\b)", desc):
            return True
        if "ARCO ELECT" in desc:
            return True

    # CPVC/PVC por sí solos no deben convertir un ADAPTADOR en TUBERIA.
    if nombre in {"CPVC", "PVC", "PEAD", "TUBING"}:
        inicio = objeto_principal(descripcion).split()
        if inicio and inicio[0] in {
            "ADAPTADOR",
            "CONECTOR",
            "COPLE",
            "CODO",
            "TEE",
            "TAPON",
            "TUERCA",
            "VALVULA",
            "HERRAMIENTA",
            "CORTA",
            "CORTADOR",
            "CORTADORA",
        }:
            return True

    return False


def candidatos_permitidos(
    descripcion,
    um,
    clave_actual,
    perfiles,
):
    perfil_actual = perfiles.get(clave_actual)

    actual_servicio = articulo_actual_es_servicio(
        descripcion,
        um,
        perfil_actual,
    )

    resultado = {}

    for clave, perfil in perfiles.items():
        if es_servicio(perfil) != actual_servicio:
            continue
        resultado[clave] = perfil

    return resultado


def ranking_candidatos(
    descripcion,
    um,
    clave_actual,
    perfiles,
):
    permitidos = candidatos_permitidos(
        descripcion,
        um,
        clave_actual,
        perfiles,
    )

    perfil_actual = perfiles.get(clave_actual)
    resultados = []

    for clave, perfil in permitidos.items():
        datos = puntuar_perfil(descripcion, perfil)

        if datos["score"] <= 0:
            continue

        pierde_esp, especializaciones_perdidas = candidato_pierde_especializacion(
            descripcion,
            perfil_actual,
            perfil,
        )

        cambia_familia, familia_perdida = candidato_cambia_familia_respaldada(
            descripcion,
            perfil_actual,
            perfil,
        )

        mas_generico, especializacion_funcional = candidato_es_mas_generico(
            descripcion,
            perfil_actual,
            perfil,
        )

        score = datos["score"]

        if clave != clave_actual and pierde_esp:
            score *= 0.62
            datos["evidencias"].append(
                "PENALIZACION: pierde especializacion "
                + ", ".join(especializaciones_perdidas)
            )

        if clave != clave_actual and cambia_familia:
            score *= 0.58
            datos["evidencias"].append(
                "PENALIZACION: cambia familia tecnica respaldada "
                + ", ".join(familia_perdida[:4])
            )

        if clave != clave_actual and mas_generico:
            score *= 0.55
            datos["evidencias"].append(
                "PENALIZACION: pierde contexto especializado "
                + ", ".join(especializacion_funcional)
            )

        if (
            clave != clave_actual
            and objeto_es_herramienta_o_accesorio_funcional(descripcion)
            and datos["score_objeto"] < 0.62
        ):
            score *= 0.60
            datos["evidencias"].append(
                "PENALIZACION: termino tecnico pertenece al objeto de uso, "
                "no necesariamente al articulo principal"
            )

        contexto_fuerte, senales_contexto = contexto_actual_fuerte(
            descripcion,
            clave_actual,
        )

        if clave != clave_actual and contexto_fuerte:
            score *= 0.42
            datos["evidencias"].append(
                "PENALIZACION: contexto tecnico actual fuertemente respaldado"
            )

        if clave != clave_actual and termino_candidato_es_unidad_o_atributo(
            descripcion,
            perfil,
        ):
            score *= 0.25
            datos["evidencias"].append(
                "PENALIZACION: candidato detectado como unidad, material "
                "o atributo secundario"
            )

        resultados.append(
            {
                "clave": clave,
                "perfil": perfil,
                **datos,
                "score": score,
            }
        )

    resultados.sort(
        key=lambda x: x["score"],
        reverse=True,
    )

    return resultados


def evaluar_articulo(
    descripcion,
    grupo_actual,
    subgrupo_actual,
    um,
    perfiles,
    indice_historico,
):
    clave_actual = (
        normalizar_clave(grupo_actual),
        normalizar_clave(subgrupo_actual),
    )

    perfil_actual = perfiles.get(clave_actual)

    hist = evaluar_evidencia_historica(
        descripcion,
        clave_actual,
        indice_historico,
    )

    # --------------------------------------------------------
    # REGLAS DE NEGOCIO DIRECTAS
    # --------------------------------------------------------
    clave_directa, evidencia_directa = regla_negocio_directa(descripcion)

    if clave_directa:
        perfil_directo = perfiles.get(clave_directa)

        if perfil_directo:
            nombre_directo = (
                f'{perfil_directo["nombre_grupo"]} / '
                f'{perfil_directo["nombre_subgrupo"]}'
            )

            if clave_actual == clave_directa:
                return {
                    "resultado": "COINCIDE",
                    "observacion": "OK",
                    "subobservacion": "OK",
                    "score_actual": 1.0,
                    "score_sugerido": 1.0,
                    "grupo_sugerido": clave_directa[0],
                    "subgrupo_sugerido": clave_directa[1],
                    "nombre_sugerido": nombre_directo,
                    "evidencia": evidencia_directa,
                    "detalle": ("Regla directa de clasificación."),
                }

            subobs = (
                "GRUPO INCORRECTO"
                if clave_actual[0] != clave_directa[0]
                else "SUBGRUPO INCORRECTO"
            )

            return {
                "resultado": "CLASIFICACION INCORRECTA",
                "observacion": "CLASIFICACION",
                "subobservacion": subobs,
                "score_actual": 0.0,
                "score_sugerido": 1.0,
                "grupo_sugerido": clave_directa[0],
                "subgrupo_sugerido": clave_directa[1],
                "nombre_sugerido": nombre_directo,
                "evidencia": evidencia_directa,
                "detalle": ("Regla directa de clasificación."),
            }

    ranking = ranking_candidatos(
        descripcion,
        um,
        clave_actual,
        perfiles,
    )

    actual = next(
        (r for r in ranking if r["clave"] == clave_actual),
        None,
    )

    score_actual = actual["score"] if actual else 0.0

    if not ranking:
        respaldo_actual, evidencias_actual = evidencia_actual_suficiente(
            descripcion,
            perfil_actual,
            clave_actual,
        )

        historico_confirma_actual = (
            hist["actual_score"] >= HIST_CONSENSO_FUERTE
            and hist["actual_count"] >= 1
            and hist["neg_grupo_actual"] < 0.55
            and hist["neg_subgrupo_actual"] < 0.55
        )

        if (respaldo_actual or historico_confirma_actual) and perfil_actual:
            return {
                "resultado": "COINCIDE",
                "observacion": "OK",
                "subobservacion": "OK",
                "score_actual": 0.0,
                "score_sugerido": 0.0,
                "grupo_sugerido": clave_actual[0],
                "subgrupo_sugerido": clave_actual[1],
                "nombre_sugerido": (
                    f'{perfil_actual["nombre_grupo"]} / '
                    f'{perfil_actual["nombre_subgrupo"]}'
                ),
                "evidencia": "; ".join(
                    evidencias_actual + ([hist["detalle"]] if hist["detalle"] else [])
                ),
                "detalle": (
                    "No apareció una alternativa competitiva y la "
                    "clasificación actual está respaldada por la "
                    "descripción y/o antecedentes manualmente revisados."
                ),
            }

        # Si no hay candidatos del catálogo/histórico suficientemente
        # competitivos, no se considera un error: se conserva la
        # clasificación actual, de acuerdo con la regla de negocio validada.
        return {
            "resultado": "COINCIDE",
            "observacion": "OK",
            "subobservacion": "OK",
            "score_actual": 0.0,
            "score_sugerido": 0.0,
            "grupo_sugerido": clave_actual[0],
            "subgrupo_sugerido": clave_actual[1],
            "nombre_sugerido": (
                f'{perfil_actual["nombre_grupo"]} / '
                f'{perfil_actual["nombre_subgrupo"]}'
                if perfil_actual
                else ""
            ),
            "evidencia": hist["detalle"],
            "detalle": (
                "No se encontró evidencia suficiente de una clasificación "
                "incorrecta. Se conserva y valida el Grupo/Subgrupo actual."
            ),
        }

    mejor = ranking[0]
    segundo = ranking[1] if len(ranking) > 1 else None

    score_mejor = mejor["score"]
    score_segundo = segundo["score"] if segundo else 0.0

    grupo_sugerido, subgrupo_sugerido = mejor["clave"]
    perfil_mejor = mejor["perfil"]

    nombre_sugerido = (
        f'{perfil_mejor["nombre_grupo"]} / ' f'{perfil_mejor["nombre_subgrupo"]}'
    )

    if mejor["clave"] == clave_actual:
        respaldo_actual, evidencias_actual = evidencia_actual_suficiente(
            descripcion,
            perfil_actual,
            clave_actual,
        )

        if (
            score_mejor >= UMBRAL_REVISAR
            or (mejor["ancla"] and score_mejor >= 0.20)
            or respaldo_actual
            or (
                hist["actual_score"] >= HIST_CONSENSO_FUERTE
                and hist["neg_grupo_actual"] < 0.55
                and hist["neg_subgrupo_actual"] < 0.55
            )
        ):
            return {
                "resultado": "COINCIDE",
                "observacion": "OK",
                "subobservacion": "OK",
                "score_actual": score_actual,
                "score_sugerido": score_mejor,
                "grupo_sugerido": grupo_sugerido,
                "subgrupo_sugerido": subgrupo_sugerido,
                "nombre_sugerido": nombre_sugerido,
                "evidencia": "; ".join(
                    mejor["evidencias"]
                    + evidencias_actual
                    + ([hist["detalle"]] if hist["detalle"] else [])
                ),
                "detalle": (
                    "La clasificación actual es la mejor respaldada "
                    "por objeto, contexto, plantilla o familia técnica."
                ),
            }

        return {
            "resultado": "REVISAR",
            "observacion": "",
            "subobservacion": "",
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "La clasificación actual parece la mejor, "
                "pero la evidencia es limitada."
            ),
        }

    diferencia = score_mejor - score_actual
    margen = score_mejor - score_segundo

    origen_generico = clave_actual in CLASIFICACIONES_GENERICAS

    # --------------------------------------------------------
    # EVIDENCIA HISTORICA CONSERVADORA
    # --------------------------------------------------------
    historico_actual_fuerte = (
        hist["actual_score"] >= HIST_CONSENSO_FUERTE
        and hist["actual_score"] >= hist["mejor_score"] - 0.05
        and hist["neg_grupo_actual"] < 0.55
        and hist["neg_subgrupo_actual"] < 0.55
    )

    historico_alternativa_fuerte = (
        hist["mejor_clave"] is not None
        and hist["mejor_clave"] != clave_actual
        and hist["mejor_score"] >= HIST_CONSENSO_FUERTE
        and (hist["mejor_score"] - hist["actual_score"] >= HIST_MARGEN_MINIMO)
        and (hist["mejor_score"] - hist["segundo_score"] >= 0.05)
    )

    historico_actual_negativo = (
        hist["neg_grupo_actual"] >= HIST_SIM_FUERTE
        or hist["neg_subgrupo_actual"] >= HIST_SIM_FUERTE
    )

    if historico_actual_fuerte:
        return {
            "resultado": "COINCIDE",
            "observacion": "OK",
            "subobservacion": "OK",
            "score_actual": max(score_actual, hist["actual_score"]),
            "score_sugerido": max(score_actual, hist["actual_score"]),
            "grupo_sugerido": clave_actual[0],
            "subgrupo_sugerido": clave_actual[1],
            "nombre_sugerido": (
                f'{perfil_actual["nombre_grupo"]} / '
                f'{perfil_actual["nombre_subgrupo"]}'
                if perfil_actual
                else ""
            ),
            "evidencia": hist["detalle"],
            "detalle": (
                "Antecedentes manualmente revisados y suficientemente "
                "similares respaldan la clasificación actual."
            ),
        }

    # El histórico por sí solo no marca error salvo que, además de existir
    # un consenso positivo para otra clasificación, existan antecedentes
    # negativos parecidos contra la clasificación actual.
    if (
        historico_alternativa_fuerte
        and historico_actual_negativo
        and hist["mejor_count"] >= 1
    ):
        clave_hist = hist["mejor_clave"]
        perfil_hist = perfiles.get(clave_hist)

        if perfil_hist:
            subobs_hist = (
                "GRUPO INCORRECTO"
                if clave_hist[0] != clave_actual[0]
                else "SUBGRUPO INCORRECTO"
            )

            return {
                "resultado": "CLASIFICACION INCORRECTA",
                "observacion": "CLASIFICACION",
                "subobservacion": subobs_hist,
                "score_actual": score_actual,
                "score_sugerido": hist["mejor_score"],
                "grupo_sugerido": clave_hist[0],
                "subgrupo_sugerido": clave_hist[1],
                "nombre_sugerido": (
                    f'{perfil_hist["nombre_grupo"]} / '
                    f'{perfil_hist["nombre_subgrupo"]}'
                ),
                "evidencia": hist["detalle"],
                "detalle": (
                    "El histórico contiene antecedentes similares que "
                    "respaldan otra clasificación y, simultáneamente, "
                    "antecedentes que rechazan la clasificación actual."
                ),
            }

    pierde_esp, perdidas = candidato_pierde_especializacion(
        descripcion,
        perfil_actual,
        perfil_mejor,
    )

    cambia_familia, familia_perdida = candidato_cambia_familia_respaldada(
        descripcion,
        perfil_actual,
        perfil_mejor,
    )

    mas_generico, contexto_perdido = candidato_es_mas_generico(
        descripcion,
        perfil_actual,
        perfil_mejor,
    )

    if pierde_esp:
        return {
            "resultado": "REVISAR",
            "observacion": "",
            "subobservacion": "",
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "La alternativa parece plausible, pero perdería "
                "una especialización presente en la descripción: "
                + ", ".join(perdidas)
                + ". No se marca automáticamente."
            ),
        }

    if cambia_familia or mas_generico:
        motivos = []
        if cambia_familia:
            motivos.append(
                "familia tecnica actual respaldada: " + ", ".join(familia_perdida[:4])
            )
        if mas_generico:
            motivos.append("especializacion actual: " + ", ".join(contexto_perdido))

        return {
            "resultado": "REVISAR",
            "observacion": "",
            "subobservacion": "",
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "La alternativa coincide con parte del objeto, pero "
                "no se marca automáticamente porque la clasificación "
                "actual conserva contexto técnico relevante ("
                + "; ".join(motivos)
                + ")."
            ),
        }

    contexto_fuerte, senales_contexto = contexto_actual_fuerte(
        descripcion,
        clave_actual,
    )

    if contexto_fuerte:
        return {
            "resultado": "COINCIDE",
            "observacion": "OK",
            "subobservacion": "OK",
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "La clasificación actual contiene contexto técnico "
                "específico respaldado por la descripción; la alternativa "
                "detectada es más genérica y no sustituye esa especialización."
            ),
        }

    if termino_candidato_es_unidad_o_atributo(
        descripcion,
        perfil_mejor,
    ):
        return {
            "resultado": "REVISAR",
            "observacion": "",
            "subobservacion": "",
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "El término que impulsa la alternativa parece funcionar "
                "como unidad, material, aplicación o atributo secundario, "
                "no como artículo principal."
            ),
        }

    fuerte_general = (
        mejor["ancla"]
        and mejor["score_objeto"] >= 0.48
        and score_mejor >= UMBRAL_MARCAR
        and diferencia >= MARGEN_MINIMO
        and margen >= 0.10
    )

    fuerte_desde_generico = (
        origen_generico
        and mejor["ancla"]
        and mejor["score_objeto"] >= 0.62
        and score_mejor >= 0.68
        and diferencia >= 0.18
    )

    es_fuerte = fuerte_general or fuerte_desde_generico

    if es_fuerte:
        subobs = (
            "GRUPO INCORRECTO"
            if grupo_sugerido != clave_actual[0]
            else "SUBGRUPO INCORRECTO"
        )

        return {
            "resultado": "CLASIFICACION INCORRECTA",
            "observacion": "CLASIFICACION",
            "subobservacion": subobs,
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "La alternativa identifica claramente el objeto "
                "principal y supera la clasificación actual sin "
                "perder especialización relevante."
            ),
        }

    if (
        mejor["ancla"]
        and mejor["score_objeto"] >= 0.48
        and score_mejor >= UMBRAL_REVISAR
    ):
        return {
            "resultado": "REVISAR",
            "observacion": "",
            "subobservacion": "",
            "score_actual": score_actual,
            "score_sugerido": score_mejor,
            "grupo_sugerido": grupo_sugerido,
            "subgrupo_sugerido": subgrupo_sugerido,
            "nombre_sugerido": nombre_sugerido,
            "evidencia": "; ".join(mejor["evidencias"]),
            "detalle": (
                "Existe una alternativa plausible, pero no cumple "
                "los criterios para marcarla automáticamente."
            ),
        }

    respaldo_actual, evidencias_actual = evidencia_actual_suficiente(
        descripcion,
        perfil_actual,
        clave_actual,
    )

    if respaldo_actual and (
        not mejor["ancla"]
        or mejor["score_objeto"] < 0.48
        or score_mejor < UMBRAL_REVISAR
    ):
        return {
            "resultado": "COINCIDE",
            "observacion": "OK",
            "subobservacion": "OK",
            "score_actual": score_actual,
            "score_sugerido": score_actual,
            "grupo_sugerido": clave_actual[0],
            "subgrupo_sugerido": clave_actual[1],
            "nombre_sugerido": (
                f'{perfil_actual["nombre_grupo"]} / '
                f'{perfil_actual["nombre_subgrupo"]}'
                if perfil_actual
                else ""
            ),
            "evidencia": "; ".join(evidencias_actual),
            "detalle": (
                "La clasificación actual está respaldada por la "
                "descripción y no existe una alternativa suficientemente "
                "fuerte para desplazarla."
            ),
        }

    if (
        hist["actual_score"] >= HIST_SIM_FUERTE
        and hist["neg_grupo_actual"] < 0.55
        and hist["neg_subgrupo_actual"] < 0.55
        and perfil_actual
    ):
        return {
            "resultado": "COINCIDE",
            "observacion": "OK",
            "subobservacion": "OK",
            "score_actual": max(score_actual, hist["actual_score"]),
            "score_sugerido": max(score_actual, hist["actual_score"]),
            "grupo_sugerido": clave_actual[0],
            "subgrupo_sugerido": clave_actual[1],
            "nombre_sugerido": (
                f'{perfil_actual["nombre_grupo"]} / '
                f'{perfil_actual["nombre_subgrupo"]}'
            ),
            "evidencia": hist["detalle"],
            "detalle": (
                "La evidencia técnica directa es limitada, pero existen "
                "antecedentes manualmente revisados suficientemente "
                "similares que respaldan la clasificación actual."
            ),
        }

    if historico_alternativa_fuerte:
        clave_hist = hist["mejor_clave"]
        perfil_hist = perfiles.get(clave_hist)

        return {
            "resultado": "REVISAR",
            "observacion": "",
            "subobservacion": "",
            "score_actual": score_actual,
            "score_sugerido": hist["mejor_score"],
            "grupo_sugerido": clave_hist[0],
            "subgrupo_sugerido": clave_hist[1],
            "nombre_sugerido": (
                f'{perfil_hist["nombre_grupo"]} / ' f'{perfil_hist["nombre_subgrupo"]}'
                if perfil_hist
                else ""
            ),
            "evidencia": hist["detalle"],
            "detalle": (
                "El histórico sugiere otra clasificación con fuerza, "
                "pero no existe evidencia negativa suficiente contra la "
                "clasificación actual para marcarla automáticamente."
            ),
        }

    # REGLA DE NEGOCIO FINAL:
    # Si no existe evidencia suficiente para afirmar que la clasificación
    # actual es incorrecta ni un conflicto real que amerite REVISAR,
    # se respeta el Grupo/Subgrupo asignado actualmente.
    #
    # En este módulo, la ausencia de evidencia de error NO significa
    # "NO EVALUABLE"; significa que la clasificación actual se considera
    # aceptable y pasa a COINCIDE.
    return {
        "resultado": "COINCIDE",
        "observacion": "OK",
        "subobservacion": "OK",
        "score_actual": score_actual,
        "score_sugerido": score_actual,
        "grupo_sugerido": clave_actual[0],
        "subgrupo_sugerido": clave_actual[1],
        "nombre_sugerido": (
            f'{perfil_actual["nombre_grupo"]} / ' f'{perfil_actual["nombre_subgrupo"]}'
            if perfil_actual
            else ""
        ),
        "evidencia": hist["detalle"],
        "detalle": (
            "No se encontró evidencia suficiente de una clasificación "
            "incorrecta. Se conserva y valida el Grupo/Subgrupo actual."
        ),
    }


def localizar_columnas(df):
    mapa = {}

    for col in df.columns:
        mapa[normalizar(col)] = col

    requeridas = [
        "CODIGO",
        "ESTADO",
        "GRUPO",
        "SUBGRUPO",
        "DESCRIPCION",
    ]

    faltantes = [c for c in requeridas if c not in mapa]

    if faltantes:
        raise ValueError("Faltan columnas requeridas: " + ", ".join(faltantes))

    return mapa


def procesar():
    entrada = buscar_archivo_resultado()
    salida = nombre_salida(entrada)

    print("=" * 78)
    print("DIAGNOSTICO DE CLASIFICACION - CONTEXTUAL + HISTORICO V6.2.1")
    print("=" * 78)
    print(f"Entrada: {entrada}")
    print(f"Base de datos: {DB_PATH}")
    print()

    catalogo, campos = cargar_catalogo()
    perfiles = construir_perfiles(catalogo, campos)

    historico = cargar_revisiones_historicas()
    indice_historico = construir_indice_historico(historico)

    print(f"Clasificaciones disponibles: {len(perfiles)}")
    print(f"Revisiones historicas SQLite: {len(historico)}")
    print("Excel historicos externos: NO SE CONSULTAN " "(solo base_datos.db)")
    print("Modelo: familia -> objeto principal -> especializacion -> caracteristicas")
    print()

    df = pd.read_excel(
        entrada,
        dtype=str,
        engine="openpyxl",
    )

    mapa = localizar_columnas(df)

    c_codigo = mapa["CODIGO"]
    c_estado = mapa["ESTADO"]
    c_grupo = mapa["GRUPO"]
    c_subgrupo = mapa["SUBGRUPO"]
    c_desc = mapa["DESCRIPCION"]
    c_um = mapa.get("UM")

    nuevos = df[df[c_estado].astype(str).str.strip().str.upper().eq("NUEVO")].copy()

    resultados = []

    for _, fila in nuevos.iterrows():
        codigo = normalizar_codigo(fila[c_codigo])
        grupo = normalizar_clave(fila[c_grupo])
        subgrupo = normalizar_clave(fila[c_subgrupo])

        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])

        um = "" if c_um is None or pd.isna(fila[c_um]) else str(fila[c_um])

        evaluacion = evaluar_articulo(
            descripcion,
            grupo,
            subgrupo,
            um,
            perfiles,
            indice_historico,
        )

        perfil_actual = perfiles.get(
            (grupo, subgrupo),
            {},
        )

        hist_fila = evaluar_evidencia_historica(
            descripcion,
            (grupo, subgrupo),
            indice_historico,
        )

        especializaciones = detectar_especializaciones(descripcion)

        resultados.append(
            {
                "Codigo": codigo,
                "Grupo actual": grupo,
                "Subgrupo actual": subgrupo,
                "Nombre grupo actual": perfil_actual.get(
                    "nombre_grupo",
                    "",
                ),
                "Nombre subgrupo actual": perfil_actual.get(
                    "nombre_subgrupo",
                    "",
                ),
                "UM": um,
                "Objeto principal detectado": objeto_principal(descripcion),
                "Especializaciones detectadas": ", ".join(especializaciones),
                "Descripción": descripcion,
                "Resultado": evaluacion["resultado"],
                "Observación propuesta": evaluacion["observacion"],
                "Subobservación propuesta": evaluacion["subobservacion"],
                "Grupo sugerido": evaluacion["grupo_sugerido"],
                "Subgrupo sugerido": evaluacion["subgrupo_sugerido"],
                "Clasificación sugerida": evaluacion["nombre_sugerido"],
                "Puntaje actual": round(
                    evaluacion["score_actual"] * 100,
                    1,
                ),
                "Puntaje sugerido": round(
                    evaluacion["score_sugerido"] * 100,
                    1,
                ),
                "Histórico respalda actual": round(
                    hist_fila["actual_score"] * 100,
                    1,
                ),
                "Mejor histórico": (
                    (f'{hist_fila["mejor_clave"][0]}/' f'{hist_fila["mejor_clave"][1]}')
                    if hist_fila["mejor_clave"]
                    else ""
                ),
                "Puntaje mejor histórico": round(
                    hist_fila["mejor_score"] * 100,
                    1,
                ),
                "Histórico contra grupo actual": round(
                    hist_fila["neg_grupo_actual"] * 100,
                    1,
                ),
                "Histórico contra subgrupo actual": round(
                    hist_fila["neg_subgrupo_actual"] * 100,
                    1,
                ),
                "Ejemplos históricos": (hist_fila.get("ejemplos_mejor_txt", "")),
                "Evidencia": evaluacion["evidencia"],
                "Detalle": evaluacion["detalle"],
            }
        )

    resultado_df = pd.DataFrame(resultados)

    incorrectos = resultado_df[
        resultado_df["Resultado"].eq("CLASIFICACION INCORRECTA")
    ].copy()

    revisar = resultado_df[resultado_df["Resultado"].eq("REVISAR")].copy()

    coincide = resultado_df[resultado_df["Resultado"].eq("COINCIDE")].copy()

    no_evaluable = resultado_df[resultado_df["Resultado"].eq("NO EVALUABLE")].copy()

    conteos = Counter(resultado_df["Resultado"])

    grupo_incorrecto = int(
        (resultado_df["Subobservación propuesta"] == "GRUPO INCORRECTO").sum()
    )

    subgrupo_incorrecto = int(
        (resultado_df["Subobservación propuesta"] == "SUBGRUPO INCORRECTO").sum()
    )

    resumen_df = pd.DataFrame(
        [
            ["Articulos NUEVO analizados", len(resultado_df)],
            [
                "CLASIFICACION INCORRECTA",
                conteos.get("CLASIFICACION INCORRECTA", 0),
            ],
            ["GRUPO INCORRECTO", grupo_incorrecto],
            ["SUBGRUPO INCORRECTO", subgrupo_incorrecto],
            ["COINCIDE", conteos.get("COINCIDE", 0)],
            ["REVISAR", conteos.get("REVISAR", 0)],
            ["NO EVALUABLE", conteos.get("NO EVALUABLE", 0)],
        ],
        columns=["Concepto", "Resultado"],
    )

    with pd.ExcelWriter(
        salida,
        engine="openpyxl",
    ) as writer:
        resumen_df.to_excel(
            writer,
            sheet_name="RESUMEN",
            index=False,
        )
        incorrectos.to_excel(
            writer,
            sheet_name="CLASIFICACION INCORRECTA",
            index=False,
        )
        revisar.to_excel(
            writer,
            sheet_name="REVISAR",
            index=False,
        )
        coincide.to_excel(
            writer,
            sheet_name="COINCIDE",
            index=False,
        )
        no_evaluable.to_excel(
            writer,
            sheet_name="NO EVALUABLE",
            index=False,
        )
        resultado_df.to_excel(
            writer,
            sheet_name="DIAGNOSTICO",
            index=False,
        )

        for hoja in writer.book.worksheets:
            hoja.freeze_panes = "A2"
            hoja.auto_filter.ref = hoja.dimensions

            for columna in hoja.columns:
                letra = columna[0].column_letter
                max_len = 0

                for celda in columna:
                    valor = "" if celda.value is None else str(celda.value)
                    max_len = max(
                        max_len,
                        min(len(valor), 80),
                    )

                hoja.column_dimensions[letra].width = max(
                    12,
                    min(max_len + 2, 60),
                )

    print("Diagnostico terminado correctamente.")
    print("-" * 78)
    print(f"Articulos NUEVO analizados:          {len(resultado_df)}")
    print(
        "CLASIFICACION INCORRECTA:           "
        f"{conteos.get('CLASIFICACION INCORRECTA', 0)}"
    )
    print(f"  - GRUPO INCORRECTO:                {grupo_incorrecto}")
    print(f"  - SUBGRUPO INCORRECTO:             {subgrupo_incorrecto}")
    print("COINCIDE:                            " f"{conteos.get('COINCIDE', 0)}")
    print("REVISAR:                             " f"{conteos.get('REVISAR', 0)}")
    print("NO EVALUABLE:                        " f"{conteos.get('NO EVALUABLE', 0)}")
    print()
    print("Archivo generado:")
    print(salida)
    print("=" * 78)


if __name__ == "__main__":
    procesar()
