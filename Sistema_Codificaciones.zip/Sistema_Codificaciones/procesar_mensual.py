import sqlite3
from openpyxl import load_workbook, Workbook

# ========================================
# CONFIGURACIÓN
# ========================================

ARCHIVO_EXCEL = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION\HISTORICO CODIFICACION.xlsx"
)

HOJA_MES = "MES ACTUAL"
HOJA_ORIGINAL = "ORIGINAL"

MES_PROCESO = "SEPTIEMBRE"

ARCHIVO_RESULTADO = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION\RESULTADO_SEPTIEMBRE.xlsx"
)


# ========================================
# FUNCIONES
# ========================================


def limpiar_codigo(valor):

    if valor is None:
        return ""

    if isinstance(valor, float) and valor.is_integer():
        valor = int(valor)

    return str(valor).strip()


def buscar_columnas(hoja):

    columnas = {}

    for celda in hoja[1]:

        if celda.value is None:
            continue

        nombre = str(celda.value).strip().upper()

        columnas[nombre] = celda.column

    return columnas


# ========================================
# INICIO
# ========================================

print("=" * 60)
print("        GENERACIÓN DE REPORTE MENSUAL")
print("=" * 60)


# ========================================
# ABRIR EXCEL
# ========================================

print("\nAbriendo archivo Excel...")

libro = load_workbook(ARCHIVO_EXCEL, data_only=False)

hoja_mes = libro[HOJA_MES]
hoja_original = libro[HOJA_ORIGINAL]


# ========================================
# COLUMNAS MES ACTUAL
# ========================================

columnas_mes = buscar_columnas(hoja_mes)

columna_codigo = None
columna_estado = None

for nombre, columna in columnas_mes.items():

    if nombre in ["CODIGO", "CODIGOS", "CÓDIGO", "CÓDIGOS"]:
        columna_codigo = columna

    elif nombre == "ESTADO":
        columna_estado = columna


if columna_codigo is None:

    print("\nERROR: No se encontró la columna de códigos.")
    input("\nPresiona ENTER para salir...")
    exit()


if columna_estado is None:

    print("\nERROR: No se encontró la columna ESTADO.")
    input("\nPresiona ENTER para salir...")
    exit()


print(f"Columna de códigos: {columna_codigo}")
print(f"Columna ESTADO:     {columna_estado}")


# ========================================
# COLUMNAS ORIGINAL
# ========================================

print("\nIdentificando columnas de ORIGINAL...")

columnas_original = buscar_columnas(hoja_original)

col_codigo = columnas_original.get("CODIGO")
col_grupo = columnas_original.get("GRUPO")
col_subgrupo = columnas_original.get("SUBGRUPO")

col_descripcion = columnas_original.get("DESCRIPCION") or columnas_original.get(
    "DESCRIPCIÓN"
)

col_usuario = columnas_original.get("USUARIO")
col_um = columnas_original.get("UM")


if col_codigo is None:

    print("\nERROR: No se encontró Codigo en ORIGINAL.")
    input("\nPresiona ENTER para salir...")
    exit()


print(f"Codigo:       columna {col_codigo}")
print(f"Grupo:        columna {col_grupo}")
print(f"Subgrupo:     columna {col_subgrupo}")
print(f"Descripción:  columna {col_descripcion}")
print(f"Usuario:      columna {col_usuario}")
print(f"UM:           columna {col_um}")


# ========================================
# CARGAR ORIGINAL
# ========================================

print("\nCargando artículos de ORIGINAL...")

articulos_original = {}

for fila in range(2, hoja_original.max_row + 1):

    codigo = limpiar_codigo(hoja_original.cell(fila, col_codigo).value)

    if codigo == "":
        continue

    articulos_original[codigo] = {
        "grupo": hoja_original.cell(fila, col_grupo).value,
        "subgrupo": hoja_original.cell(fila, col_subgrupo).value,
        "descripcion": hoja_original.cell(fila, col_descripcion).value,
        "usuario": hoja_original.cell(fila, col_usuario).value,
        "um": hoja_original.cell(fila, col_um).value,
    }


print(f"Artículos disponibles en ORIGINAL: " f"{len(articulos_original)}")


# ========================================
# CARGAR BASE DE DATOS
# ========================================

print("\nCargando base histórica...")

conexion = sqlite3.connect("base_datos.db")
cursor = conexion.cursor()

cursor.execute("""
    SELECT codigo, mes
    FROM articulos_historico
""")

registros_bd = cursor.fetchall()

codigos_bd = {}

for codigo, mes in registros_bd:

    codigo = limpiar_codigo(codigo)

    codigos_bd[codigo] = mes


print(f"Códigos acumulados en la base: " f"{len(codigos_bd)}")


# ========================================
# CREAR LIBRO NUEVO
# ========================================

print("\nPreparando reporte de códigos NUEVOS...")

libro_resultado = Workbook()

hoja_resultado = libro_resultado.active
hoja_resultado.title = MES_PROCESO


# ========================================
# ENCABEZADOS DEL REPORTE
# ========================================

encabezados = [
    "Codigo",
    "Estado",
    "Grupo",
    "Subgrupo",
    "Descripción",
    "Usuario",
    "UM",
    "OBSERVACION",
    "SUBOBSERVACION",
]

for columna, encabezado in enumerate(encabezados, start=1):

    hoja_resultado.cell(1, columna).value = encabezado


# ========================================
# PROCESAR MES
# ========================================

total = 0
nuevos = 0
ya_existian = 0
vacios = 0

encontrados_original = 0
no_encontrados_original = 0


for fila in range(2, hoja_mes.max_row + 1):

    valor_codigo = hoja_mes.cell(fila, columna_codigo).value

    codigo = limpiar_codigo(valor_codigo)

    # ------------------------------------
    # CÓDIGO VACÍO
    # ------------------------------------

    if codigo == "":
        vacios += 1
        continue

    total += 1

    # ------------------------------------
    # DETERMINAR ESTADO
    # ------------------------------------

    if codigo not in codigos_bd:

        estado = "NUEVO"

    elif codigos_bd[codigo] == MES_PROCESO:

        # Fue cargado este mes como código NUEVO
        estado = "NUEVO"

    else:

        estado = "YA EXISTIA"

    # ------------------------------------
    # CONTADORES
    # ------------------------------------

    if estado == "NUEVO":

        nuevos += 1

    else:

        ya_existian += 1

    # ------------------------------------
    # SOLO LOS NUEVOS ENTRAN AL REPORTE
    # ------------------------------------

    if estado != "NUEVO":
        continue

    # ------------------------------------
    # BUSCAR INFORMACIÓN EN ORIGINAL
    # ------------------------------------

    articulo = articulos_original.get(codigo)

    if articulo is not None:

        encontrados_original += 1

        grupo = articulo["grupo"]
        subgrupo = articulo["subgrupo"]
        descripcion = articulo["descripcion"]
        usuario = articulo["usuario"]
        um = articulo["um"]

    else:

        no_encontrados_original += 1

        grupo = ""
        subgrupo = ""
        descripcion = ""
        usuario = ""
        um = ""

    # ------------------------------------
    # ESCRIBIR NUEVO REGISTRO
    # ------------------------------------

    nueva_fila = hoja_resultado.max_row + 1

    datos = [
        codigo,
        "NUEVO",
        grupo,
        subgrupo,
        descripcion,
        usuario,
        um,
        "",
        "",
    ]

    for columna, valor in enumerate(datos, start=1):

        hoja_resultado.cell(nueva_fila, columna).value = valor


# ========================================
# AJUSTAR ANCHOS
# ========================================

anchos = {
    "A": 14,
    "B": 14,
    "C": 12,
    "D": 15,
    "E": 80,
    "F": 15,
    "G": 10,
    "H": 25,
    "I": 25,
}

for columna, ancho in anchos.items():

    hoja_resultado.column_dimensions[columna].width = ancho


# ========================================
# CONGELAR ENCABEZADOS
# ========================================

hoja_resultado.freeze_panes = "A2"


# ========================================
# GUARDAR
# ========================================

print("\nGuardando reporte...")

libro_resultado.save(ARCHIVO_RESULTADO)

conexion.close()


# ========================================
# RESULTADO
# ========================================

print("\n" + "=" * 60)
print("          RESULTADO DEL PROCESAMIENTO")
print("=" * 60)

print(f"Códigos procesados:              {total}")

print(f"Códigos NUEVOS:                  {nuevos}")

print(f"Códigos YA EXISTÍAN:             {ya_existian}")

print(f"Celdas vacías:                   {vacios}")

print("-" * 60)

print(f"Nuevos encontrados ORIGINAL:     " f"{encontrados_original}")

print(f"Nuevos NO encontrados ORIGINAL:  " f"{no_encontrados_original}")

print("=" * 60)

print("\nArchivo generado:")

print(ARCHIVO_RESULTADO)

print("\nEl Excel original NO fue modificado.")
print("La base de datos NO fue modificada.")

input("\nPresiona ENTER para salir...")
