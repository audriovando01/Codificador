import sqlite3

conexion = sqlite3.connect("base_datos.db")
cursor = conexion.cursor()

# ============================================================
# TABLA DE REVISIONES REALIZADAS POR LA IA
# ============================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS revisiones_ia (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT,
    descripcion TEXT,
    grupo TEXT,
    subgrupo TEXT,
    observacion TEXT,
    subobservacion TEXT,
    confianza REAL,
    motivo TEXT,
    severidad TEXT,
    fecha TEXT
)
""")

# ============================================================
# TABLA DE DECISIONES DEL USUARIO
# ============================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS decisiones_usuario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT,
    descripcion TEXT,
    grupo TEXT,
    subgrupo TEXT,
    observacion_ia TEXT,
    subobservacion_ia TEXT,
    confianza_ia REAL,
    decision_usuario TEXT,
    comentario TEXT,
    fecha TEXT
)
""")

# ============================================================
# TABLA DE CATÁLOGO DE OBSERVACIONES
# ============================================================

cursor.execute("""
CREATE TABLE IF NOT EXISTS catalogo_observaciones (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    observacion TEXT NOT NULL,
    subobservacion TEXT NOT NULL,
    UNIQUE(observacion, subobservacion)
)
""")

# ============================================================
# INSERTAR CATÁLOGO OFICIAL
# ============================================================

observaciones = [
    ("CLASIFICACION", "GRUPO INCORRECTO"),
    ("CLASIFICACION", "SUBGRUPO INCORRECTO"),
    ("DUPLICADO", "ARTICULO DUPLICADO"),
    ("ESPECIFICACION TECNICA", "SOBRE-ESPECIFICADO"),
    ("ESPECIFICACION TECNICA", "SUB-ESPECIFICADO"),
    ("ESPECIFICACION TECNICA", "LLENADO INADECUADO DE PLANTILLA"),
    ("ORTOGRAFIA", "PALABRA DUPLICADA"),
    ("ORTOGRAFIA", "USO DE MINUSCULAS"),
    ("ORTOGRAFIA", "FALTA DE CARACTERES DE UNIDADES DE MEDIDA"),
    ("ORTOGRAFIA", "REDACCION INCORRECTA"),
    ("ORTOGRAFIA", "USO INCORRECTO DE CARACTERES"),
    ("OK", "OK"),
]

cursor.executemany(
    """
INSERT OR IGNORE INTO catalogo_observaciones
(observacion, subobservacion)
VALUES (?, ?)
""",
    observaciones,
)

conexion.commit()

# ============================================================
# VERIFICACION
# ============================================================

print("=" * 60)
print("TABLAS DE IA CREADAS CORRECTAMENTE")
print("=" * 60)

cursor.execute("""
SELECT observacion, subobservacion
FROM catalogo_observaciones
ORDER BY id
""")

registros = cursor.fetchall()

print(f"Observaciones/subobservaciones registradas: {len(registros)}")
print()

for observacion, subobservacion in registros:
    print(f"{observacion} -> {subobservacion}")

conexion.close()
