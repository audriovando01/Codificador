import sqlite3

conexion = sqlite3.connect("base_datos.db")
cursor = conexion.cursor()

print("=" * 60)
print("VERIFICACION DE BASE DE DATOS IA")
print("=" * 60)

cursor.execute("""
SELECT name
FROM sqlite_master
WHERE type = 'table'
ORDER BY name
""")

tablas = cursor.fetchall()

print("\nTablas encontradas:")

for tabla in tablas:
    print(f"- {tabla[0]}")

print("\n" + "-" * 60)

for tabla in [
    "articulos_historico",
    "revisiones_ia",
    "decisiones_usuario",
    "catalogo_observaciones",
]:

    cursor.execute(f"SELECT COUNT(*) FROM {tabla}")
    cantidad = cursor.fetchone()[0]

    print(f"{tabla}: {cantidad} registros")

conexion.close()
