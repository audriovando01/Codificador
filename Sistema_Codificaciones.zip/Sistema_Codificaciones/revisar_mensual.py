import re
from openpyxl import load_workbook

# ========================================
# CONFIGURACIÓN
# ========================================

ARCHIVO_RESULTADO = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION\RESULTADO_SEPTIEMBRE.xlsx"
)

# ========================================
# FUNCIONES
# ========================================


def limpiar_texto(valor):
    if valor is None:
        return ""

    return str(valor).strip()


def detectar_palabra_duplicada(texto):
    palabras = re.findall(r"\b[A-ZÁÉÍÓÚÜÑ]+\b", texto.upper())

    palabra_anterior = None

    for palabra in palabras:

        # La X se utiliza como separador
        # de dimensiones o extremos.
        if palabra == "X":
            palabra_anterior = None
            continue

        # Detectar únicamente palabras consecutivas iguales
        if palabra == palabra_anterior:
            return True, palabra

        palabra_anterior = palabra

    return False, ""


def detectar_minusculas(texto):
    letras = [c for c in texto if c.isalpha()]

    if not letras:
        return False

    return any(c.islower() for c in letras)


def detectar_caracteres_invalidos(texto):
    caracteres_invalidos = {"Ø", "ø", "¿", "?", "|", "®", "™"}

    encontrados = []

    for caracter in caracteres_invalidos:
        if caracter in texto:
            encontrados.append(caracter)

    return encontrados


# ========================================
# INICIO
# ========================================

print("=" * 60)
print("        REVISIÓN AUTOMÁTICA MENSUAL")
print("=" * 60)

print("\nAbriendo resultado mensual...")

libro = load_workbook(ARCHIVO_RESULTADO, data_only=False)

hoja = libro.active

print(f"Hoja procesada: {hoja.title}")
print(f"Registros encontrados: {hoja.max_row - 1}")


# ========================================
# IDENTIFICAR COLUMNAS
# ========================================

columnas = {}

for celda in hoja[1]:
    if celda.value is not None:
        columnas[str(celda.value).strip().upper()] = celda.column


col_descripcion = columnas.get("DESCRIPCIÓN")
if col_descripcion is None:
    col_descripcion = columnas.get("DESCRIPCION")

col_observacion = columnas.get("OBSERVACION")
col_subobservacion = columnas.get("SUBOBSERVACION")


if col_descripcion is None:
    print("\nERROR: No se encontró la columna DESCRIPCIÓN.")
    input("\nPresiona ENTER para salir...")
    exit()

if col_observacion is None:
    print("\nERROR: No se encontró la columna OBSERVACION.")
    input("\nPresiona ENTER para salir...")
    exit()

if col_subobservacion is None:
    print("\nERROR: No se encontró la columna SUBOBSERVACION.")
    input("\nPresiona ENTER para salir...")
    exit()


print(f"Descripción:    columna {col_descripcion}")
print(f"Observación:    columna {col_observacion}")
print(f"Subobservación: columna {col_subobservacion}")


# ========================================
# CONTADORES
# ========================================

total = 0
palabras_duplicadas = 0
minusculas = 0
caracteres_invalidos = 0


# ========================================
# REVISAR ARTÍCULOS
# ========================================

print("\nIniciando revisión...")
print("-" * 60)

for fila in range(2, hoja.max_row + 1):

    descripcion = limpiar_texto(hoja.cell(fila, col_descripcion).value)

    if descripcion == "":
        continue

    total += 1

    observaciones = []
    subobservaciones = []

    # ------------------------------------
    # PALABRA DUPLICADA
    # ------------------------------------

    duplicada, palabra = detectar_palabra_duplicada(descripcion)

    if duplicada:
        palabras_duplicadas += 1

        observaciones.append("ORTOGRAFIA")
        subobservaciones.append("PALABRA DUPLICADA")

    # ------------------------------------
    # USO DE MINÚSCULAS
    # ------------------------------------

    if detectar_minusculas(descripcion):
        minusculas += 1

        if "ORTOGRAFIA" not in observaciones:
            observaciones.append("ORTOGRAFIA")

        subobservaciones.append("USO DE MINUSCULAS")

    # ------------------------------------
    # CARACTERES INVÁLIDOS
    # ------------------------------------

    caracteres = detectar_caracteres_invalidos(descripcion)

    if caracteres:
        caracteres_invalidos += 1

        if "ORTOGRAFIA" not in observaciones:
            observaciones.append("ORTOGRAFIA")

        subobservaciones.append("INVALID CHARACTERS: " + ", ".join(caracteres))

    # ------------------------------------
    # ESCRIBIR RESULTADO
    # ------------------------------------

    hoja.cell(fila, col_observacion).value = ", ".join(observaciones)

    hoja.cell(fila, col_subobservacion).value = ", ".join(subobservaciones)


# ========================================
# GUARDAR
# ========================================

print("\nGuardando resultado...")

libro.save(ARCHIVO_RESULTADO)


# ========================================
# RESULTADOS
# ========================================

print("\n" + "=" * 60)
print("          RESULTADO DE LA REVISIÓN")
print("=" * 60)

print(f"Artículos revisados:       {total}")
print(f"Palabras duplicadas:      {palabras_duplicadas}")
print(f"Uso de minúsculas:        {minusculas}")
print(f"Caracteres inválidos:     {caracteres_invalidos}")

print("=" * 60)

print("\nArchivo actualizado:")
print(ARCHIVO_RESULTADO)

print("\nLa revisión terminó correctamente.")

input("\nPresiona ENTER para salir...")
