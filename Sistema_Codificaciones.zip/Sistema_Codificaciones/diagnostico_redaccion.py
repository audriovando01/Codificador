import os
import re
import glob
import sqlite3
import unicodedata

import pandas as pd

# ============================================================
# CONFIGURACION
# ============================================================

BASE_REVISION = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION"
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "base_datos.db")


# ============================================================
# CORRECCIONES HISTORICAS VALIDADAS
# Julio + Agosto
# ============================================================
#
# Se guardan en SQLite para que en el futuro puedan ampliarse
# sin modificar la lógica principal del programa.
#

CORRECCIONES_INICIALES = {
    "CONECOR": "CONECTOR",
    "COCENTRICA": "CONCENTRICA",
    "CABRON": "CARBON",
    "ALUMINO": "ALUMINIO",
    "LUQUIDOS": "LIQUIDOS",
    "FLEXBLE": "FLEXIBLE",
    "MAGUERA": "MANGUERA",
    "SERVIVIO": "SERVICIO",
    "REDUCIION": "REDUCCION",
    "COMBISTIBLE": "COMBUSTIBLE",
    "POLICARBONTO": "POLICARBONATO",
    "CONFIRGUARACION": "CONFIGURACION",
    "MODEN": "MODEM",
    "NVEL": "NIVEL",
    "MUTICOLOR": "MULTICOLOR",
    "ANTIBATERIAL": "ANTIBACTERIAL",
    "MEMEBER'S": "MEMBER'S",
    "HORIZONAL": "HORIZONTAL",
    "CARTULLO": "CARTUCHO",
    "IIMPRESORA": "IMPRESORA",
    "AGUHA": "AGUJA",
    "DIVICIONES": "DIVISIONES",
    "CACUCHA": "CACHUCHA",
    "BISCELADO": "BISELADO",
    "BISCELADOS": "BISELADOS",
    "TONILLO": "TORNILLO",
    "SUJESION": "SUJECION",
}


# ============================================================
# UTILIDADES
# ============================================================


def quitar_acentos(texto):
    texto = "" if pd.isna(texto) else str(texto)
    return "".join(
        c
        for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )


def normalizar_para_busqueda(texto):
    return quitar_acentos(texto).upper()


def normalizar_codigo(valor):
    if pd.isna(valor):
        return ""

    texto = str(valor).strip()

    if texto.endswith(".0"):
        texto = texto[:-2]

    return texto


def buscar_archivo_resultado():
    patron = os.path.join(BASE_REVISION, "RESULTADO_*.xlsx")
    archivos = glob.glob(patron)

    if not archivos:
        raise FileNotFoundError(
            "No se encontro ningun RESULTADO_*.xlsx en:\n" + BASE_REVISION
        )

    archivos = [
        archivo
        for archivo in archivos
        if "DIAGNOSTICO_" not in os.path.basename(archivo).upper()
    ]

    if not archivos:
        raise FileNotFoundError("No se encontro un archivo RESULTADO_*.xlsx valido.")

    return max(archivos, key=os.path.getmtime)


def nombre_salida(archivo_entrada):
    base = os.path.basename(archivo_entrada)
    periodo = os.path.splitext(base)[0].replace("RESULTADO_", "")

    return os.path.join(
        BASE_REVISION,
        f"DIAGNOSTICO_REDACCION_{periodo}.xlsx",
    )


# ============================================================
# DICCIONARIO EN SQLITE
# ============================================================


def preparar_diccionario():
    conn = sqlite3.connect(DB_PATH)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS diccionario_redaccion (
            error TEXT PRIMARY KEY,
            correccion TEXT NOT NULL,
            origen TEXT
        )
        """)

    for error, correccion in CORRECCIONES_INICIALES.items():
        conn.execute(
            """
            INSERT OR IGNORE INTO diccionario_redaccion
            (error, correccion, origen)
            VALUES (?, ?, ?)
            """,
            (error, correccion, "HISTORICO JULIO-AGOSTO"),
        )

    conn.commit()
    conn.close()


def cargar_diccionario():
    conn = sqlite3.connect(DB_PATH)

    filas = conn.execute("""
        SELECT error, correccion
        FROM diccionario_redaccion
        ORDER BY LENGTH(error) DESC
        """).fetchall()

    conn.close()

    return dict(filas)


# ============================================================
# DETECTORES
# ============================================================


def detectar_palabras_incorrectas(texto, diccionario):
    """
    Detecta únicamente palabras/fragmentos que ya fueron validados
    históricamente como REDACCION INCORRECTA.
    """
    texto_norm = normalizar_para_busqueda(texto)
    hallazgos = []

    for error, correccion in diccionario.items():
        error_norm = normalizar_para_busqueda(error)
        correccion_norm = normalizar_para_busqueda(correccion)

        # Si la forma correcta ya aparece exactamente en lugar del error,
        # no se marca.
        patron_error = rf"(?<![A-Z0-9]){re.escape(error_norm)}(?![A-Z0-9])"

        if re.search(patron_error, texto_norm):
            hallazgos.append(
                {
                    "tipo": "PALABRA/CAPTURA",
                    "detectado": error,
                    "correccion": correccion,
                    "detalle": f"{error} → {correccion}",
                }
            )

    return hallazgos


def detectar_estructura_incorrecta(texto):
    """
    Actualmente NO se generan observaciones automáticas por estructura.

    Después de validar septiembre se comprobó que patrones como:
      - ", X,"
      - ",,"
      - "LONGITUD X ..."
    pueden aparecer legítimamente en descripciones técnicas o como
    consecuencia de la plantilla del codificador.

    Para evitar falsos positivos, REDACCION INCORRECTA se limita por ahora
    a errores ortográficos/de captura previamente validados.
    """
    return []


def analizar_redaccion(texto, diccionario):
    hallazgos = []

    hallazgos.extend(detectar_palabras_incorrectas(texto, diccionario))

    hallazgos.extend(detectar_estructura_incorrecta(texto))

    # Eliminar duplicados conservando orden.
    unicos = []
    claves = set()

    for h in hallazgos:
        clave = (
            h["tipo"],
            h["detectado"],
            h["correccion"],
        )

        if clave not in claves:
            claves.add(clave)
            unicos.append(h)

    return unicos


# ============================================================
# PROCESAMIENTO
# ============================================================


def localizar_columnas(df):
    mapa = {}

    for col in df.columns:
        clave = quitar_acentos(col).upper().strip()
        mapa[clave] = col

    requeridas = [
        "CODIGO",
        "ESTADO",
        "GRUPO",
        "SUBGRUPO",
        "DESCRIPCION",
    ]

    faltantes = [nombre for nombre in requeridas if nombre not in mapa]

    if faltantes:
        raise ValueError("Faltan columnas requeridas: " + ", ".join(faltantes))

    return mapa


def procesar():
    preparar_diccionario()
    diccionario = cargar_diccionario()

    entrada = buscar_archivo_resultado()
    salida = nombre_salida(entrada)

    print("=" * 72)
    print("DIAGNOSTICO ORTOGRAFIA - REDACCION INCORRECTA")
    print("=" * 72)
    print(f"Entrada: {entrada}")
    print(f"Base de datos: {DB_PATH}")
    print()
    print(f"Correcciones historicas cargadas: {len(diccionario)}")
    print()

    df = pd.read_excel(
        entrada,
        dtype=str,
        engine="openpyxl",
    )

    mapa = localizar_columnas(df)

    c_codigo = mapa["CODIGO"]
    c_estado = mapa["ESTADO"]
    c_grupo = mapa["GRUPO"]
    c_subgrupo = mapa["SUBGRUPO"]
    c_desc = mapa["DESCRIPCION"]

    nuevos = df[df[c_estado].astype(str).str.strip().str.upper().eq("NUEVO")].copy()

    resultados = []
    detalle = []

    for _, fila in nuevos.iterrows():
        codigo = normalizar_codigo(fila[c_codigo])
        grupo = str(fila[c_grupo]).strip()
        subgrupo = str(fila[c_subgrupo]).strip()
        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])

        hallazgos = analizar_redaccion(
            descripcion,
            diccionario,
        )

        if hallazgos:
            observacion = "ORTOGRAFIA"
            subobservacion = "REDACCION INCORRECTA"

            motivos = "; ".join(h["detalle"] for h in hallazgos)

            correcciones = "; ".join(h["correccion"] for h in hallazgos)
        else:
            observacion = "OK"
            subobservacion = "OK"
            motivos = ""
            correcciones = ""

        resultados.append(
            {
                "Codigo": codigo,
                "Grupo": grupo,
                "Subgrupo": subgrupo,
                "Descripción": descripcion,
                "Observación propuesta": observacion,
                "Subobservación propuesta": subobservacion,
                "Hallazgos": motivos,
                "Corrección sugerida": correcciones,
            }
        )

        for h in hallazgos:
            detalle.append(
                {
                    "Codigo": codigo,
                    "Grupo": grupo,
                    "Subgrupo": subgrupo,
                    "Descripción": descripcion,
                    "Tipo de hallazgo": h["tipo"],
                    "Texto detectado": h["detectado"],
                    "Corrección sugerida": h["correccion"],
                    "Detalle": h["detalle"],
                }
            )

    resultado_df = pd.DataFrame(resultados)
    detalle_df = pd.DataFrame(detalle)

    casos_df = resultado_df[
        resultado_df["Subobservación propuesta"].eq("REDACCION INCORRECTA")
    ].copy()

    resumen_df = pd.DataFrame(
        [
            [
                "Articulos NUEVO analizados",
                len(resultado_df),
            ],
            [
                "REDACCION INCORRECTA",
                len(casos_df),
            ],
            [
                "Sin hallazgo de redaccion",
                len(resultado_df) - len(casos_df),
            ],
            [
                "Hallazgos individuales",
                len(detalle_df),
            ],
            [
                "Correcciones historicas disponibles",
                len(diccionario),
            ],
        ],
        columns=["Concepto", "Resultado"],
    )

    with pd.ExcelWriter(
        salida,
        engine="openpyxl",
    ) as writer:
        resumen_df.to_excel(
            writer,
            sheet_name="RESUMEN",
            index=False,
        )

        casos_df.to_excel(
            writer,
            sheet_name="REDACCION INCORRECTA",
            index=False,
        )

        detalle_df.to_excel(
            writer,
            sheet_name="DETALLE",
            index=False,
        )

        resultado_df.to_excel(
            writer,
            sheet_name="DIAGNOSTICO",
            index=False,
        )

        for hoja in writer.book.worksheets:
            hoja.freeze_panes = "A2"
            hoja.auto_filter.ref = hoja.dimensions

            for columna in hoja.columns:
                letra = columna[0].column_letter
                max_len = 0

                for celda in columna:
                    valor = "" if celda.value is None else str(celda.value)

                    max_len = max(
                        max_len,
                        min(len(valor), 80),
                    )

                hoja.column_dimensions[letra].width = max(
                    12,
                    min(max_len + 2, 60),
                )

    print("Diagnostico terminado correctamente.")
    print("-" * 72)
    print(f"Articulos NUEVO analizados:         {len(resultado_df)}")
    print(f"REDACCION INCORRECTA:               {len(casos_df)}")
    print(
        f"Sin hallazgo de redaccion:          " f"{len(resultado_df) - len(casos_df)}"
    )
    print(f"Hallazgos individuales:             {len(detalle_df)}")
    print()
    print("Archivo generado:")
    print(salida)
    print("=" * 72)


if __name__ == "__main__":
    procesar()
