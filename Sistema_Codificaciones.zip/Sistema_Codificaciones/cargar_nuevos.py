import sqlite3
import openpyxl
import os

# ============================================================
# CONFIGURACIÓN
# ============================================================

ARCHIVO_EXCEL = r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN\REVISION DE CODIFICACION\HISTORICO CODIFICACION.xlsx"

HOJA_MES = "MES ACTUAL"
HOJA_ORIGINAL = "ORIGINAL"

ARCHIVO_BD = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "base_datos.db"
)

MES_ACTUAL = "SEPTIEMBRE"

# ============================================================
# ABRIR EXCEL
# ============================================================

print("Abriendo archivo Excel...")

libro = openpyxl.load_workbook(
    ARCHIVO_EXCEL,
    read_only=True,
    data_only=True
)

hoja_mes = libro[HOJA_MES]
hoja_original = libro[HOJA_ORIGINAL]

# ============================================================
# FUNCIÓN PARA LOCALIZAR COLUMNAS
# ============================================================

def localizar_columnas(hoja, columnas_requeridas):

    encabezados = next(
        hoja.iter_rows(
            min_row=1,
            max_row=1,
            values_only=True
        )
    )

    columnas = {}

    for posicion, encabezado in enumerate(encabezados, start=1):

        if encabezado is None:
            continue

        nombre = str(encabezado).strip().upper()

        for requerido in columnas_requeridas:

            if nombre == requerido.upper():
                columnas[requerido] = posicion

    return columnas


# ============================================================
# LOCALIZAR COLUMNAS
# ============================================================

columnas_mes = localizar_columnas(
    hoja_mes,
    ["Codigos"]
)

columnas_original = localizar_columnas(
    hoja_original,
    [
        "Codigo",
        "Grupo",
        "Subgrupo",
        "Descripción",
        "Usuario",
        "UM"
    ]
)

# ============================================================
# VALIDAR COLUMNAS
# ============================================================

if "Codigos" not in columnas_mes:

    print("ERROR: No se encontró la columna Codigos en MES ACTUAL.")
    input("\nPresiona ENTER para salir...")
    exit()

columnas_requeridas_original = [
    "Codigo",
    "Grupo",
    "Subgrupo",
    "Descripción",
    "Usuario",
    "UM"
]

faltantes = [
    columna
    for columna in columnas_requeridas_original
    if columna not in columnas_original
]

if faltantes:

    print("ERROR: Faltan columnas en ORIGINAL:")

    for columna in faltantes:
        print(f"- {columna}")

    input("\nPresiona ENTER para salir...")
    exit()

print(
    f"Columna Codigos en MES ACTUAL: "
    f"{columnas_mes['Codigos']}"
)

print("\nColumnas encontradas en ORIGINAL:")

for nombre, posicion in columnas_original.items():
    print(f"{nombre}: columna {posicion}")

# ============================================================
# CONECTAR A BASE DE DATOS
# ============================================================

conexion = sqlite3.connect(ARCHIVO_BD)
cursor = conexion.cursor()

# ============================================================
# CARGAR CÓDIGOS HISTÓRICOS
# ============================================================

print("\nCargando códigos históricos...")

cursor.execute("""
    SELECT codigo
    FROM articulos_historico
""")

codigos_historicos = {
    fila[0]
    for fila in cursor.fetchall()
}

print(
    f"Códigos históricos disponibles: "
    f"{len(codigos_historicos)}"
)

# ============================================================
# CARGAR ORIGINAL EN MEMORIA
# ============================================================

print("\nCargando ORIGINAL...")

original = {}

for fila in hoja_original.iter_rows(
    min_row=2,
    values_only=True
):

    codigo = fila[columnas_original["Codigo"] - 1]

    if codigo is None:
        continue

    codigo = str(codigo).strip()

    if not codigo:
        continue

    original[codigo] = {
        "grupo": fila[columnas_original["Grupo"] - 1],
        "subgrupo": fila[columnas_original["Subgrupo"] - 1],
        "descripcion": fila[columnas_original["Descripción"] - 1],
        "usuario": fila[columnas_original["Usuario"] - 1],
        "um": fila[columnas_original["UM"] - 1]
    }

print(
    f"Artículos disponibles en ORIGINAL: "
    f"{len(original)}"
)

# ============================================================
# PROCESAR NUEVOS
# ============================================================

total_leidos = 0
total_nuevos = 0
total_insertados = 0
total_ya_estaban = 0
total_no_encontrados = 0

print("\nProcesando códigos NUEVOS...\n")

for fila in hoja_mes.iter_rows(
    min_row=2,
    min_col=columnas_mes["Codigos"],
    max_col=columnas_mes["Codigos"],
    values_only=True
):

    codigo = fila[0]

    if codigo is None:
        continue

    codigo = str(codigo).strip()

    if not codigo:
        continue

    total_leidos += 1

    # --------------------------------------------------------
    # COMPROBAR SI YA EXISTE
    # --------------------------------------------------------

    if codigo in codigos_historicos:
        total_ya_estaban += 1
        continue

    total_nuevos += 1

    # --------------------------------------------------------
    # BUSCAR INFORMACIÓN EN ORIGINAL
    # --------------------------------------------------------

    if codigo not in original:

        total_no_encontrados += 1
        continue

    datos = original[codigo]

    # --------------------------------------------------------
    # INSERTAR EN BASE
    # --------------------------------------------------------

    cursor.execute(
        """
        INSERT OR IGNORE INTO articulos_historico
        (
            codigo,
            grupo,
            subgrupo,
            descripcion,
            usuario,
            um,
            mes
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            codigo,
            datos["grupo"],
            datos["subgrupo"],
            datos["descripcion"],
            datos["usuario"],
            datos["um"],
            MES_ACTUAL
        )
    )

    if cursor.rowcount == 1:

        total_insertados += 1

        # Mostrar algunos ejemplos
        if total_insertados <= 10:

            print(
                f"{codigo} → INSERTADO | "
                f"{datos['grupo']} | "
                f"{datos['subgrupo']} | "
                f"{datos['descripcion']}"
            )

# ============================================================
# GUARDAR CAMBIOS
# ============================================================

conexion.commit()

# ============================================================
# RESULTADOS
# ============================================================

print("\n========================================")
print("       CARGA DE SEPTIEMBRE")
print("========================================")

print(f"Códigos leídos:              {total_leidos}")
print(f"Códigos NUEVOS:              {total_nuevos}")
print(f"Códigos insertados:          {total_insertados}")
print(f"Códigos que ya estaban:      {total_ya_estaban}")
print(f"No encontrados en ORIGINAL:  {total_no_encontrados}")

print("========================================")

# ============================================================
# VERIFICACIÓN FINAL
# ============================================================

cursor.execute("""
    SELECT COUNT(*)
    FROM articulos_historico
""")

total_bd = cursor.fetchone()[0]

cursor.execute("""
    SELECT COUNT(*)
    FROM articulos_historico
    WHERE mes = ?
""", (MES_ACTUAL,))

total_septiembre = cursor.fetchone()[0]

print(f"\nTotal de registros en la base: {total_bd}")
print(f"Registros de SEPTIEMBRE:       {total_septiembre}")

# ============================================================
# CERRAR
# ============================================================

conexion.close()
libro.close()

input("\nPresiona ENTER para salir...")