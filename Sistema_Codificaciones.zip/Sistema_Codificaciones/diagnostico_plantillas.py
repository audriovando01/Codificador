import os
import re
import glob
import sqlite3
import unicodedata
import pandas as pd

# ============================================================
# CONFIGURACION
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "base_datos.db")

# Si el archivo RESULTADO_*.xlsx no esta en la carpeta del proyecto,
# cambia esta ruta por la carpeta donde lo genera procesar_mensual.py.
CARPETA_RESULTADOS = r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN\REVISION DE CODIFICACION"

# Si quieres forzar un archivo especifico, escribe su ruta aqui.
# Ejemplo: ARCHIVO_ENTRADA = r"C:\...\RESULTADO_SEPTIEMBRE.xlsx"
ARCHIVO_ENTRADA = None

# Solo analiza articulos marcados como NUEVO.
SOLO_NUEVOS = True


# ============================================================
# NORMALIZACION
# ============================================================
def normalizar(texto):
    if pd.isna(texto):
        return ""
    texto = str(texto).upper().strip()
    texto = unicodedata.normalize("NFD", texto)
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    texto = texto.replace("Ø", " DIAMETRO ")
    texto = re.sub(r"\s+", " ", texto)
    return texto


def codigo_2d(valor):
    texto = str(valor).strip() if not pd.isna(valor) else ""
    if re.fullmatch(r"\d+(?:\.0+)?", texto):
        return f"{int(float(texto)):02d}"
    return texto.zfill(2) if texto.isdigit() else texto


# ============================================================
# PATRONES GENERALES DE CAMPOS
# ============================================================
# Un campo solo se declara FALTANTE cuando existe una regla suficientemente
# confiable. Si no hay regla, queda NO_EVALUABLE y no genera error.
PATRONES = {
    "DIAMETRO": [
        r"\bDIAMETRO\s*(?:DE\s*)?[:=]?\s*\d",
        r"\b(?:DN|NPS)\s*\d",
        r"\b\d+(?:\s+\d+/\d+|/\d+)?\s*(?:\"|PULG(?:ADA|ADAS)?|IN\b|MM\b|CM\b)",
    ],
    "CEDULA": [
        r"\bCED(?:ULA)?\.?\s*\d+[A-Z]?\b",
        r"\bSCH\.?\s*\d+[A-Z]?\b",
        r"\bSCHEDULE\s*\d+[A-Z]?\b",
    ],
    "ESPECIFICACION DE MATERIAL": [
        r"\bASTM\s+[A-Z0-9\-./]+",
        r"\bAPI\s+[0-9A-Z\-./]+",
        r"\bAISI\s+[0-9A-Z\-./]+",
        r"\bSAE\s+[0-9A-Z\-./]+",
        r"\bEN\s+\d{3,}",
        r"\bA[- ]?\d{2,4}[A-Z]?\b",
    ],
    "ESPECIFICACIÓN DE MATERIAL": [
        r"\bASTM\s+[A-Z0-9\-./]+",
        r"\bAPI\s+[0-9A-Z\-./]+",
        r"\bAISI\s+[0-9A-Z\-./]+",
        r"\bSAE\s+[0-9A-Z\-./]+",
        r"\bEN\s+\d{3,}",
        r"\bA[- ]?\d{2,4}[A-Z]?\b",
    ],
    "EXT": [
        r"\b(?:BISELAD[OA]S?|ROSCAD[OA]S?|RANURAD[OA]S?|BRIDAD[OA]S?|SOLDABLES?|BW|SW|NPT|BSP|FLANGEAD[OA]S?)\b",
    ],
    "EXTREMO": [
        r"\b(?:BISELAD[OA]S?|ROSCAD[OA]S?|RANURAD[OA]S?|BRIDAD[OA]S?|SOLDABLES?|BW|SW|NPT|BSP|FLANGEAD[OA]S?)\b",
    ],
    "EXTREMOS": [
        r"\b(?:BISELAD[OA]S?|ROSCAD[OA]S?|RANURAD[OA]S?|BRIDAD[OA]S?|SOLDABLES?|BW|SW|NPT|BSP|FLANGEAD[OA]S?)\b",
    ],
    "CLASE": [
        r"\bCLASE\s*#?\s*\d+\b",
        r"\bCLASS\s*#?\s*\d+\b",
        r"\b\d+\s*(?:LB|LBS|#)\b",
    ],
    "ESPESOR": [
        r"\bESPESOR(?:\s+DE\s+PARED)?\s*(?:DE\s*)?[:=]?\s*\d",
    ],
    "ESPESOR DE PARED": [
        r"\bESPESOR(?:\s+DE\s+PARED)?\s*(?:DE\s*)?[:=]?\s*\d",
    ],
    "LONGITUD": [
        r"\bLONGITUD\s*(?:DE\s*)?[:=]?\s*\d",
        r"\bLARGO\s*(?:DE\s*)?[:=]?\s*\d",
    ],
    "LARGO": [
        r"\bLARGO\s*(?:DE\s*)?[:=]?\s*\d",
        r"\bLONGITUD\s*(?:DE\s*)?[:=]?\s*\d",
    ],
    "ANCHO": [r"\bANCHO\s*(?:DE\s*)?[:=]?\s*\d"],
    "ALTO": [r"\b(?:ALTO|ALTURA)\s*(?:DE\s*)?[:=]?\s*\d"],
    "ALTURA": [r"\b(?:ALTO|ALTURA)\s*(?:DE\s*)?[:=]?\s*\d"],
    "POTENCIA": [
        r"\bPOTENCIA\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*(?:HP|KW|W)\b",
    ],
    "VOLTAJE": [
        r"\bVOLTAJE\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*V(?:AC|DC)?\b",
    ],
    "PRESION": [
        r"\bPRESION(?:\s+(?:MAXIMA|DE\s+DISENO|DE\s+OPERACION))?\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*(?:PSI|BAR|KPA|MPA)\b",
    ],
    "PRESION DISEÑO": [
        r"\bPRESION(?:\s+DE)?\s+DISENO\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*(?:PSI|BAR|KPA|MPA)\b",
    ],
    "PRESION MAXIMA": [
        r"\bPRESION\s+MAXIMA\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*(?:PSI|BAR|KPA|MPA)\b",
    ],
    "TEMPERATURA": [
        r"\bTEMPERATURA(?:\s+(?:MAXIMA|MINIMA|DE\s+OPERACION|DE\s+DISENO))?\s*[:=]?\s*-?\d",
        r"-?\d+(?:\.\d+)?\s*°?\s*[CF]\b",
    ],
    "TEMPERATURA DE OPERACIÓN": [
        r"\bTEMPERATURA(?:\s+DE)?\s+OPERACION\s*[:=]?\s*-?\d",
        r"-?\d+(?:\.\d+)?\s*°?\s*[CF]\b",
    ],
    "TEMPERATURA DE DISEÑO": [
        r"\bTEMPERATURA(?:\s+DE)?\s+DISENO\s*[:=]?\s*-?\d",
        r"-?\d+(?:\.\d+)?\s*°?\s*[CF]\b",
    ],
    "DENSIDAD": [
        r"\bDENSIDAD\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*(?:G/CM3|KG/M3|KG/L)\b",
    ],
    "CALIBRE": [
        r"\bCALIBRE\s*[:=]?\s*[0-9A-Z]+",
        r"\b(?:AWG|CAL)\s*\d+\b",
    ],
    "CAPACIDAD": [
        r"\bCAPACIDAD\s*[:=]?\s*\d",
    ],
    "MODELO": [r"\bMODELO\s*[:=]?\s*[A-Z0-9]"],
    "FABRICANTE": [r"\bFABRICANTE\s*[:=]?\s*[A-Z0-9]"],
    "MARCA": [r"\bMARCA\s*[:=]?\s*[A-Z0-9]"],
    "COLOR": [r"\bCOLOR\s*[:=]?\s*[A-Z]"],
    "SERVICIO": [r"\bSERVICIO\s*[:=]?\s*[A-Z0-9]"],
    "GRADO PUREZA": [
        r"\bGRADO\s+(?:DE\s+)?PUREZA\s*[:=]?\s*[A-Z0-9]",
        r"\bPUREZA\s*[:=]?\s*\d+(?:\.\d+)?\s*%",
    ],
    "NORMATIVA": [
        r"\b(?:ASTM|API|ASME|ANSI|ISO|DIN|NOM|NMX|NFPA|UL|FM)\s*[A-Z0-9\-./]*",
    ],
    "DIMENSIONES": [
        r"\bDIMENSIONES\s*[:=]?\s*\d",
        r"\b\d+(?:\.\d+)?\s*[Xx]\s*\d+(?:\.\d+)?(?:\s*[Xx]\s*\d+(?:\.\d+)?)?\s*(?:MM|CM|M|IN|\")?",
    ],
    "MATERIAL": [
        r"\bMATERIAL\s*[:=]?\s*[A-Z0-9]",
        r"\b(?:ACERO(?:\s+AL\s+CARBON|\s+INOXIDABLE)?|INOXIDABLE|PVC|CPVC|HDPE|PEAD|POLIETILENO|POLIPROPILENO|PTFE|TEFLON|LATON|BRONCE|ALUMINIO|HIERRO(?:\s+FUNDIDO)?|NITRILO|EPDM|NEOPRENO|VITON|POLIURETANO|COBRE|CAUCHO|HULE)\b",
    ],
}

# Alias para nombres equivalentes que aparecen en las plantillas.
ALIAS_CAMPO = {
    "DIAMETRO2": "DIAMETRO",
    "EXTREMO2": "EXTREMO",
    "PRESION DE DISEÑO": "PRESION DISEÑO",
    "PRESION DE DISENO": "PRESION DISEÑO",
    "TEMPERATURA DE OPERACION": "TEMPERATURA DE OPERACIÓN",
    "TEMPERATURA DE DISENO": "TEMPERATURA DE DISEÑO",
    "ESPECIFICACION DE MATERIAL": "ESPECIFICACION DE MATERIAL",
    "ESPECIFICACIÓN DE MATERIAL": "ESPECIFICACION DE MATERIAL",
}


def clave_patron(campo):
    c = normalizar(campo)
    # restauramos claves canonicas sin acentos porque normalizar los quita
    equivalencias = {
        "ESPECIFICACION DE MATERIAL": "ESPECIFICACION DE MATERIAL",
        "PRESION DISENO": "PRESION DISEÑO",
        "PRESION DE DISENO": "PRESION DISEÑO",
        "TEMPERATURA DE OPERACION": "TEMPERATURA DE OPERACIÓN",
        "TEMPERATURA DE DISENO": "TEMPERATURA DE DISEÑO",
    }
    c = equivalencias.get(c, c)
    return ALIAS_CAMPO.get(c, c)


def detectar_campo(campo, descripcion):
    clave = clave_patron(campo)
    texto = normalizar(descripcion)

    # Caso especial: campos numerados usan la misma logica base.
    clave_base = re.sub(r"\d+$", "", clave).strip()
    if clave not in PATRONES and clave_base in PATRONES:
        clave = clave_base

    patrones = PATRONES.get(clave)
    if not patrones:
        # Si el propio nombre del campo aparece escrito y trae un valor despues,
        # podemos considerarlo detectado sin conocer la semantica del campo.
        etiqueta = normalizar(campo)
        m = re.search(rf"\b{re.escape(etiqueta)}\b\s*[:=,-]?\s*([A-Z0-9])", texto)
        if m:
            return "DETECTADO", f"El campo {campo} aparece explicitamente con valor"
        return "NO_EVALUABLE", "Sin regla automatica suficientemente confiable"

    for patron in patrones:
        if re.search(patron, texto, re.IGNORECASE):
            return "DETECTADO", f"Coincide con patron de {campo}"

    return "FALTANTE", f"No se encontro evidencia suficiente de {campo}"


# ============================================================
# LLENADO INADECUADO DE PLANTILLA
# ============================================================
VALORES_INVALIDOS = {"N/A", "NA", "NO APLICA", "-", "."}


def detectar_campo_mal_llenado(descripcion, campos_plantilla):
    """
    Detecta casos fuertes donde el nombre de un campo aparece en la descripcion
    pero no tiene valor, tiene un valor invalido o inmediatamente aparece otro
    nombre de campo.
    """
    texto = normalizar(descripcion)
    nombres = [normalizar(c) for c in campos_plantilla if c]
    nombres = sorted(set(nombres), key=len, reverse=True)
    errores = []

    if not texto or not nombres:
        return errores

    # Construimos una expresion con nombres de campos conocidos de ESA plantilla.
    alternancia = "|".join(re.escape(n) for n in nombres if len(n) >= 3)
    if not alternancia:
        return errores

    for campo in nombres:
        # Solo revisamos si la etiqueta del campo aparece literalmente.
        patron = re.compile(rf"\b{re.escape(campo)}\b", re.IGNORECASE)
        for m in patron.finditer(texto):
            despues = texto[m.end() :].lstrip(" :,-.;")

            if not despues:
                errores.append(f"{campo}: sin valor")
                continue

            # Otro campo aparece inmediatamente antes de un valor util.
            otro = re.match(rf"(?:{alternancia})\b", despues, re.IGNORECASE)
            if otro:
                otro_campo = otro.group(0)
                if normalizar(otro_campo) != campo:
                    errores.append(f"{campo}: seguido por otro campo ({otro_campo})")
                    continue

            primer_fragmento = re.split(r"[,;]", despues, maxsplit=1)[0].strip()
            if primer_fragmento in VALORES_INVALIDOS:
                errores.append(f"{campo}: valor invalido ({primer_fragmento})")

    # quitar duplicados manteniendo orden
    vistos = set()
    salida = []
    for e in errores:
        if e not in vistos:
            vistos.add(e)
            salida.append(e)
    return salida


# ============================================================
# ENTRADA / BASE DE DATOS
# ============================================================
def localizar_archivo_entrada():
    if ARCHIVO_ENTRADA:
        if not os.path.exists(ARCHIVO_ENTRADA):
            raise FileNotFoundError(f"No existe ARCHIVO_ENTRADA:\n{ARCHIVO_ENTRADA}")
        return ARCHIVO_ENTRADA

    patrones = [
        os.path.join(CARPETA_RESULTADOS, "RESULTADO_*.xlsx"),
        os.path.join(BASE_DIR, "RESULTADO_*.xlsx"),
    ]
    candidatos = []
    for patron in patrones:
        candidatos.extend(glob.glob(patron))

    candidatos = [p for p in candidatos if not os.path.basename(p).startswith("~$")]
    if not candidatos:
        raise FileNotFoundError(
            "No encontre ningun archivo RESULTADO_*.xlsx.\n"
            "Configura ARCHIVO_ENTRADA al inicio del script."
        )

    return max(candidatos, key=os.path.getmtime)


def cargar_plantillas(conn):
    catalogo = pd.read_sql_query(
        """
        SELECT grupo, subgrupo, nombre_grupo, nombre_subgrupo, um
        FROM catalogo_subgrupos
    """,
        conn,
    )

    campos = pd.read_sql_query(
        """
        SELECT grupo, subgrupo, orden, elemento, tipo_elemento, obligatorio
        FROM campos_plantilla
        ORDER BY grupo, subgrupo, orden
    """,
        conn,
    )

    for df in (catalogo, campos):
        df["grupo"] = df["grupo"].astype(str).str.zfill(2)
        df["subgrupo"] = df["subgrupo"].astype(str).str.zfill(2)

    return catalogo, campos


# ============================================================
# ANALISIS
# ============================================================
def analizar():
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError(f"No existe la base de datos:\n{DB_PATH}")

    entrada = localizar_archivo_entrada()
    print("=" * 72)
    print("DIAGNOSTICO DE PLANTILLAS")
    print("=" * 72)
    print(f"Entrada: {entrada}")
    print(f"Base de datos: {DB_PATH}")
    print()

    df = pd.read_excel(entrada, dtype=str, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]

    # Resolver nombres de columnas tolerando mayusculas/acentos.
    mapa = {normalizar(c): c for c in df.columns}
    requeridas = ["CODIGO", "GRUPO", "SUBGRUPO", "DESCRIPCION"]
    faltan = [c for c in requeridas if c not in mapa]
    if faltan:
        raise ValueError(
            "Faltan columnas en el archivo de entrada: " + ", ".join(faltan)
        )

    col_codigo = mapa["CODIGO"]
    col_grupo = mapa["GRUPO"]
    col_subgrupo = mapa["SUBGRUPO"]
    col_desc = mapa["DESCRIPCION"]
    col_estado = mapa.get("ESTADO")

    if SOLO_NUEVOS and col_estado:
        df = df[
            df[col_estado].fillna("").astype(str).str.upper().str.strip() == "NUEVO"
        ].copy()

    conn = sqlite3.connect(DB_PATH)
    try:
        catalogo, campos = cargar_plantillas(conn)
    finally:
        conn.close()

    catalogo_idx = catalogo.set_index(["grupo", "subgrupo"])
    grupos_campos = {
        k: g.copy() for k, g in campos.groupby(["grupo", "subgrupo"], sort=False)
    }

    resultados = []
    detalles = []

    cont_sub = 0
    cont_llenado = 0
    cont_ok = 0
    cont_sin_plantilla = 0
    cont_revisar = 0

    for _, fila in df.iterrows():
        codigo = str(fila[col_codigo]).strip()
        grupo = codigo_2d(fila[col_grupo])
        subgrupo = codigo_2d(fila[col_subgrupo])
        descripcion = str(fila[col_desc]) if not pd.isna(fila[col_desc]) else ""
        clave = (grupo, subgrupo)

        if clave not in catalogo_idx.index or clave not in grupos_campos:
            cont_sin_plantilla += 1
            resultados.append(
                {
                    "Codigo": codigo,
                    "Grupo": grupo,
                    "Subgrupo": subgrupo,
                    "Descripcion": descripcion,
                    "Nombre Subgrupo": "",
                    "Campos obligatorios": "",
                    "Obligatorios detectados": "",
                    "Obligatorios faltantes": "",
                    "Obligatorios no evaluables": "",
                    "Errores de llenado": "",
                    "OBSERVACION PROPUESTA": "REVISAR",
                    "SUBOBSERVACION PROPUESTA": "SIN PLANTILLA EN CATALOGO",
                    "Detalle": "No se encontro plantilla para este grupo/subgrupo",
                }
            )
            continue

        info = catalogo_idx.loc[clave]
        gcampos = grupos_campos[clave]
        campos_reales = gcampos[gcampos["tipo_elemento"] == "CAMPO"][
            "elemento"
        ].tolist()
        obligatorios = gcampos[
            (gcampos["tipo_elemento"] == "CAMPO") & (gcampos["obligatorio"] == 1)
        ]["elemento"].tolist()

        detectados = []
        faltantes = []
        no_evaluables = []

        for campo in obligatorios:
            estado, motivo = detectar_campo(campo, descripcion)
            detalles.append(
                {
                    "Codigo": codigo,
                    "Grupo": grupo,
                    "Subgrupo": subgrupo,
                    "Campo obligatorio": campo,
                    "Estado": estado,
                    "Motivo": motivo,
                }
            )
            if estado == "DETECTADO":
                detectados.append(campo)
            elif estado == "FALTANTE":
                faltantes.append(campo)
            else:
                no_evaluables.append(campo)

        errores_llenado = detectar_campo_mal_llenado(descripcion, campos_reales)

        # Priorizacion: un llenado claramente incorrecto es mas especifico.
        if errores_llenado:
            observacion = "ESPECIFICACION TECNICA"
            subobservacion = "LLENADO INADECUADO DE PLANTILLA"
            detalle_final = "; ".join(errores_llenado)
            cont_llenado += 1
        elif faltantes:
            observacion = "ESPECIFICACION TECNICA"
            subobservacion = "SUB-ESPECIFICADO"
            detalle_final = "Campos obligatorios sin evidencia: " + ", ".join(faltantes)
            cont_sub += 1
        elif no_evaluables:
            observacion = "REVISAR"
            subobservacion = "CAMPOS NO EVALUABLES AUTOMATICAMENTE"
            detalle_final = "No se determina error; revisar: " + ", ".join(
                no_evaluables
            )
            cont_revisar += 1
        else:
            observacion = "OK"
            subobservacion = "OK"
            detalle_final = "Todos los campos obligatorios evaluables fueron detectados"
            cont_ok += 1

        resultados.append(
            {
                "Codigo": codigo,
                "Grupo": grupo,
                "Subgrupo": subgrupo,
                "Descripcion": descripcion,
                "Nombre Subgrupo": info["nombre_subgrupo"],
                "Campos obligatorios": ", ".join(obligatorios),
                "Obligatorios detectados": ", ".join(detectados),
                "Obligatorios faltantes": ", ".join(faltantes),
                "Obligatorios no evaluables": ", ".join(no_evaluables),
                "Errores de llenado": "; ".join(errores_llenado),
                "OBSERVACION PROPUESTA": observacion,
                "SUBOBSERVACION PROPUESTA": subobservacion,
                "Detalle": detalle_final,
            }
        )

    res = pd.DataFrame(resultados)
    det = pd.DataFrame(detalles)

    nombre_base = os.path.splitext(os.path.basename(entrada))[0]
    sufijo = nombre_base.replace("RESULTADO_", "")
    salida = os.path.join(
        os.path.dirname(entrada), f"DIAGNOSTICO_PLANTILLAS_{sufijo}.xlsx"
    )

    resumen = pd.DataFrame(
        [
            ["Articulos analizados", len(res)],
            ["SUB-ESPECIFICADO", cont_sub],
            ["LLENADO INADECUADO DE PLANTILLA", cont_llenado],
            ["REVISAR - campos no evaluables", cont_revisar],
            ["Sin plantilla en catalogo", cont_sin_plantilla],
            ["OK", cont_ok],
        ],
        columns=["Indicador", "Cantidad"],
    )

    with pd.ExcelWriter(salida, engine="openpyxl") as writer:
        resumen.to_excel(writer, index=False, sheet_name="RESUMEN")
        res.to_excel(writer, index=False, sheet_name="DIAGNOSTICO")
        det.to_excel(writer, index=False, sheet_name="DETALLE_CAMPOS")

        for nombre_hoja in writer.book.sheetnames:
            ws = writer.book[nombre_hoja]
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for col in ws.columns:
                letra = col[0].column_letter
                ancho = 0
                for celda in col[:200]:
                    valor = "" if celda.value is None else str(celda.value)
                    ancho = max(ancho, min(len(valor) + 2, 60))
                ws.column_dimensions[letra].width = max(ancho, 12)

    print("Diagnostico terminado correctamente.")
    print("-" * 72)
    print(f"Articulos analizados:                  {len(res)}")
    print(f"SUB-ESPECIFICADO:                     {cont_sub}")
    print(f"LLENADO INADECUADO DE PLANTILLA:      {cont_llenado}")
    print(f"REVISAR - campos no evaluables:        {cont_revisar}")
    print(f"Sin plantilla en catalogo:             {cont_sin_plantilla}")
    print(f"OK:                                    {cont_ok}")
    print()
    print(f"Archivo generado:\n{salida}")
    print("=" * 72)


if __name__ == "__main__":
    analizar()
