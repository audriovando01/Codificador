import sqlite3

conexion = sqlite3.connect("base_datos.db")

cursor = conexion.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS articulos_historico (
    codigo TEXT PRIMARY KEY,
    grupo TEXT,
    subgrupo TEXT,
    descripcion TEXT,
    usuario TEXT,
    um TEXT,
    mes TEXT
)
""")

conexion.commit()

print("Tabla articulos_historico creada correctamente.")

conexion.close()