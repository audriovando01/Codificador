import sqlite3
import os

ARCHIVO_BD = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "base_datos.db"
)

conexion = sqlite3.connect(ARCHIVO_BD)
cursor = conexion.cursor()

print("========================================")
print("       VERIFICACIÓN DE BASE HISTÓRICA")
print("========================================")

# Total de registros
cursor.execute("SELECT COUNT(*) FROM articulos_historico")
total = cursor.fetchone()[0]

print(f"\nTotal de códigos: {total}")

# Primeros 10 códigos
cursor.execute("""
    SELECT codigo, mes
    FROM articulos_historico
    ORDER BY rowid
    LIMIT 10
""")

print("\nPrimeros 10 registros:")

for codigo, mes in cursor.fetchall():
    print(f"Código: {codigo} | Mes: {mes}")

# Últimos 10 códigos
cursor.execute("""
    SELECT codigo, mes
    FROM articulos_historico
    ORDER BY rowid DESC
    LIMIT 10
""")

print("\nÚltimos 10 registros:")

for codigo, mes in cursor.fetchall():
    print(f"Código: {codigo} | Mes: {mes}")

# Verificar mes
cursor.execute("""
    SELECT mes, COUNT(*)
    FROM articulos_historico
    GROUP BY mes
""")

print("\nDistribución por mes:")

for mes, cantidad in cursor.fetchall():
    print(f"{mes}: {cantidad}")

conexion.close()

input("\nPresiona ENTER para salir...")