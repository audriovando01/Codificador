import re

from openpyxl import load_workbook, Workbook

# ============================================================

# CONFIGURACIÓN

# ============================================================

ARCHIVO_ENTRADA = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION\RESULTADO_SEPTIEMBRE.xlsx"
)

ARCHIVO_SALIDA = (
    r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN"
    r"\REVISION DE CODIFICACION\DIAGNOSTICO_ORTOGRAFIA_SEPTIEMBRE.xlsx"
)


# ============================================================

# CONFIGURACIÓN DE ORTOGRAFÍA

# ============================================================

palabras_permitidas = {
    "DE",
    "ASME",
    "NPT",
    "MR",
    "MHZ",
    "HZ",
}

CARACTERES_INVALIDOS = {
    "Ø",
    "ø",
    "¿",
    "?",
    "|",
    "®",
    "™",
}


# ============================================================

# DETECTAR PALABRAS DUPLICADAS

# ============================================================


def detectar_palabras_duplicadas(texto):
    palabras = re.findall(r"\b[A-ZÁÉÍÓÚÜÑ]+\b", texto.upper())

    # Palabras técnicas que pueden repetirse
    # sin considerarse error de redacción.
    palabras_permitidas = {
        "DE",
        "ASME",
        "NPT",
        "MR",
        "MHZ",
        "HZ",
        "PSI",
    }

    duplicadas = []
    palabra_anterior = None

    for palabra in palabras:

        # La X se utiliza como separador
        # de dimensiones o extremos.
        if palabra == "X":
            palabra_anterior = None
            continue

        # Si es una palabra técnica permitida,
        # no se considera duplicación.
        if palabra in palabras_permitidas:
            palabra_anterior = palabra
            continue

        # Detectar únicamente palabras consecutivas iguales
        if palabra == palabra_anterior:
            if palabra not in duplicadas:
                duplicadas.append(palabra)

        palabra_anterior = palabra

    return duplicadas


# ============================================================

# DETECTAR USO DE MINÚSCULAS

# ============================================================


def detectar_minusculas(texto):

    unidades = {
        "mm",
        "cm",
        "m",
        "km",
        "ft",
        "in",
        "kg",
        "g",
        "mg",
        "lb",
        "lbs",
        "hz",
        "khz",
        "mhz",
        "ghz",
        "kw",
        "kva",
        "kvar",
        "kwh",
        "mah",
        "dbm",
        "psi",
        "pa",
        "mpa",
        "lm",
        "lm/w",
        "ma",
        "ua",
        "v",
        "w",
        "a",
        "ka",
        "kaic",
    }

    palabras_detectadas = []

    tokens = re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9°±./:+\-]+", texto)

    for token in tokens:

        if not token:

            continue

        if token.upper() == "NO":

            continue

        if token.upper() == "X":

            continue

        if any(char.isdigit() for char in token):

            continue

        if any(char in token for char in ["/", "-", ":", "+", ".", "°", "±"]):

            continue

        if token.lower() in unidades:

            continue

        if token == token.upper():

            continue

        palabras_detectadas.append(token)

    return palabras_detectadas


# ============================================================

# DETECTAR CARACTERES INVÁLIDOS

# ============================================================


def detectar_caracteres_invalidos(texto):

    encontrados = []

    # --------------------------------------------------------
    # CARACTERES PROHIBIDOS
    # --------------------------------------------------------

    for caracter in CARACTERES_INVALIDOS:

        if caracter in texto and caracter not in encontrados:

            encontrados.append(caracter)

    # --------------------------------------------------------
    # VALORES QUE NO DEBEN UTILIZARSE
    # --------------------------------------------------------

    texto_mayusculas = texto.upper()

    patrones_valores_invalidos = [
        r"\bNO\s+APLICA\b",
        r"\bN/A\b",
        r"\bNA\b",
    ]

    for patron in patrones_valores_invalidos:

        if re.search(patron, texto_mayusculas):

            valor = re.search(patron, texto_mayusculas).group()

            if valor not in encontrados:

                encontrados.append(valor)

    # --------------------------------------------------------
    # PUNTO O GUION COMO VALOR DE UN CAMPO
    #
    # Ejemplos incorrectos:
    # EXTREMO .
    # EXTREMO -
    # MATERIAL .
    # TIPO -
    #
    # No se consideran inválidos puntos o guiones que formen
    # parte de valores normales como:
    # A-36, 15.2, 10-1757, etc.
    # --------------------------------------------------------

    patron_campo_vacio = re.compile(
        r"\b("
        r"EXTREMO|"
        r"MATERIAL|"
        r"TIPO|"
        r"MARCA|"
        r"MODELO|"
        r"FABRICANTE|"
        r"DESCRIPCION|"
        r"DESCRIPCIÓN|"
        r"COLOR|"
        r"ACABADO|"
        r"OBSERVACION|"
        r"OBSERVACIÓN|"
        r"CLASE|"
        r"CONEXION|"
        r"CONEXIÓN|"
        r"DIAMETRO|"
        r"DIÁMETRO|"
        r"LONGITUD|"
        r"LARGO|"
        r"ANCHO|"
        r"ALTO|"
        r"ALTURA|"
        r"ESPESOR|"
        r"PROFUNDIDAD"
        r")"
        r"\s*(?:\.|-)\s*(?=,|$)",
        re.IGNORECASE,
    )

    for coincidencia in patron_campo_vacio.finditer(texto):

        valor = coincidencia.group(0).strip()

        if valor not in encontrados:

            encontrados.append(valor)

    return encontrados


# ============================================================

# DETECTAR MISSING UNITS

# ============================================================


def detectar_missing_units(texto):

    # --------------------------------------------------------
    # Normalizar texto
    # --------------------------------------------------------

    texto_mayusculas = texto.upper()

    # Corrige números escritos accidentalmente con espacio:
    # 15. 24 M -> 15.24 M
    # 15, 24 M -> 15.24 M
    texto_mayusculas = re.sub(r"(\d+)\s*[.,]\s*(\d+)", r"\1.\2", texto_mayusculas)

    errores = []

    # --------------------------------------------------------
    # CAMPOS DE DIMENSIONES EXPLÍCITOS
    # --------------------------------------------------------

    campos = [
        "DIAMETRO",
        "LONGITUD",
        "LARGO",
        "ANCHO",
        "ALTO",
        "ALTURA",
        "PROFUNDIDAD",
        "ESPESOR",
    ]

    # Número entero, decimal, fracción o fracción mixta
    numero = r"(?:\d+\s+\d+/\d+|\d+/\d+|\d+(?:[.,]\d+)?)"

    # Unidades aceptadas
    # IMPORTANTE: aquí se incluye M
    unidades = r'(?:MM2|MM|CM|M|MT|MTS|METROS?|IN|PULG(?:ADA|ADAS)?|FT|")'

    for campo in campos:

        patron = re.compile(rf"\b{campo}\s*(?:DE\s*)?({numero})", re.IGNORECASE)

        for coincidencia in patron.finditer(texto_mayusculas):

            valor = coincidencia.group(1)

            posicion_final = coincidencia.end()

            # Texto inmediatamente después del número
            siguiente = texto_mayusculas[posicion_final : posicion_final + 30]

            # ------------------------------------------------
            # CASO 1:
            # El número tiene unidad inmediatamente después
            #
            # Ejemplos:
            # DIAMETRO 3"
            # LONGITUD 50 M
            # LONGITUD 15.2 M
            # LARGO 2 M
            # ALTO 5.3 M
            # ------------------------------------------------

            if re.match(rf"\s*{unidades}(?=\s|$|[,.;:)])", siguiente):
                continue

            # ------------------------------------------------
            # CASO 2:
            # Dimensiones encadenadas
            #
            # Ejemplo:
            # ALTURA 61 X 121.9 CM
            #
            # Si después del primer número aparece X y
            # posteriormente aparece una unidad, no marcar
            # el primer número.
            # ------------------------------------------------

            siguiente_limpio = siguiente.strip()

            if re.match(r"^X\b", siguiente_limpio):

                if re.search(rf"\b{unidades}\b", siguiente_limpio):
                    continue

            # ------------------------------------------------
            # Si llegamos aquí, no encontramos unidad
            # ------------------------------------------------

            detalle = f"{campo}: {valor}"

            if detalle not in errores:
                errores.append(detalle)

    # --------------------------------------------------------
    # CLASE
    # --------------------------------------------------------

    patron_clase = re.compile(r"\bCLASE\s+(#?\s*\d+(?:\s*/\s*\d+)?#?)", re.IGNORECASE)

    for coincidencia in patron_clase.finditer(texto_mayusculas):

        valor = coincidencia.group(1).strip()

        siguiente = texto_mayusculas[coincidencia.end() : coincidencia.end() + 25]

        # No marcar:
        # CLASE I
        # CLASE II
        # CLASE III
        # CLASE 1 DIV. 1&2
        # etc.
        if re.match(r"\s*[,.\-]?\s*DIV\b", siguiente):
            continue

        # Si tiene #, está correctamente especificada
        if "#" in valor:
            continue

        detalle = f"CLASE: {valor}"

        if detalle not in errores:
            errores.append(detalle)

    return errores


# ============================================================

# LEER ARCHIVO

# ============================================================

print("Leyendo archivo...")

wb = load_workbook(ARCHIVO_ENTRADA, data_only=True)

ws = wb.active


# ============================================================

# IDENTIFICAR COLUMNAS

# ============================================================

encabezados = {}

for numero_columna, celda in enumerate(ws[1], start=1):

    if celda.value is not None:

        encabezado = str(celda.value).strip().upper()

        encabezados[encabezado] = numero_columna


col_codigo = encabezados.get("CODIGO")

col_descripcion = encabezados.get("DESCRIPCIÓN")

if col_descripcion is None:

    col_descripcion = encabezados.get("DESCRIPCION")


if col_codigo is None:

    raise ValueError("No se encontró la columna CODIGO.")

if col_descripcion is None:

    raise ValueError("No se encontró la columna DESCRIPCIÓN.")


# ============================================================

# CREAR ARCHIVO DE DIAGNÓSTICO

# ============================================================

wb_salida = Workbook()

ws_salida = wb_salida.active

ws_salida.title = "Diagnostico"


encabezados_salida = [
    "Codigo",
    "Descripción",
    "PALABRA DUPLICADA",
    "USO DE MINUSCULAS",
    "CARACTERES INVALIDOS",
    "MISSING UNITS",
    "DETALLE",
]

ws_salida.append(encabezados_salida)


# ============================================================

# PROCESAR ARTÍCULOS

# ============================================================

total_articulos = 0

total_duplicadas = 0

total_minusculas = 0

total_invalidos = 0

total_missing_units = 0


for fila in ws.iter_rows(min_row=2, values_only=True):

    codigo = fila[col_codigo - 1]

    descripcion = fila[col_descripcion - 1]

    if descripcion is None:

        descripcion = ""

    descripcion = str(descripcion)

    total_articulos += 1

    # --------------------------------------------

    # PALABRAS DUPLICADAS

    # --------------------------------------------

    duplicadas = detectar_palabras_duplicadas(descripcion)

    # --------------------------------------------

    # MINÚSCULAS

    # --------------------------------------------

    minusculas = detectar_minusculas(descripcion)

    # --------------------------------------------

    # CARACTERES INVÁLIDOS

    # --------------------------------------------

    invalidos = detectar_caracteres_invalidos(descripcion)

    # --------------------------------------------

    # MISSING UNITS

    # --------------------------------------------

    missing_units = detectar_missing_units(descripcion)

    # --------------------------------------------

    # CONTADORES

    # --------------------------------------------

    if duplicadas:

        total_duplicadas += 1

    if minusculas:

        total_minusculas += 1

    if invalidos:

        total_invalidos += 1

    if missing_units:

        total_missing_units += 1

    # --------------------------------------------

    # DETALLE

    # --------------------------------------------

    detalles = []

    if duplicadas:

        detalles.append("DUPLICADAS: " + ", ".join(duplicadas))

    if minusculas:

        detalles.append("MINUSCULAS: " + ", ".join(minusculas))

    if invalidos:

        detalles.append("INVALIDOS: " + ", ".join(invalidos))

    if missing_units:

        detalles.append("MISSING UNITS: " + ", ".join(missing_units))

    detalle_final = " | ".join(detalles)

    # --------------------------------------------

    # AGREGAR FILA

    # --------------------------------------------

    ws_salida.append(
        [
            codigo,
            descripcion,
            ", ".join(duplicadas),
            ", ".join(minusculas),
            ", ".join(invalidos),
            ", ".join(missing_units),
            detalle_final,
        ]
    )


# ============================================================

# FORMATO

# ============================================================

ws_salida.freeze_panes = "A2"

anchos = {
    "A": 14,
    "B": 90,
    "C": 25,
    "D": 25,
    "E": 25,
    "F": 35,
    "G": 100,
}

for columna, ancho in anchos.items():

    ws_salida.column_dimensions[columna].width = ancho


# ============================================================

# GUARDAR

# ============================================================

wb_salida.save(ARCHIVO_SALIDA)


# ============================================================

# RESULTADOS

# ============================================================

print()

print("=" * 60)

print("DIAGNÓSTICO DE ORTOGRAFÍA")

print("=" * 60)

print(f"Artículos revisados:       {total_articulos}")

print(f"Palabras duplicadas:       {total_duplicadas}")

print(f"Uso de minúsculas:         {total_minusculas}")

print(f"Caracteres inválidos:      {total_invalidos}")

print(f"Missing units:              {total_missing_units}")

print()

print("Archivo generado correctamente:")

print(ARCHIVO_SALIDA)

print("=" * 60)
