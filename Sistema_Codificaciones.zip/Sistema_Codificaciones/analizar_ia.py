import os
import sqlite3
from datetime import datetime
from openai import OpenAI

# ============================================================
# CONFIGURACION
# ============================================================

MODELO = "gpt-5.6-luna"
BASE_DATOS = "base_datos.db"


# ============================================================
# CONEXION CON OPENAI
# ============================================================

api_key = os.getenv("OPENAI_API_KEY")

if not api_key:
    raise RuntimeError(
        "No se encontró OPENAI_API_KEY. " "Configúrala antes de ejecutar el programa."
    )

cliente = OpenAI(api_key=api_key)


# ============================================================
# CATALOGO OFICIAL
# ============================================================

CATALOGO = """
1. CLASIFICACION -> GRUPO INCORRECTO
2. CLASIFICACION -> SUBGRUPO INCORRECTO
3. DUPLICADO -> ARTICULO DUPLICADO
4. ESPECIFICACION TECNICA -> SOBRE-ESPECIFICADO
5. ESPECIFICACION TECNICA -> SUB-ESPECIFICADO
6. ESPECIFICACION TECNICA -> LLENADO INADECUADO DE PLANTILLA
7. ORTOGRAFIA -> PALABRA DUPLICADA
8. ORTOGRAFIA -> USO DE MINUSCULAS
9. ORTOGRAFIA -> FALTA DE CARACTERES DE UNIDADES DE MEDIDA
10. ORTOGRAFIA -> REDACCION INCORRECTA
11. ORTOGRAFIA -> USO INCORRECTO DE CARACTERES
12. OK -> OK
"""


# ============================================================
# ANALISIS
# ============================================================


def analizar_articulo(codigo, grupo, subgrupo, descripcion):

    instrucciones = f"""
Eres un revisor experto de artículos para un catálogo técnico
industrial.

Tu trabajo es evaluar si la descripción del artículo está
correctamente codificada.

IMPORTANTE:

Solo puedes utilizar UNA de las siguientes combinaciones:

{CATALOGO}

No puedes inventar otra observación ni otra subobservación.

Debes analizar conjuntamente:

- Código
- Grupo
- Subgrupo
- Descripción

No debes marcar un artículo como SUB-ESPECIFICADO solamente
porque su descripción sea corta.

Una descripción corta puede ser correcta si contiene las
características suficientes para identificar el artículo.

Tampoco debes marcar como SOBRE-ESPECIFICADO solamente porque
la descripción sea larga.

Debes evaluar si la información realmente corresponde al tipo
de artículo y permite identificarlo adecuadamente.

Para LLENADO INADECUADO DE PLANTILLA debes buscar situaciones
en las que la información técnica esté claramente colocada de
manera incorrecta o exista una estructura de campos incoherente.

Para ORTOGRAFIA debes identificar problemas reales de escritura,
caracteres, unidades o palabras.

Para CLASIFICACION debes determinar si el artículo parece
pertenecer a un grupo o subgrupo diferente al indicado.

Para DUPLICADO debes considerar si existen evidencias de que
el artículo representa esencialmente el mismo artículo que
otro código. Si no se proporciona información suficiente para
compararlo con otro código, no debes inventar un duplicado.

Si no existe un error suficientemente claro, utiliza:

OK -> OK

La confianza debe representar qué tan seguro estás de tu
clasificación, no qué tan grave es el error.

Responde ÚNICAMENTE en formato JSON con esta estructura:

{{
    "observacion": "...",
    "subobservacion": "...",
    "confianza": 0,
    "motivo": "...",
    "severidad": "NINGUNA"
}}

La confianza debe ser un número entero de 0 a 100.

La severidad solamente puede ser:

- NINGUNA
- BAJA
- MEDIA
- ALTA
"""

    datos = f"""
Código: {codigo}
Grupo: {grupo}
Subgrupo: {subgrupo}
Descripción: {descripcion}
"""

    respuesta = cliente.responses.create(
        model=MODELO, instructions=instrucciones, input=datos
    )

    return respuesta.output_text


# ============================================================
# GUARDAR RESULTADO
# ============================================================


def guardar_revision(codigo, grupo, subgrupo, descripcion, resultado):

    import json

    datos = json.loads(resultado)

    conexion = sqlite3.connect(BASE_DATOS)
    cursor = conexion.cursor()

    cursor.execute(
        """
        INSERT INTO revisiones_ia (
            codigo,
            descripcion,
            grupo,
            subgrupo,
            observacion,
            subobservacion,
            confianza,
            motivo,
            severidad,
            fecha
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """,
        (
            codigo,
            descripcion,
            grupo,
            subgrupo,
            datos["observacion"],
            datos["subobservacion"],
            datos["confianza"],
            datos["motivo"],
            datos["severidad"],
            datetime.now().isoformat(timespec="seconds"),
        ),
    )

    conexion.commit()
    conexion.close()

    return datos


# ============================================================
# PRUEBA
# ============================================================

if __name__ == "__main__":

    codigo = "0201248"

    grupo = "02"

    subgrupo = "01"

    descripcion = (
        "CODO, 90°, DE, ACERO AL CARBÓN, "
        'DIAMETRO 3", A-537, EXTREMOS RANURADOS, '
        "CLASE 300, UL/FM"
    )

    print("=" * 60)
    print("PRUEBA DE ANALISIS CON IA")
    print("=" * 60)

    print("\nArtículo:")
    print(descripcion)

    print("\nAnalizando...")

    resultado = analizar_articulo(codigo, grupo, subgrupo, descripcion)

    datos = guardar_revision(codigo, grupo, subgrupo, descripcion, resultado)

    print("\nRESULTADO IA")
    print("-" * 60)

    print(f"Observación:    {datos['observacion']}")
    print(f"Subobservación: {datos['subobservacion']}")
    print(f"Confianza:      {datos['confianza']}%")
    print(f"Severidad:      {datos['severidad']}")
    print(f"Motivo:         {datos['motivo']}")

    print("\nResultado guardado en revisiones_ia.")
