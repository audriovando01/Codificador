# -*- coding: utf-8 -*-
"""
IMPORTAR LISTA OFICIAL DE USUARIOS A SQLITE
==========================================

Fuente única:
    LISTA DE USUARIOS.xlsx

Hoja:
    Lista de usuarios

Columnas:
    C = Numero de empleado
    D = Nombre empleado

La tabla SQLite "usuarios" se reemplaza completamente con el contenido
actual del archivo. Así no quedan registros antiguos o sobrantes.
"""

import os
import sqlite3
import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DB_PATH = os.path.join(BASE_DIR, "base_datos.db")
ARCHIVO_USUARIOS = os.path.join(BASE_DIR, "LISTA DE USUARIOS.xlsx")

HOJA_USUARIOS = "Lista de usuarios"


def normalizar_usuario(valor):
    if pd.isna(valor):
        return ""

    texto = str(valor).strip()

    if texto.endswith(".0"):
        texto = texto[:-2]

    return texto


def importar():
    if not os.path.exists(ARCHIVO_USUARIOS):
        raise FileNotFoundError(
            "No encontré el archivo oficial de usuarios:\n"
            f"{ARCHIVO_USUARIOS}\n\n"
            "Guarda LISTA DE USUARIOS.xlsx en la misma carpeta "
            "que este programa."
        )

    df = pd.read_excel(
        ARCHIVO_USUARIOS,
        sheet_name=HOJA_USUARIOS,
        usecols="C:D",
        header=3,
        dtype=str,
        engine="openpyxl",
    )

    if df.shape[1] != 2:
        raise ValueError(
            'La hoja "Lista de usuarios" debe contener el número '
            "de empleado en C y el nombre en D."
        )

    df.columns = ["usuario", "nombre_usuario"]

    registros = []

    for _, fila in df.iterrows():
        usuario = normalizar_usuario(fila["usuario"])

        nombre = (
            ""
            if pd.isna(fila["nombre_usuario"])
            else str(fila["nombre_usuario"]).strip()
        )

        if usuario and nombre:
            registros.append((usuario, nombre))

    # Validar duplicados antes de tocar la base de datos.
    usuarios = [usuario for usuario, _ in registros]
    duplicados = sorted(
        {usuario for usuario in usuarios if usuarios.count(usuario) > 1}
    )

    if duplicados:
        raise ValueError(
            "La lista oficial contiene números de usuario duplicados:\n"
            + "\n".join(duplicados)
        )

    conn = sqlite3.connect(DB_PATH)

    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                usuario TEXT PRIMARY KEY,
                nombre_usuario TEXT NOT NULL
            )
            """)

        # LISTA DE USUARIOS.xlsx es ahora la fuente oficial.
        # Se elimina el contenido anterior para evitar registros obsoletos.
        conn.execute("DELETE FROM usuarios")

        conn.executemany(
            """
            INSERT INTO usuarios (usuario, nombre_usuario)
            VALUES (?, ?)
            """,
            registros,
        )

        conn.commit()

        total_bd = conn.execute("SELECT COUNT(*) FROM usuarios").fetchone()[0]

    finally:
        conn.close()

    print("=" * 72)
    print("CATALOGO OFICIAL DE USUARIOS IMPORTADO")
    print("=" * 72)
    print(f"Archivo:              {ARCHIVO_USUARIOS}")
    print(f"Usuarios leídos:      {len(registros)}")
    print(f"Usuarios únicos:      {len(set(usuarios))}")
    print(f"Total tabla usuarios: {total_bd}")
    print(f"Base SQLite:          {DB_PATH}")
    print("=" * 72)


if __name__ == "__main__":
    importar()
