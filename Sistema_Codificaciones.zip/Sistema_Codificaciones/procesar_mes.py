import sqlite3
import openpyxl
import os

# ============================================================
# CONFIGURACIÓN
# ============================================================

ARCHIVO_EXCEL = r"C:\Users\aovandon\Desktop\NUVOIL\ALMACEN\CODIFICACION ALMACEN\REVISION DE CODIFICACION\HISTORICO CODIFICACION.xlsx"

HOJA_MES = "MES ACTUAL"

ARCHIVO_BD = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "base_datos.db"
)

# ============================================================
# VERIFICAR ARCHIVO
# ============================================================

if not os.path.exists(ARCHIVO_EXCEL):
    print("ERROR: No se encontró el archivo Excel.")
    print(ARCHIVO_EXCEL)
    input("\nPresiona ENTER para salir...")
    exit()

# ============================================================
# ABRIR EXCEL
# ============================================================

print("Abriendo archivo Excel...")

libro = openpyxl.load_workbook(
    ARCHIVO_EXCEL,
    read_only=True,
    data_only=True
)

if HOJA_MES not in libro.sheetnames:
    print(f"ERROR: No existe la hoja '{HOJA_MES}'.")
    print("Hojas encontradas:", libro.sheetnames)
    input("\nPresiona ENTER para salir...")
    exit()

hoja = libro[HOJA_MES]

# ============================================================
# LOCALIZAR COLUMNA DE CÓDIGOS
# ============================================================

fila_encabezados = next(
    hoja.iter_rows(
        min_row=1,
        max_row=1,
        values_only=True
    )
)

columna_codigos = None

for posicion, encabezado in enumerate(
    fila_encabezados,
    start=1
):
    if encabezado is not None:

        texto = str(encabezado).strip().upper()

        if texto in ("CODIGO", "CODIGOS", "CÓDIGO", "CÓDIGOS"):
            columna_codigos = posicion
            break

if columna_codigos is None:
    print("ERROR: No se encontró la columna de códigos.")
    input("\nPresiona ENTER para salir...")
    exit()

print(f"Columna de códigos encontrada: {columna_codigos}")

# ============================================================
# CONECTAR A SQLITE
# ============================================================

conexion = sqlite3.connect(ARCHIVO_BD)
cursor = conexion.cursor()

# ============================================================
# CARGAR CÓDIGOS HISTÓRICOS EN MEMORIA
# ============================================================

print("Cargando códigos históricos...")

cursor.execute("""
    SELECT codigo
    FROM articulos_historico
""")

codigos_historicos = {
    fila[0]
    for fila in cursor.fetchall()
}

print(
    f"Códigos históricos disponibles: "
    f"{len(codigos_historicos)}"
)

# ============================================================
# COMPARAR MES ACTUAL
# ============================================================

total_leidos = 0
total_nuevos = 0
total_existentes = 0
total_vacios = 0

print("\nComparando códigos...\n")

for fila in hoja.iter_rows(
    min_row=2,
    min_col=columna_codigos,
    max_col=columna_codigos,
    values_only=True
):

    codigo = fila[0]

    if codigo is None:
        total_vacios += 1
        continue

    codigo = str(codigo).strip()

    if not codigo:
        total_vacios += 1
        continue

    total_leidos += 1

    if codigo in codigos_historicos:
        estado = "YA EXISTIA"
        total_existentes += 1
    else:
        estado = "NUEVO"
        total_nuevos += 1

    # Mostrar solamente algunos ejemplos
    if total_leidos <= 10:
        print(
            f"Código: {codigo} "
            f"→ {estado}"
        )

# ============================================================
# RESULTADOS
# ============================================================

print("\n========================================")
print("       RESULTADO DE LA COMPARACIÓN")
print("========================================")
print(f"Códigos leídos:       {total_leidos}")
print(f"Códigos NUEVOS:       {total_nuevos}")
print(f"Códigos YA EXISTÍAN:  {total_existentes}")
print(f"Celdas vacías:        {total_vacios}")
print("========================================")

conexion.close()
libro.close()

input("\nPresiona ENTER para salir...")