import os
import re
import sqlite3
import pandas as pd

# ============================================================
# CONFIGURACION
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "base_datos.db")

# Puedes cambiar esta ruta si mueves el archivo.
EXCEL_CATALOGO = os.path.join(
    BASE_DIR, "GRUPOS CODIFICADOR DE ARTICULOS (Actualizado).xlsx"
)
HOJA_CATALOGO = "GRUPOS"


# ============================================================
# FUNCIONES DE LIMPIEZA
# ============================================================
def limpiar_texto(valor):
    if pd.isna(valor):
        return ""
    return str(valor).strip()


def limpiar_codigo(valor):
    """Conserva grupo/subgrupo como texto de 2 digitos cuando son numericos."""
    texto = limpiar_texto(valor)
    if not texto:
        return ""

    # Excel a veces entrega 1.0 aunque conceptualmente sea "01".
    if re.fullmatch(r"\d+(?:\.0+)?", texto):
        numero = int(float(texto))
        return f"{numero:02d}"

    return texto


def separar_determinante(determinante):
    """
    Convierte por ejemplo:
      "TUBO"+DIAMETRO*+CEDULA+MATERIAL*

    en una lista ordenada de elementos.

    Reglas:
    - Texto entre comillas => TEXTO_FIJO
    - Elemento sin comillas => CAMPO
    - * al final => obligatorio
    """
    determinante = limpiar_texto(determinante)
    if not determinante:
        return []

    elementos = []
    actual = []
    entre_comillas = False

    for caracter in determinante:
        if caracter == '"':
            entre_comillas = not entre_comillas
            actual.append(caracter)
        elif caracter == "+" and not entre_comillas:
            token = "".join(actual).strip()
            if token:
                elementos.append(token)
            actual = []
        else:
            actual.append(caracter)

    token = "".join(actual).strip()
    if token:
        elementos.append(token)

    resultado = []

    for orden, token in enumerate(elementos, start=1):
        token = token.strip()
        obligatorio = token.endswith("*")
        if obligatorio:
            token = token[:-1].strip()

        es_texto_fijo = (
            len(token) >= 2 and token.startswith('"') and token.endswith('"')
        )

        if es_texto_fijo:
            nombre = token[1:-1].strip()
            tipo = "TEXTO_FIJO"
            # El asterisco se interpreta solamente para campos.
            obligatorio = False
        else:
            nombre = token.strip('"').strip()
            tipo = "CAMPO"

        if not nombre:
            continue

        resultado.append(
            {
                "orden": orden,
                "elemento": nombre,
                "tipo_elemento": tipo,
                "obligatorio": 1 if obligatorio else 0,
            }
        )

    return resultado


# ============================================================
# BASE DE DATOS
# ============================================================
def crear_tablas(conn):
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS catalogo_subgrupos (
            grupo TEXT NOT NULL,
            subgrupo TEXT NOT NULL,
            especialidad TEXT,
            nombre_grupo TEXT,
            nombre_subgrupo TEXT,
            ica TEXT,
            um TEXT,
            determinante TEXT,
            PRIMARY KEY (grupo, subgrupo)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS campos_plantilla (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            grupo TEXT NOT NULL,
            subgrupo TEXT NOT NULL,
            orden INTEGER NOT NULL,
            elemento TEXT NOT NULL,
            tipo_elemento TEXT NOT NULL CHECK (
                tipo_elemento IN ('TEXTO_FIJO', 'CAMPO')
            ),
            obligatorio INTEGER NOT NULL DEFAULT 0 CHECK (
                obligatorio IN (0, 1)
            ),
            UNIQUE (grupo, subgrupo, orden),
            FOREIGN KEY (grupo, subgrupo)
                REFERENCES catalogo_subgrupos (grupo, subgrupo)
                ON DELETE CASCADE
        )
    """)

    cursor.execute("""
        CREATE INDEX IF NOT EXISTS idx_campos_plantilla_busqueda
        ON campos_plantilla (grupo, subgrupo, tipo_elemento, obligatorio)
    """)

    conn.commit()


def importar_catalogo():
    if not os.path.exists(EXCEL_CATALOGO):
        raise FileNotFoundError(
            "No se encontro el Excel del catalogo en:\n"
            f"{EXCEL_CATALOGO}\n\n"
            "Actualiza la variable EXCEL_CATALOGO al inicio del archivo."
        )

    print("=" * 68)
    print("IMPORTACION DE GRUPOS, SUBGRUPOS Y PLANTILLAS")
    print("=" * 68)
    print(f"Excel: {EXCEL_CATALOGO}")
    print(f"Base de datos: {DB_PATH}")
    print()

    df = pd.read_excel(
        EXCEL_CATALOGO,
        sheet_name=HOJA_CATALOGO,
        dtype=str,
        engine="openpyxl",
    )

    # Normalizar encabezados para evitar problemas por espacios.
    df.columns = [str(c).strip().upper() for c in df.columns]

    columnas_requeridas = {
        "ESPECIALIDAD",
        "GRUPO",
        "NOMBRE GRUPO",
        "SUBGRUPO",
        "NOMBRE SUBGRUPO",
        "ICA",
        "UM",
        "DETERMINANTE",
    }

    faltantes = columnas_requeridas - set(df.columns)
    if faltantes:
        raise ValueError(
            "Faltan columnas necesarias en la hoja GRUPOS: "
            + ", ".join(sorted(faltantes))
        )

    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")

    try:
        crear_tablas(conn)
        cursor = conn.cursor()

        # La importacion es una sincronizacion completa del catalogo.
        # No toca articulos_historico ni ninguna otra tabla existente.
        cursor.execute("DELETE FROM campos_plantilla")
        cursor.execute("DELETE FROM catalogo_subgrupos")

        subgrupos_importados = 0
        elementos_importados = 0
        campos_importados = 0
        obligatorios_importados = 0
        textos_fijos_importados = 0
        sin_determinante = []
        claves_duplicadas = []
        claves_vistas = set()

        for _, fila in df.iterrows():
            grupo = limpiar_codigo(fila["GRUPO"])
            subgrupo = limpiar_codigo(fila["SUBGRUPO"])

            # Ignorar filas totalmente vacias o de resumen.
            if not grupo or not subgrupo:
                continue

            clave = (grupo, subgrupo)
            if clave in claves_vistas:
                claves_duplicadas.append(clave)
                continue
            claves_vistas.add(clave)

            especialidad = limpiar_texto(fila["ESPECIALIDAD"])
            nombre_grupo = limpiar_texto(fila["NOMBRE GRUPO"])
            nombre_subgrupo = limpiar_texto(fila["NOMBRE SUBGRUPO"])
            ica = limpiar_texto(fila["ICA"])
            um = limpiar_texto(fila["UM"])
            determinante = limpiar_texto(fila["DETERMINANTE"])

            cursor.execute(
                """
                INSERT INTO catalogo_subgrupos (
                    grupo, subgrupo, especialidad, nombre_grupo,
                    nombre_subgrupo, ica, um, determinante
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    grupo,
                    subgrupo,
                    especialidad,
                    nombre_grupo,
                    nombre_subgrupo,
                    ica,
                    um,
                    determinante,
                ),
            )

            subgrupos_importados += 1

            elementos = separar_determinante(determinante)

            if not elementos:
                sin_determinante.append((grupo, subgrupo, nombre_subgrupo))

            for elemento in elementos:
                cursor.execute(
                    """
                    INSERT INTO campos_plantilla (
                        grupo, subgrupo, orden, elemento,
                        tipo_elemento, obligatorio
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """,
                    (
                        grupo,
                        subgrupo,
                        elemento["orden"],
                        elemento["elemento"],
                        elemento["tipo_elemento"],
                        elemento["obligatorio"],
                    ),
                )

                elementos_importados += 1

                if elemento["tipo_elemento"] == "CAMPO":
                    campos_importados += 1
                    if elemento["obligatorio"]:
                        obligatorios_importados += 1
                else:
                    textos_fijos_importados += 1

        conn.commit()

        print("Importacion terminada correctamente.")
        print("-" * 68)
        print(f"Subgrupos importados:        {subgrupos_importados}")
        print(f"Elementos de plantilla:      {elementos_importados}")
        print(f"Campos de plantilla:         {campos_importados}")
        print(f"Campos obligatorios (*):     {obligatorios_importados}")
        print(f"Textos fijos:                {textos_fijos_importados}")
        print(f"Sin determinante:            {len(sin_determinante)}")
        print(f"Claves duplicadas omitidas:  {len(claves_duplicadas)}")

        # Verificacion de ejemplo: primeros 5 catalogos.
        print("\nEJEMPLOS IMPORTADOS")
        print("-" * 68)
        ejemplos = cursor.execute("""
            SELECT grupo, subgrupo, nombre_subgrupo
            FROM catalogo_subgrupos
            ORDER BY grupo, subgrupo
            LIMIT 5
        """).fetchall()

        for grupo, subgrupo, nombre in ejemplos:
            print(f"{grupo}-{subgrupo} | {nombre}")
            campos = cursor.execute(
                """
                SELECT orden, elemento, tipo_elemento, obligatorio
                FROM campos_plantilla
                WHERE grupo = ? AND subgrupo = ?
                ORDER BY orden
            """,
                (grupo, subgrupo),
            ).fetchall()

            for orden, elemento, tipo, obligatorio in campos:
                marca = " *" if obligatorio else ""
                print(f"   {orden:02d}. [{tipo}] {elemento}{marca}")
            print()

        if sin_determinante:
            print("SUBGRUPOS SIN DETERMINANTE")
            print("-" * 68)
            for grupo, subgrupo, nombre in sin_determinante[:20]:
                print(f"- {grupo}-{subgrupo}: {nombre}")
            if len(sin_determinante) > 20:
                print(f"... y {len(sin_determinante) - 20} mas")

        if claves_duplicadas:
            print("\nADVERTENCIA: claves GRUPO/SUBGRUPO duplicadas en el Excel")
            print("-" * 68)
            for clave in claves_duplicadas[:20]:
                print(f"- {clave[0]}-{clave[1]}")

        print("=" * 68)
        print("La base de datos ya contiene el catalogo tecnico.")
        print("=" * 68)

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    importar_catalogo()
