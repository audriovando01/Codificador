(() => {
    const sidebar = document.getElementById("sidebar");
    const overlay = document.getElementById("sidebarOverlay");
    const menu = document.getElementById("mobileMenu");

    if (menu && sidebar && overlay) {
        const closeMenu = () => {
            sidebar.classList.remove("open");
            overlay.classList.remove("visible");
        };

        menu.addEventListener("click", () => {
            sidebar.classList.toggle("open");
            overlay.classList.toggle("visible");
        });

        overlay.addEventListener("click", closeMenu);
    }

    const input = document.getElementById("fileInput");
    const selected = document.getElementById("selectedFile");
    const dropzone = document.getElementById("dropzone");
    const form = document.getElementById("uploadForm");
    const modal = document.getElementById("loadingModal");

    const showSelected = () => {
        if (!input || !selected) return;
        const file = input.files && input.files[0];
        if (file) {
            selected.textContent = file.name;
            selected.classList.add("has-file");
        } else {
            selected.textContent = "Ningún archivo seleccionado";
            selected.classList.remove("has-file");
        }
    };

    if (input) {
        input.addEventListener("change", showSelected);
    }

    if (dropzone && input) {
        ["dragenter", "dragover"].forEach(evt => {
            dropzone.addEventListener(evt, e => {
                e.preventDefault();
                dropzone.classList.add("dragover");
            });
        });

        ["dragleave", "drop"].forEach(evt => {
            dropzone.addEventListener(evt, e => {
                e.preventDefault();
                dropzone.classList.remove("dragover");
            });
        });

        dropzone.addEventListener("drop", e => {
            if (e.dataTransfer.files.length) {
                input.files = e.dataTransfer.files;
                showSelected();
            }
        });
    }

    if (form && modal) {
        form.addEventListener("submit", () => {
            modal.classList.add("visible");
            modal.setAttribute("aria-hidden", "false");
        });
    }


    // =========================================================
    // FILTROS POR COLUMNA - PAGINA CATALOGO
    // =========================================================
    const catalogTable = document.getElementById("catalogTable");
    const clearColumnFilters = document.getElementById("clearColumnFilters");
    const catalogFilterSummary = document.getElementById("catalogFilterSummary");

    if (catalogTable) {
        const filterSelects = Array.from(
            catalogTable.querySelectorAll(".column-filter")
        );
        const rows = Array.from(
            catalogTable.querySelectorAll("tbody tr")
        ).filter(row => !row.querySelector(".no-results"));

        const normalize = value =>
            (value || "").trim().replace(/\s+/g, " ").toUpperCase();

        // Genera las opciones de cada filtro a partir de las filas visibles
        // cargadas desde SQLite.
        filterSelects.forEach(select => {
            const column = Number(select.dataset.column);

            const values = [...new Set(
                rows
                    .map(row => {
                        const cell = row.cells[column];
                        return cell ? cell.textContent.trim() : "";
                    })
                    .filter(Boolean)
            )].sort((a, b) =>
                a.localeCompare(b, "es", { numeric: true, sensitivity: "base" })
            );

            values.forEach(value => {
                const option = document.createElement("option");
                option.value = value;
                option.textContent = value;
                select.appendChild(option);
            });
        });

        const applyColumnFilters = () => {
            let visibleCount = 0;

            rows.forEach(row => {
                const matches = filterSelects.every(select => {
                    if (!select.value) return true;

                    const column = Number(select.dataset.column);
                    const cell = row.cells[column];
                    const cellValue = cell ? normalize(cell.textContent) : "";

                    return cellValue === normalize(select.value);
                });

                row.style.display = matches ? "" : "none";
                if (matches) visibleCount += 1;
            });

            if (catalogFilterSummary) {
                catalogFilterSummary.textContent =
                    `Mostrando ${visibleCount} de ${rows.length} registros`;
            }
        };

        filterSelects.forEach(select => {
            select.addEventListener("change", applyColumnFilters);
        });

        if (clearColumnFilters) {
            clearColumnFilters.addEventListener("click", () => {
                filterSelects.forEach(select => {
                    select.value = "";
                });
                applyColumnFilters();
            });
        }

        applyColumnFilters();
    }



    // =========================================================
    // FILTROS POR COLUMNA - USUARIOS CON DESVIACIONES 2026
    // =========================================================
    const annualUsersTable = document.getElementById("annualUsersTable");
    const clearAnnualUsersFilters = document.getElementById("clearAnnualUsersFilters");
    const annualUsersFilterSummary = document.getElementById("annualUsersFilterSummary");

    if (annualUsersTable) {
        const filters = Array.from(
            annualUsersTable.querySelectorAll(".annual-column-filter")
        );

        const dataRows = Array.from(
            annualUsersTable.querySelectorAll("tbody tr.annual-data-row")
        );

        const totalRows = Array.from(
            annualUsersTable.querySelectorAll("tbody tr.annual-month-total-row")
        );

        const normalizeAnnual = value =>
            (value || "").trim().replace(/\s+/g, " ").toUpperCase();

        filters.forEach(select => {
            const column = Number(select.dataset.column);

            const values = [...new Set(
                dataRows.map(row => {
                    const cell = row.cells[column];
                    return cell ? cell.textContent.trim() : "";
                }).filter(Boolean)
            )].sort((a, b) =>
                a.localeCompare(b, "es", { numeric: true, sensitivity: "base" })
            );

            values.forEach(value => {
                const option = document.createElement("option");
                option.value = value;
                option.textContent = value;
                select.appendChild(option);
            });
        });

        const applyAnnualFilters = () => {
            let visible = 0;
            const visibleMonths = new Set();

            dataRows.forEach(row => {
                const matches = filters.every(select => {
                    if (!select.value) return true;

                    const column = Number(select.dataset.column);
                    const cell = row.cells[column];
                    const cellValue = cell ? normalizeAnnual(cell.textContent) : "";

                    return cellValue === normalizeAnnual(select.value);
                });

                row.style.display = matches ? "" : "none";

                if (matches) {
                    visible += 1;
                    visibleMonths.add(normalizeAnnual(row.dataset.month));
                }
            });

            totalRows.forEach(row => {
                const month = normalizeAnnual(row.dataset.month);
                row.style.display = visibleMonths.has(month) ? "" : "none";
            });

            if (annualUsersFilterSummary) {
                annualUsersFilterSummary.textContent =
                    `Mostrando ${visible} de ${dataRows.length} registros`;
            }
        };

        filters.forEach(select => {
            select.addEventListener("change", applyAnnualFilters);
        });

        if (clearAnnualUsersFilters) {
            clearAnnualUsersFilters.addEventListener("click", () => {
                filters.forEach(select => {
                    select.value = "";
                });
                applyAnnualFilters();
            });
        }

        applyAnnualFilters();
    }


    // =========================================================
    // GRAFICA - DESVIACIONES MENSUALES
    // =========================================================
    const monthlyChartHost = document.getElementById("monthlyDeviationChart");
    const monthlyChartDataNode = document.getElementById("monthlyDeviationChartData");
    const monthlyLegend = document.getElementById("monthlyDeviationLegend");
    const monthlyChartMonth = document.getElementById("monthlyChartMonth");

    if (monthlyChartHost && monthlyChartDataNode) {
        try {
            const payload = JSON.parse(monthlyChartDataNode.textContent || "{}");
            const sourceSeries = Array.isArray(payload.series) ? payload.series : [];

            // Solo los cuatro tipos oficiales. Se excluye Total general.
            const categories = [
                "Clasificación",
                "Duplicado",
                "Especificación Técnica",
                "Ortografía"
            ];

            // Conservamos los colores por MES aunque se filtre uno solo.
            const monthColors = [
                "#245b23",
                "#2f7628",
                "#3c922d",
                "#4ea53a",
                "#65b653",
                "#7abf6b",
                "#91c987",
                "#a7d2a1",
                "#badcb5",
                "#cce5c8",
                "#dcebd8",
                "#e8f2e5"
            ];

            const allSeries = sourceSeries.map((serie, index) => ({
                mes: String(serie.mes || ""),
                valores: Array.isArray(serie.valores)
                    ? serie.valores.slice(0, 4).map(value => Number(value) || 0)
                    : [0, 0, 0, 0],
                color: monthColors[index % monthColors.length]
            }));

            const renderLegend = series => {
                if (!monthlyLegend) return;

                monthlyLegend.innerHTML = "";

                series.forEach(serie => {
                    const item = document.createElement("div");
                    item.className = "monthly-legend-item";

                    const swatch = document.createElement("span");
                    swatch.className = "monthly-legend-swatch";
                    swatch.style.backgroundColor = serie.color;

                    const label = document.createElement("span");
                    label.textContent = serie.mes;

                    item.appendChild(swatch);
                    item.appendChild(label);
                    monthlyLegend.appendChild(item);
                });
            };

            const niceMaximum = rawMax => {
                const maxValue = Math.max(1, Number(rawMax) || 1);

                let step = 10;
                if (maxValue > 50) step = 20;
                if (maxValue > 100) step = 50;
                if (maxValue > 300) step = 100;
                if (maxValue > 700) step = 200;
                if (maxValue > 1500) step = 500;

                return Math.max(step, Math.ceil(maxValue / step) * step);
            };

            const createSvgText = (svgNS, attrs, value, className) => {
                const text = document.createElementNS(svgNS, "text");

                Object.entries(attrs).forEach(([name, attrValue]) => {
                    text.setAttribute(name, attrValue);
                });

                if (className) {
                    text.setAttribute("class", className);
                }

                text.textContent = value;
                return text;
            };

            const renderMonthlyChart = selectedMonth => {
                const selected = String(selectedMonth || "TODOS");

                const series = selected === "TODOS"
                    ? allSeries
                    : allSeries.filter(serie => serie.mes === selected);

                if (!series.length) {
                    renderLegend([]);
                    monthlyChartHost.innerHTML =
                        '<div class="chart-error">No hay datos disponibles para el mes seleccionado.</div>';
                    return;
                }

                renderLegend(series);

                const values = series.flatMap(serie => serie.valores);
                const maxValue = Math.max(1, ...values);
                const yMax = niceMaximum(maxValue);

                // Dimensiones.
                const width = 960;
                const height = 470;
                const margin = {
                    top: 38,
                    right: 28,
                    bottom: 82,
                    left: 64
                };

                const chartWidth = width - margin.left - margin.right;
                const chartHeight = height - margin.top - margin.bottom;

                const svgNS = "http://www.w3.org/2000/svg";
                const svg = document.createElementNS(svgNS, "svg");

                svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
                svg.setAttribute("class", "monthly-svg-chart");
                svg.setAttribute("role", "presentation");

                // Cuadrícula horizontal y eje Y.
                const ticks = 5;

                for (let i = 0; i <= ticks; i += 1) {
                    const ratio = i / ticks;
                    const value = Math.round(yMax * ratio);
                    const y = margin.top + chartHeight - chartHeight * ratio;

                    const line = document.createElementNS(svgNS, "line");
                    line.setAttribute("x1", margin.left);
                    line.setAttribute("x2", margin.left + chartWidth);
                    line.setAttribute("y1", y);
                    line.setAttribute("y2", y);
                    line.setAttribute("class", "monthly-grid-line");
                    svg.appendChild(line);

                    svg.appendChild(
                        createSvgText(
                            svgNS,
                            {
                                x: margin.left - 12,
                                y: y + 4,
                                "text-anchor": "end"
                            },
                            value.toLocaleString("es-MX"),
                            "monthly-axis-label"
                        )
                    );
                }

                // Barras agrupadas.
                const categoryWidth = chartWidth / categories.length;
                const groupAvailable = categoryWidth * 0.72;
                const gap = series.length > 1 ? 3 : 0;

                const barWidth = Math.min(
                    selected === "TODOS" ? 24 : 72,
                    Math.max(
                        10,
                        (groupAvailable - gap * Math.max(0, series.length - 1))
                        / series.length
                    )
                );

                const totalBarsWidth =
                    barWidth * series.length +
                    gap * Math.max(0, series.length - 1);

                categories.forEach((category, categoryIndex) => {
                    const categoryStart =
                        margin.left + categoryIndex * categoryWidth;
                    const barsStart =
                        categoryStart + (categoryWidth - totalBarsWidth) / 2;

                    series.forEach((serie, seriesIndex) => {
                        const value = serie.valores[categoryIndex] || 0;
                        const barHeight = (value / yMax) * chartHeight;
                        const x =
                            barsStart + seriesIndex * (barWidth + gap);
                        const y =
                            margin.top + chartHeight - barHeight;

                        const rect = document.createElementNS(svgNS, "rect");
                        rect.setAttribute("x", x);
                        rect.setAttribute("y", y);
                        rect.setAttribute("width", barWidth);
                        rect.setAttribute("height", Math.max(0, barHeight));
                        rect.setAttribute("rx", 3);
                        rect.setAttribute("fill", serie.color);
                        rect.setAttribute("class", "monthly-bar");

                        const title = document.createElementNS(svgNS, "title");
                        title.textContent =
                            `${serie.mes} · ${category}: ${value.toLocaleString("es-MX")}`;
                        rect.appendChild(title);

                        svg.appendChild(rect);

                        // Mostrar valor encima de la barra.
                        if (value > 0) {
                            svg.appendChild(
                                createSvgText(
                                    svgNS,
                                    {
                                        x: x + barWidth / 2,
                                        y: Math.max(14, y - 6),
                                        "text-anchor": "middle"
                                    },
                                    value.toLocaleString("es-MX"),
                                    "monthly-value-label"
                                )
                            );
                        }
                    });

                    // Etiquetas de categorías.
                    const labelX =
                        categoryStart + categoryWidth / 2;
                    const labelY =
                        margin.top + chartHeight + 30;

                    const categoryText = document.createElementNS(svgNS, "text");
                    categoryText.setAttribute("x", labelX);
                    categoryText.setAttribute("y", labelY);
                    categoryText.setAttribute("text-anchor", "middle");
                    categoryText.setAttribute(
                        "class",
                        "monthly-category-label"
                    );

                    if (category === "Especificación Técnica") {
                        const line1 = document.createElementNS(svgNS, "tspan");
                        line1.setAttribute("x", labelX);
                        line1.setAttribute("dy", "0");
                        line1.textContent = "Especificación";

                        const line2 = document.createElementNS(svgNS, "tspan");
                        line2.setAttribute("x", labelX);
                        line2.setAttribute("dy", "15");
                        line2.textContent = "Técnica";

                        categoryText.appendChild(line1);
                        categoryText.appendChild(line2);
                    } else {
                        categoryText.textContent = category;
                    }

                    svg.appendChild(categoryText);
                });

                monthlyChartHost.replaceChildren(svg);
            };

            // Render inicial.
            renderMonthlyChart(
                monthlyChartMonth ? monthlyChartMonth.value : "TODOS"
            );

            // Filtro.
            if (monthlyChartMonth) {
                monthlyChartMonth.addEventListener("change", event => {
                    renderMonthlyChart(event.target.value);
                });
            }
        } catch (error) {
            console.error("Error en gráfica mensual:", error);
            monthlyChartHost.innerHTML =
                '<div class="chart-error">No fue posible representar la gráfica mensual.</div>';
        }
    }


    // Menu lateral desplegable
    document.querySelectorAll("[data-nav-group]").forEach(group => {
        const toggle = group.querySelector("[data-nav-toggle]");
        if (!toggle) return;

        toggle.addEventListener("click", () => {
            const isOpen = group.classList.toggle("open");
            toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
        });
    });

})();
