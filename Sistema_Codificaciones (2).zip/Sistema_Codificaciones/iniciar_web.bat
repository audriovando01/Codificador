@echo off
cd /d "%~dp0"
title Sistema de Revision de Codificaciones
echo.
echo ============================================================
echo   SISTEMA WEB DE REVISION DE CODIFICACIONES
echo ============================================================
echo.
echo Abre en tu navegador:
echo   http://127.0.0.1:5000
echo.
echo Para cerrar el sistema presiona CTRL+C.
echo.
python app.py
pause
