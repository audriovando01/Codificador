# -*- coding: utf-8 -*-
"""
SISTEMA WEB DE REVISION DE CODIFICACIONES
Interfaz Flask para el motor sistema_codificaciones.py

Ejecución:
    python app.py

Navegador:
    http://127.0.0.1:5000
"""

from __future__ import annotations

import contextlib
import io
import os
import re
import sqlite3
import shutil
import time
from datetime import datetime
from pathlib import Path
from copy import copy

import pandas as pd
from openpyxl import load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from flask import (
    Flask,
    abort,
    redirect,
    render_template,
    request,
    send_file,
    url_for,
)

import sistema_codificaciones as motor


app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 80 * 1024 * 1024

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(motor.DB_PATH)
REVISIONES_DIR = Path(motor.REVISIONES_DIR)

MESES_ORDEN = {
    "ENERO": 1, "FEBRERO": 2, "MARZO": 3, "ABRIL": 4,
    "MAYO": 5, "JUNIO": 6, "JULIO": 7, "AGOSTO": 8,
    "SEPTIEMBRE": 9, "OCTUBRE": 10, "NOVIEMBRE": 11, "DICIEMBRE": 12,
}

MESES = list(MESES_ORDEN.keys())
ANIO_ACTUAL = datetime.now().year
ANIOS_DISPONIBLES = list(range(2026, ANIO_ACTUAL + 6))

REPORTES_HISTORICOS_DIR = BASE_DIR / "reportes_historicos"
UPLOADS_TEMP_DIR = BASE_DIR / "uploads_temporales"

COLUMNAS_HISTORICAS = {
    "codigo": ["CODIGO", "CÓDIGO", "CODIGOS", "CÓDIGOS"],
    "grupo": ["GRUPO"],
    "nombre_grupo": ["NOMBRE GRUPO", "NOMBRE DE GRUPO"],
    "subgrupo": ["SUBGRUPO"],
    "nombre_subgrupo": ["NOMBRE SUBGRUPO", "NOMBRE DE SUBGRUPO"],
    "descripcion": ["DESCRIPCION", "DESCRIPCIÓN"],
    "usuario": ["USUARIO"],
    "nombre_usuario": ["NOMBRE DE USUARIO", "NOMBRE USUARIO"],
    "um": ["UM", "U.M.", "UNIDAD DE MEDIDA"],
}


# ============================================================
# UTILIDADES
# ============================================================

def nombre_seguro(nombre: str) -> str:
    nombre = os.path.basename(str(nombre or "")).strip()
    nombre = re.sub(r"[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9 ._()\-]", "_", nombre)
    nombre = nombre.strip(" .")
    return nombre or "ARCHIVO_MENSUAL.xlsx"


def conexion():
    return sqlite3.connect(DB_PATH)


def existe_tabla(nombre: str) -> bool:
    if not DB_PATH.exists():
        return False
    con = conexion()
    try:
        return con.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            (nombre,),
        ).fetchone() is not None
    finally:
        con.close()


def contar_tabla(nombre: str) -> int:
    if not existe_tabla(nombre):
        return 0
    con = conexion()
    try:
        return int(con.execute(f"SELECT COUNT(*) FROM {nombre}").fetchone()[0])
    finally:
        con.close()



def mapa_usuarios_actual() -> dict[str, str]:
    """Devuelve {numero_empleado: nombre} desde la tabla usuarios."""
    if not existe_tabla("usuarios"):
        return {}

    con = conexion()
    try:
        filas = con.execute(
            "SELECT usuario, nombre_usuario FROM usuarios"
        ).fetchall()
    finally:
        con.close()

    mapa = {}
    for usuario, nombre in filas:
        usuario = str(usuario or "").strip()
        if usuario.endswith(".0") and usuario[:-2].isdigit():
            usuario = usuario[:-2]

        nombre = str(nombre or "").strip()
        if usuario:
            mapa[usuario] = nombre

    return mapa


def aplicar_nombres_actuales_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Actualiza Nombre de Usuario en memoria usando siempre SQLite
    como fuente oficial actual.
    """
    if "Usuario" not in df.columns:
        return df

    mapa = mapa_usuarios_actual()
    if not mapa:
        return df

    usuarios = (
        df["Usuario"]
        .fillna("")
        .astype(str)
        .str.replace(r"\.0$", "", regex=True)
        .str.strip()
    )

    if "Nombre de Usuario" not in df.columns:
        posicion = min(df.columns.get_loc("Usuario") + 1, len(df.columns))
        df.insert(posicion, "Nombre de Usuario", "")

    nombres_db = usuarios.map(mapa).fillna("")
    nombres_actuales = (
        df["Nombre de Usuario"]
        .fillna("")
        .astype(str)
        .str.strip()
    )

    # Si el usuario existe actualmente en SQLite, ese nombre es el oficial.
    df["Nombre de Usuario"] = nombres_db.where(
        nombres_db.ne(""),
        nombres_actuales,
    )

    return df


def sincronizar_revision_con_usuarios(ruta: Path) -> int:
    """
    Actualiza un REVISION_INTEGRADA_*.xlsx ya generado:
    - Nombre de Usuario en Artículos (o REVISION_FINAL en archivos anteriores).

    Devuelve la cantidad de nombres que fueron modificados.
    """
    if not ruta.exists() or ruta.suffix.lower() != ".xlsx":
        return 0

    mapa = mapa_usuarios_actual()
    if not mapa:
        return 0

    try:
        wb = load_workbook(ruta)
    except Exception:
        return 0

    if "Artículos" in wb.sheetnames:
        ws = wb["Artículos"]
    elif "REVISION_FINAL" in wb.sheetnames:
        ws = wb["REVISION_FINAL"]
    else:
        wb.close()
        return 0

    encabezados = {}
    for cell in ws[1]:
        valor = str(cell.value or "").strip()
        if valor:
            encabezados[valor] = cell.column

    col_usuario = encabezados.get("Usuario")
    col_nombre = encabezados.get("Nombre de Usuario")

    if not col_usuario:
        wb.close()
        return 0

    # Si por alguna razón no existe la columna, crearla después de Usuario.
    if not col_nombre:
        ws.insert_cols(col_usuario + 1)
        col_nombre = col_usuario + 1
        ws.cell(row=1, column=col_nombre, value="Nombre de Usuario")

    cambios = 0
    no_identificados = set()

    for fila in range(2, ws.max_row + 1):
        valor_usuario = ws.cell(fila, col_usuario).value
        usuario = str(valor_usuario or "").strip()

        if usuario.endswith(".0") and usuario[:-2].isdigit():
            usuario = usuario[:-2]

        if not usuario:
            continue

        nombre_db = mapa.get(usuario, "")

        if nombre_db:
            celda_nombre = ws.cell(fila, col_nombre)
            nombre_actual = str(celda_nombre.value or "").strip()

            if nombre_actual != nombre_db:
                celda_nombre.value = nombre_db
                cambios += 1
        else:
            no_identificados.add(usuario)

    # Actualizar la lista de usuarios no identificados del RESUMEN.
    if "RESUMEN" in wb.sheetnames:
        resumen = wb["RESUMEN"]

        # La lista se maneja en columna D en el reporte integrado.
        resumen["D1"] = "USUARIOS NO IDENTIFICADOS"

        # Limpiar únicamente la columna D desde la fila 2.
        for fila in range(2, max(resumen.max_row, 2) + 1):
            resumen.cell(row=fila, column=4, value=None)

        ordenados = sorted(
            no_identificados,
            key=lambda x: (not x.isdigit(), int(x) if x.isdigit() else x),
        )

        for fila_excel, usuario in enumerate(ordenados, start=2):
            resumen.cell(row=fila_excel, column=4, value=usuario)

    try:
        wb.save(ruta)
    finally:
        wb.close()

    return cambios


def sincronizar_todas_las_revisiones() -> int:
    """Sincroniza los nombres en todas las revisiones integradas existentes."""
    REVISIONES_DIR.mkdir(parents=True, exist_ok=True)
    total_cambios = 0

    for ruta in REVISIONES_DIR.glob("REVISION_INTEGRADA_*.xlsx"):
        if ruta.name.startswith("~$"):
            continue
        try:
            total_cambios += sincronizar_revision_con_usuarios(ruta)
        except Exception:
            # Una revisión dañada no debe impedir registrar el usuario.
            continue

    return total_cambios


def leer_resultado_excel(ruta: Path) -> dict:
    datos = {
        "total": 0,
        "ok": 0,
        "revisar": 0,
        "con_observacion": 0,
        "clasificacion": 0,
        "duplicado": 0,
        "especificacion": 0,
        "ortografia": 0,
        "usuarios_no_identificados": [],
        "top_usuarios_desviaciones": [],
        "usuarios_general": 0,
        "usuarios_con_desviaciones": 0,
        "porcentaje_usuarios_desviaciones": 0.0,
        "codigos_top5": [],
        "distribucion_usuarios": [],
    }

    if not ruta.exists():
        return datos

    df = None
    for hoja_resultado in ["Artículos", "REVISION_FINAL"]:
        try:
            df = pd.read_excel(
                ruta,
                sheet_name=hoja_resultado,
                dtype=str,
                engine="openpyxl",
            )
            if hoja_resultado == "Artículos":
                df.rename(
                    columns={
                        "Observación": "Observaciones",
                        "Subobservación": "Subobservaciones",
                    },
                    inplace=True,
                )
            break
        except Exception:
            df = None

    if df is None:
        return datos

    # SQLite es la fuente actual de nombres de usuario.
    # Esto permite que las páginas reflejen altas posteriores a la revisión.
    df = aplicar_nombres_actuales_dataframe(df)

    datos["total"] = len(df)

    if "Observaciones" in df.columns:
        obs = df["Observaciones"].fillna("").astype(str).str.strip().str.upper()
        datos["ok"] = int(obs.eq("OK").sum())
        datos["revisar"] = int(obs.eq("REVISAR").sum())
        datos["clasificacion"] = int(obs.eq("CLASIFICACION").sum())
        datos["duplicado"] = int(obs.eq("DUPLICADO").sum())
        datos["especificacion"] = int(obs.eq("ESPECIFICACION TECNICA").sum())
        datos["ortografia"] = int(obs.eq("ORTOGRAFIA").sum())
        datos["con_observacion"] = (
            datos["clasificacion"]
            + datos["duplicado"]
            + datos["especificacion"]
            + datos["ortografia"]
        )

        # Métricas de usuarios del mes.
        # Desviaciones oficiales: CLASIFICACION, DUPLICADO,
        # ESPECIFICACION TECNICA y ORTOGRAFIA.
        if "Usuario" in df.columns:
            mascara_desviacion = obs.isin(
                ["CLASIFICACION", "DUPLICADO", "ESPECIFICACION TECNICA", "ORTOGRAFIA"]
            )

            usuarios_todos = (
                df["Usuario"]
                .fillna("")
                .astype(str)
                .str.replace(r"\.0$", "", regex=True)
                .str.strip()
            )

            usuarios_desviacion = usuarios_todos[mascara_desviacion]

            datos["usuarios_general"] = int(
                usuarios_todos[usuarios_todos.ne("")].nunique()
            )
            datos["usuarios_con_desviaciones"] = int(
                usuarios_desviacion[usuarios_desviacion.ne("")].nunique()
            )

            if datos["usuarios_general"] > 0:
                datos["porcentaje_usuarios_desviaciones"] = (
                    datos["usuarios_con_desviaciones"] / datos["usuarios_general"]
                ) * 100

            # Nombre de usuario disponible en el propio archivo final.
            nombres_por_usuario = {}
            if "Nombre de Usuario" in df.columns:
                nombres = (
                    df["Nombre de Usuario"]
                    .fillna("")
                    .astype(str)
                    .str.strip()
                )
                for usuario, nombre in zip(usuarios_todos, nombres):
                    if usuario and nombre and usuario not in nombres_por_usuario:
                        nombres_por_usuario[usuario] = nombre

            conteo_desviaciones = (
                usuarios_desviacion[usuarios_desviacion.ne("")]
                .value_counts()
            )

            top5_series = conteo_desviaciones.head(5)

            datos["top_usuarios_desviaciones"] = [
                {
                    "usuario": str(usuario),
                    "nombre": nombres_por_usuario.get(str(usuario), ""),
                    "cantidad": int(cantidad),
                }
                for usuario, cantidad in top5_series.items()
            ]

            # Distribución completa por usuario, equivalente a la tabla
            # principal de la hoja "Distribución de desviaciones".
            tipos_oficiales = [
                "ORTOGRAFIA",
                "ESPECIFICACION TECNICA",
                "CLASIFICACION",
                "DUPLICADO",
            ]
            distribucion = []
            df_desv = df.loc[mascara_desviacion].copy()
            df_desv["__usuario"] = usuarios_todos[mascara_desviacion].values
            df_desv["__obs"] = obs[mascara_desviacion].values
            total_oficial = int(len(df_desv))

            if total_oficial > 0:
                tabla_dist = pd.crosstab(df_desv["__usuario"], df_desv["__obs"])
                for usuario in conteo_desviaciones.index:
                    usuario = str(usuario)
                    if not usuario:
                        continue
                    cantidades = {
                        tipo: int(tabla_dist.loc[usuario, tipo])
                        if usuario in tabla_dist.index and tipo in tabla_dist.columns
                        else 0
                        for tipo in tipos_oficiales
                    }
                    total_usuario = sum(cantidades.values())
                    distribucion.append({
                        "usuario": usuario,
                        "nombre": nombres_por_usuario.get(usuario, ""),
                        "ortografia": cantidades["ORTOGRAFIA"],
                        "especificacion": cantidades["ESPECIFICACION TECNICA"],
                        "clasificacion": cantidades["CLASIFICACION"],
                        "duplicado": cantidades["DUPLICADO"],
                        "total": total_usuario,
                        "porcentaje": (total_usuario / total_oficial) * 100,
                    })

            datos["distribucion_usuarios"] = distribucion

            # Tabla equivalente a "Códigos por usuario" del Excel.
            codigos_top5 = []
            for posicion, (usuario, cantidad_error) in enumerate(
                top5_series.items(), start=1
            ):
                usuario = str(usuario)
                total_generados = int((usuarios_todos == usuario).sum())
                total_error = int(cantidad_error)
                total_sin_error = max(total_generados - total_error, 0)

                porcentaje_error = (
                    (total_error / total_generados) * 100
                    if total_generados else 0.0
                )
                porcentaje_sin_error = (
                    (total_sin_error / total_generados) * 100
                    if total_generados else 0.0
                )

                codigos_top5.append({
                    "posicion": posicion,
                    "usuario": usuario,
                    "nombre": nombres_por_usuario.get(usuario, ""),
                    "total_error": total_error,
                    "total_sin_error": total_sin_error,
                    "total_generados": total_generados,
                    "porcentaje_error": porcentaje_error,
                    "porcentaje_sin_error": porcentaje_sin_error,
                })

            datos["codigos_top5"] = codigos_top5

    if {"Usuario", "Nombre de Usuario"}.issubset(df.columns):
        usuarios = (
            df.loc[
                df["Usuario"].fillna("").astype(str).str.strip().ne("")
                & df["Nombre de Usuario"].fillna("").astype(str).str.strip().eq(""),
                "Usuario",
            ]
            .fillna("")
            .astype(str)
            .str.replace(r"\.0$", "", regex=True)
            .str.strip()
        )
        datos["usuarios_no_identificados"] = sorted(
            {u for u in usuarios if u},
            key=lambda x: (not x.isdigit(), int(x) if x.isdigit() else x),
        )

    return datos


def obtener_historial() -> list[dict]:
    REVISIONES_DIR.mkdir(parents=True, exist_ok=True)
    resultados = []

    for ruta in REVISIONES_DIR.glob("REVISION_INTEGRADA_*.xlsx"):
        if ruta.name.startswith("~$"):
            continue

        periodo = ruta.stem.replace("REVISION_INTEGRADA_", "").replace("_", " ")
        resumen = leer_resultado_excel(ruta)
        resultados.append({
            "periodo": periodo,
            "archivo": ruta.name,
            "fecha": ruta.stat().st_mtime,
            **resumen,
        })

    resultados.sort(key=lambda x: x["fecha"], reverse=True)
    return resultados


def obtener_dashboard() -> dict:
    historial = obtener_historial()
    ultimo = historial[0] if historial else None

    # El panel de Inicio utiliza exactamente el mismo consolidado que
    # "Desviaciones mensuales", incluyendo septiembre y meses posteriores.
    mensual = obtener_desviaciones_mensuales_2026()
    total_desviaciones_2026 = int(
        mensual.get("totales_resumen", {}).get("desviaciones", 0) or 0
    )

    return {
        "ultimo": ultimo,
        "total_historico": contar_tabla("articulos_historico"),
        "usuarios": contar_tabla("usuarios"),
        "clasificaciones": contar_tabla("catalogo_subgrupos"),
        "revisiones_historicas": contar_tabla("revisiones_historicas"),
        "total_desviaciones_2026": total_desviaciones_2026,
        "historial": historial[:5],
    }


def obtener_usuarios(busqueda: str = "") -> list[dict]:
    if not existe_tabla("usuarios"):
        return []

    con = conexion()
    try:
        if busqueda:
            patron = f"%{busqueda.strip()}%"
            filas = con.execute(
                """
                SELECT usuario, nombre_usuario
                FROM usuarios
                WHERE usuario LIKE ? OR nombre_usuario LIKE ?
                ORDER BY nombre_usuario
                LIMIT 250
                """,
                (patron, patron),
            ).fetchall()
        else:
            filas = con.execute(
                """
                SELECT usuario, nombre_usuario
                FROM usuarios
                ORDER BY nombre_usuario
                LIMIT 250
                """
            ).fetchall()
    finally:
        con.close()

    return [{"usuario": u, "nombre": n} for u, n in filas]



def _normalizar_usuario(valor) -> str:
    if valor is None:
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0") and texto[:-2].isdigit():
        texto = texto[:-2]
    return texto


def _mapa_nombres_usuarios() -> dict:
    if not existe_tabla("usuarios"):
        return {}

    con = conexion()
    try:
        filas = con.execute(
            "SELECT usuario, nombre_usuario FROM usuarios"
        ).fetchall()
    finally:
        con.close()

    return {
        _normalizar_usuario(usuario): (nombre or "").strip()
        for usuario, nombre in filas
        if _normalizar_usuario(usuario)
    }


def _periodo_desde_nombre_revision(nombre: str):
    texto = Path(nombre).stem.upper().replace("REVISION_INTEGRADA_", "")
    mes = next((m for m in MESES if m in texto), "")
    coincidencia_anio = re.search(r"(20\d{2})", texto)
    anio = int(coincidencia_anio.group(1)) if coincidencia_anio else 2026
    return mes, anio


def obtener_top5_acumulado_2026() -> list[dict]:
    """
    Acumula el Top 5 mensual de usuarios con desviaciones durante 2026.

    Enero-agosto se obtienen de revisiones_historicas.
    Si existe un REVISION_INTEGRADA_<MES>[_2026].xlsx para un mes,
    ese archivo tiene prioridad para dicho mes (septiembre en adelante,
    o cualquier mes reprocesado desde la web).
    """
    nombres_oficiales = _mapa_nombres_usuarios()
    por_mes = {}

    # 1) Base histórica manual.
    if existe_tabla("revisiones_historicas"):
        con = conexion()
        try:
            filas = con.execute(
                """
                SELECT
                    UPPER(TRIM(COALESCE(mes, ''))) AS mes,
                    usuario,
                    nombre_usuario,
                    COUNT(*) AS desviaciones
                FROM revisiones_historicas
                WHERE anio = 2026
                  AND UPPER(TRIM(COALESCE(observacion, ''))) IN (
                      'CLASIFICACION',
                      'DUPLICADO',
                      'ESPECIFICACION TECNICA',
                      'ORTOGRAFIA'
                  )
                GROUP BY
                    UPPER(TRIM(COALESCE(mes, ''))),
                    usuario,
                    nombre_usuario
                """
            ).fetchall()
        finally:
            con.close()

        agrupado = {}
        for mes, usuario, nombre, cantidad in filas:
            usuario = _normalizar_usuario(usuario)
            if not mes or not usuario:
                continue
            agrupado.setdefault(mes, []).append({
                "usuario": usuario,
                "nombre": nombres_oficiales.get(usuario, (nombre or "").strip()),
                "desviaciones": int(cantidad or 0),
            })

        for mes, registros in agrupado.items():
            registros.sort(
                key=lambda x: (-x["desviaciones"], x["usuario"])
            )
            por_mes[mes] = registros[:5]

    # 2) Revisiones generadas desde la aplicación.
    # El archivo más reciente de cada mes sustituye el histórico de ese mes.
    revisiones = obtener_historial()
    meses_actualizados = set()

    for item in revisiones:
        mes, anio = _periodo_desde_nombre_revision(item["archivo"])
        if not mes or anio != 2026 or mes in meses_actualizados:
            continue

        ruta = REVISIONES_DIR / item["archivo"]
        datos = leer_resultado_excel(ruta)
        registros = []

        for fila in datos.get("top_usuarios_desviaciones", []):
            usuario = _normalizar_usuario(fila.get("usuario"))
            if not usuario:
                continue
            registros.append({
                "usuario": usuario,
                "nombre": (
                    fila.get("nombre", "")
                    or nombres_oficiales.get(usuario, "")
                ),
                "desviaciones": int(fila.get("cantidad", 0) or 0),
            })

        por_mes[mes] = registros[:5]
        meses_actualizados.add(mes)

    acumulado = []
    for mes in MESES:
        registros = por_mes.get(mes, [])
        for posicion, registro in enumerate(registros, start=1):
            acumulado.append({
                "mes": mes.title(),
                "posicion": posicion,
                "usuario": registro["usuario"],
                "nombre": registro["nombre"],
                "desviaciones": registro["desviaciones"],
            })

    return acumulado



def obtener_desviaciones_mensuales_2026() -> dict:
    """
    Consolida las codificaciones y desviaciones mensuales de 2026.

    Fuente:
    - revisiones_historicas para meses históricos.
    - REVISION_INTEGRADA_<MES>[_2026].xlsx para meses procesados
      desde la aplicación; el archivo más reciente sustituye al histórico
      de ese mismo mes.

    Desviaciones oficiales:
    CLASIFICACION, DUPLICADO, ESPECIFICACION TECNICA y ORTOGRAFIA.
    """
    por_mes = {}

    # 1) Base histórica manual
    if existe_tabla("revisiones_historicas"):
        con = conexion()
        try:
            filas = con.execute(
                """
                SELECT
                    UPPER(TRIM(COALESCE(mes, ''))) AS mes,
                    COUNT(*) AS codificaciones,
                    SUM(CASE WHEN UPPER(TRIM(COALESCE(observacion, ''))) =
                        'CLASIFICACION' THEN 1 ELSE 0 END) AS clasificacion,
                    SUM(CASE WHEN UPPER(TRIM(COALESCE(observacion, ''))) =
                        'DUPLICADO' THEN 1 ELSE 0 END) AS duplicado,
                    SUM(CASE WHEN UPPER(TRIM(COALESCE(observacion, ''))) =
                        'ESPECIFICACION TECNICA' THEN 1 ELSE 0 END) AS especificacion,
                    SUM(CASE WHEN UPPER(TRIM(COALESCE(observacion, ''))) =
                        'ORTOGRAFIA' THEN 1 ELSE 0 END) AS ortografia
                FROM revisiones_historicas
                WHERE anio = 2026
                GROUP BY UPPER(TRIM(COALESCE(mes, '')))
                """
            ).fetchall()
        finally:
            con.close()

        for (
            mes,
            codificaciones,
            clasificacion,
            duplicado,
            especificacion,
            ortografia,
        ) in filas:
            if mes not in MESES:
                continue

            registro = {
                "mes": mes,
                "codificaciones": int(codificaciones or 0),
                "clasificacion": int(clasificacion or 0),
                "duplicado": int(duplicado or 0),
                "especificacion": int(especificacion or 0),
                "ortografia": int(ortografia or 0),
            }
            registro["desviaciones"] = (
                registro["clasificacion"]
                + registro["duplicado"]
                + registro["especificacion"]
                + registro["ortografia"]
            )
            registro["porcentaje"] = (
                (registro["desviaciones"] / registro["codificaciones"]) * 100
                if registro["codificaciones"] else 0.0
            )
            por_mes[mes] = registro

    # Corrección validada para AGOSTO 2026 en el desglose mensual.
    # Orden lógico en la tabla:
    # Ortografía 241, Especificación Técnica 46, Duplicado 2,
    # Clasificación 439. Total = 728.
    if "AGOSTO" in por_mes:
        por_mes["AGOSTO"]["ortografia"] = 241
        por_mes["AGOSTO"]["especificacion"] = 46
        por_mes["AGOSTO"]["duplicado"] = 2
        por_mes["AGOSTO"]["clasificacion"] = 439
        por_mes["AGOSTO"]["desviaciones"] = 728
        por_mes["AGOSTO"]["porcentaje"] = (
            (728 / por_mes["AGOSTO"]["codificaciones"]) * 100
            if por_mes["AGOSTO"]["codificaciones"] else 0.0
        )

    # 2) Revisiones procesadas desde la web.
    # obtener_historial ya viene ordenado de más reciente a más antiguo,
    # por lo que se toma una sola revisión por mes.
    meses_actualizados = set()

    for item in obtener_historial():
        mes, anio = _periodo_desde_nombre_revision(item["archivo"])
        if not mes or anio != 2026 or mes in meses_actualizados:
            continue

        datos = leer_resultado_excel(REVISIONES_DIR / item["archivo"])

        registro = {
            "mes": mes,
            "codificaciones": int(datos.get("total", 0) or 0),
            "clasificacion": int(datos.get("clasificacion", 0) or 0),
            "duplicado": int(datos.get("duplicado", 0) or 0),
            "especificacion": int(datos.get("especificacion", 0) or 0),
            "ortografia": int(datos.get("ortografia", 0) or 0),
        }
        registro["desviaciones"] = (
            registro["clasificacion"]
            + registro["duplicado"]
            + registro["especificacion"]
            + registro["ortografia"]
        )
        registro["porcentaje"] = (
            (registro["desviaciones"] / registro["codificaciones"]) * 100
            if registro["codificaciones"] else 0.0
        )

        por_mes[mes] = registro
        meses_actualizados.add(mes)

    # ========================================================
    # VALORES MENSUALES OFICIALES VALIDOS ENERO-AGOSTO 2026
    # ========================================================
    # Se conservan los meses posteriores (SEPTIEMBRE en adelante)
    # obtenidos automáticamente desde las revisiones de la aplicación.
    oficiales_enero_agosto = {
        "ENERO": {
            "codificaciones": 876,
            "ortografia": 185,
            "especificacion": 20,
            "duplicado": 4,
            "clasificacion": 1,
            "desviaciones": 210,
        },
        "FEBRERO": {
            "codificaciones": 1885,
            "ortografia": 256,
            "especificacion": 30,
            "duplicado": 2,
            "clasificacion": 1,
            "desviaciones": 289,
        },
        "MARZO": {
            "codificaciones": 1480,
            "ortografia": 123,
            "especificacion": 168,
            "duplicado": 21,
            "clasificacion": 2,
            "desviaciones": 314,
        },
        "ABRIL": {
            "codificaciones": 1527,
            "ortografia": 194,
            "especificacion": 304,
            "duplicado": 46,
            "clasificacion": 11,
            "desviaciones": 555,
        },
        "MAYO": {
            "codificaciones": 1175,
            "ortografia": 110,
            "especificacion": 154,
            "duplicado": 20,
            "clasificacion": 8,
            "desviaciones": 292,
        },
        "JUNIO": {
            "codificaciones": 928,
            "ortografia": 113,
            "especificacion": 133,
            "duplicado": 10,
            "clasificacion": 11,
            "desviaciones": 267,
        },
        "JULIO": {
            "codificaciones": 2108,
            "ortografia": 309,
            "especificacion": 231,
            "duplicado": 32,
            "clasificacion": 27,
            "desviaciones": 599,
        },
        "AGOSTO": {
            "codificaciones": 1693,
            "ortografia": 241,
            "especificacion": 46,
            "duplicado": 2,
            "clasificacion": 439,
            "desviaciones": 728,
        },
    }

    for mes_oficial, valores in oficiales_enero_agosto.items():
        registro = dict(valores)
        registro["mes"] = mes_oficial
        registro["porcentaje"] = (
            (registro["desviaciones"] / registro["codificaciones"]) * 100
            if registro["codificaciones"] else 0.0
        )
        por_mes[mes_oficial] = registro

    meses = [por_mes[m] for m in MESES if m in por_mes]

    # --------------------------------------------------------
    # RESUMEN MENSUAL - PRIMERA TABLA
    # --------------------------------------------------------
    # La primera tabla utiliza los valores oficiales de la hoja
    # "Tablas Desviaciones-Mensual" para enero-agosto.
    for registro in meses:
        registro["desviaciones_resumen"] = registro.get(
            "desviaciones_resumen_oficial",
            registro["desviaciones"],
        )
        registro["porcentaje_resumen"] = (
            (registro["desviaciones_resumen"] / registro["codificaciones"]) * 100
            if registro["codificaciones"] else 0.0
        )

    totales_resumen = {
        "codificaciones": sum(x["codificaciones"] for x in meses),
        "desviaciones": sum(x["desviaciones_resumen"] for x in meses),
    }
    totales_resumen["porcentaje"] = (
        (totales_resumen["desviaciones"] / totales_resumen["codificaciones"]) * 100
        if totales_resumen["codificaciones"] else 0.0
    )

    totales = {
        "codificaciones": sum(x["codificaciones"] for x in meses),
        "clasificacion": sum(x["clasificacion"] for x in meses),
        "duplicado": sum(x["duplicado"] for x in meses),
        "especificacion": sum(x["especificacion"] for x in meses),
        "ortografia": sum(x["ortografia"] for x in meses),
    }
    totales["desviaciones"] = (
        totales["clasificacion"]
        + totales["duplicado"]
        + totales["especificacion"]
        + totales["ortografia"]
    )
    totales["porcentaje"] = (
        (totales["desviaciones"] / totales["codificaciones"]) * 100
        if totales["codificaciones"] else 0.0
    )

    tipos = [
        {"clave": "ortografia", "nombre": "Ortografía", "total": totales["ortografia"]},
        {
            "clave": "especificacion",
            "nombre": "Especificación Técnica",
            "total": totales["especificacion"],
        },
        {"clave": "duplicado", "nombre": "Duplicado", "total": totales["duplicado"]},
        {
            "clave": "clasificacion",
            "nombre": "Clasificación",
            "total": totales["clasificacion"],
        },
    ]

    for tipo in tipos:
        tipo["porcentaje"] = (
            (tipo["total"] / totales["desviaciones"]) * 100
            if totales["desviaciones"] else 0.0
        )

    ultimo = meses[-1] if meses else None

    grafica = {
        "meses": [x["mes"].title() for x in meses],
        "categorias": [
            "Clasificación",
            "Duplicado",
            "Especificación Técnica",
            "Ortografía",
            "Total general",
        ],
        "series": [],
    }

    for registro in meses:
        grafica["series"].append({
            "mes": registro["mes"].title(),
            "valores": [
                registro["clasificacion"],
                registro["duplicado"],
                registro["especificacion"],
                registro["ortografia"],
                registro["desviaciones"],
            ],
        })

    return {
        "meses": meses,
        "tipos": tipos,
        "totales": totales,
        "totales_resumen": totales_resumen,
        "ultimo": ultimo,
        "grafica": grafica,
    }


def obtener_catalogo(busqueda: str = "") -> list[dict]:
    """
    Muestra el catálogo con la misma estructura de la hoja GRUPOS,
    columnas A:E:
    ESPECIALIDAD, GRUPO, NOMBRE GRUPO, SUBGRUPO, NOMBRE SUBGRUPO.

    No se aplica límite de filas: se muestran todos los registros.
    """
    if not existe_tabla("catalogo_subgrupos"):
        return []

    con = conexion()
    try:
        if busqueda:
            patron = f"%{busqueda.strip()}%"
            filas = con.execute(
                """
                SELECT especialidad, grupo, nombre_grupo, subgrupo, nombre_subgrupo
                FROM catalogo_subgrupos
                WHERE especialidad LIKE ?
                   OR grupo LIKE ?
                   OR nombre_grupo LIKE ?
                   OR subgrupo LIKE ?
                   OR nombre_subgrupo LIKE ?
                ORDER BY grupo, subgrupo
                """,
                (patron, patron, patron, patron, patron),
            ).fetchall()
        else:
            filas = con.execute(
                """
                SELECT especialidad, grupo, nombre_grupo, subgrupo, nombre_subgrupo
                FROM catalogo_subgrupos
                ORDER BY grupo, subgrupo
                """
            ).fetchall()
    finally:
        con.close()

    return [
        {
            "especialidad": especialidad or "",
            "grupo": grupo or "",
            "nombre_grupo": nombre_grupo or "",
            "subgrupo": subgrupo or "",
            "nombre_subgrupo": nombre_subgrupo or "",
        }
        for especialidad, grupo, nombre_grupo, subgrupo, nombre_subgrupo in filas
    ]


# ============================================================
# EXPORTACION EXCEL = MISMA INFORMACION DE LA WEB
# ============================================================

_REPORTE_VERDE_OSCURO = "548235"
_REPORTE_VERDE_MEDIO = "70AD47"
_REPORTE_VERDE_CLARO = "E2F0D9"
_REPORTE_AZUL = "315FCE"
_REPORTE_VIOLETA = "7557C8"
_REPORTE_NARANJA = "E18A2A"
_REPORTE_GRIS = "6C7A90"
_REPORTE_BORDE = "D9E1E8"


def _estilo_titulo_reporte(ws, celda, texto):
    ws[celda] = texto
    ws[celda].font = Font(size=16, bold=True, color="1F2937")
    ws[celda].alignment = Alignment(vertical="center")


def _estilo_encabezado_reporte(celdas, fill=_REPORTE_VERDE_OSCURO):
    relleno = PatternFill("solid", fgColor=fill)
    fuente = Font(color="FFFFFF", bold=True)
    borde = Border(bottom=Side(style="thin", color=_REPORTE_BORDE))
    for celda in celdas:
        celda.fill = relleno
        celda.font = fuente
        celda.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        celda.border = borde


def _estilo_tabla_reporte(ws, fila_inicio, fila_fin, col_inicio, col_fin):
    borde = Border(bottom=Side(style="hair", color=_REPORTE_BORDE))
    for fila in ws.iter_rows(
        min_row=fila_inicio,
        max_row=fila_fin,
        min_col=col_inicio,
        max_col=col_fin,
    ):
        for celda in fila:
            celda.border = borde
            celda.alignment = Alignment(vertical="center", wrap_text=True)


def _ancho_columnas(ws, anchos):
    for columna, ancho in anchos.items():
        ws.column_dimensions[columna].width = ancho


def _crear_hoja_resumen_revision(wb, datos, periodo):
    ws = wb.create_sheet("Resumen de revisión")
    _estilo_titulo_reporte(ws, "A1", f"Última revisión - {periodo.title()}")

    total = int(datos.get("total", 0) or 0)
    desviaciones = int(datos.get("con_observacion", 0) or 0)
    filas = [
        ["Indicador", "Cantidad", "Porcentaje"],
        ["Total codificaciones", total, 1 if total else 0],
        ["OK", int(datos.get("ok", 0) or 0), (int(datos.get("ok", 0) or 0) / total) if total else 0],
        ["Revisar", int(datos.get("revisar", 0) or 0), (int(datos.get("revisar", 0) or 0) / total) if total else 0],
        ["Desviaciones", desviaciones, (desviaciones / total) if total else 0],
    ]
    for r, fila in enumerate(filas, start=3):
        for c, valor in enumerate(fila, start=1):
            ws.cell(r, c, valor)
    _estilo_encabezado_reporte(ws[3])
    for r in range(4, 8):
        ws.cell(r, 3).number_format = "0.0%"
    _estilo_tabla_reporte(ws, 4, 7, 1, 3)

    ws["A10"] = "Detalle por tipo de desviación"
    ws["A10"].font = Font(size=12, bold=True, color="1F2937")
    detalle = [
        ["Tipo de desviación", "Cantidad", "Porcentaje sobre desviaciones"],
        ["Ortografía", int(datos.get("ortografia", 0) or 0), 0],
        ["Especificación técnica", int(datos.get("especificacion", 0) or 0), 0],
        ["Duplicados", int(datos.get("duplicado", 0) or 0), 0],
        ["Clasificación", int(datos.get("clasificacion", 0) or 0), 0],
    ]
    for fila in detalle[1:]:
        fila[2] = (fila[1] / desviaciones) if desviaciones else 0
    for r, fila in enumerate(detalle, start=12):
        for c, valor in enumerate(fila, start=1):
            ws.cell(r, c, valor)
    _estilo_encabezado_reporte(ws[12])
    for r in range(13, 17):
        ws.cell(r, 3).number_format = "0.0%"
    _estilo_tabla_reporte(ws, 13, 16, 1, 3)
    _ancho_columnas(ws, {"A": 30, "B": 16, "C": 28})
    ws.freeze_panes = "A3"


def _crear_hoja_distribucion(wb, datos, periodo):
    ws = wb.create_sheet("Distribución de desviaciones")
    _estilo_titulo_reporte(ws, "A1", f"Distribución de desviaciones - {periodo.title()}")

    # TABLA 1: resumen por tipo de desviación.
    total = int(datos.get("con_observacion", 0) or 0)
    filas = [
        ["Tipo de desviación", "Cantidad", "Porcentaje"],
        ["Ortografía", int(datos.get("ortografia", 0) or 0), 0],
        ["Especificación técnica", int(datos.get("especificacion", 0) or 0), 0],
        ["Duplicados", int(datos.get("duplicado", 0) or 0), 0],
        ["Clasificación", int(datos.get("clasificacion", 0) or 0), 0],
        ["Total", total, 1 if total else 0],
    ]
    for fila in filas[1:5]:
        fila[2] = (fila[1] / total) if total else 0

    for r, fila in enumerate(filas, start=3):
        for c, valor in enumerate(fila, start=1):
            ws.cell(r, c, valor)

    _estilo_encabezado_reporte(ws[3])
    for r in range(4, 9):
        ws.cell(r, 3).number_format = "0.0%"
    _estilo_tabla_reporte(ws, 4, 8, 1, 3)
    for c in range(1, 4):
        ws.cell(8, c).font = Font(bold=True)

    # TABLA 2: distribución de todos los usuarios con desviaciones del mes.
    # Es la misma estructura que se muestra en la subpágina
    # Usuarios > Distribución por usuario.
    distribucion = datos.get("distribucion_usuarios", []) or []
    fila_titulo = 11
    ws.cell(fila_titulo, 1, "Distribución de desviaciones por usuario")
    ws.cell(fila_titulo, 1).font = Font(bold=True, size=12)

    fila_enc = 13
    encabezados = [
        "#",
        "Usuario",
        "Nombre de usuario",
        "Ortografía",
        "Especificación técnica",
        "Clasificación",
        "Duplicado",
        "Total general",
        "Porcentaje",
    ]
    for c, valor in enumerate(encabezados, start=1):
        ws.cell(fila_enc, c, valor)
    _estilo_encabezado_reporte(ws[fila_enc])

    fila = fila_enc + 1
    for numero, item in enumerate(distribucion, start=1):
        valores = [
            numero,
            str(item.get("usuario", "") or ""),
            str(item.get("nombre", "") or "No identificado"),
            int(item.get("ortografia", 0) or 0),
            int(item.get("especificacion", 0) or 0),
            int(item.get("clasificacion", 0) or 0),
            int(item.get("duplicado", 0) or 0),
            int(item.get("total", 0) or 0),
            float(item.get("porcentaje", 0) or 0) / 100,
        ]
        for c, valor in enumerate(valores, start=1):
            ws.cell(fila, c, valor)
        ws.cell(fila, 9).number_format = "0.00%"
        fila += 1

    fila_total = fila
    tot_ort = sum(int(x.get("ortografia", 0) or 0) for x in distribucion)
    tot_esp = sum(int(x.get("especificacion", 0) or 0) for x in distribucion)
    tot_cla = sum(int(x.get("clasificacion", 0) or 0) for x in distribucion)
    tot_dup = sum(int(x.get("duplicado", 0) or 0) for x in distribucion)
    tot_gen = sum(int(x.get("total", 0) or 0) for x in distribucion)

    totales = [
        "",
        "",
        "Total general",
        tot_ort,
        tot_esp,
        tot_cla,
        tot_dup,
        tot_gen,
        1 if tot_gen else 0,
    ]
    for c, valor in enumerate(totales, start=1):
        ws.cell(fila_total, c, valor)
        ws.cell(fila_total, c).font = Font(bold=True)
    ws.cell(fila_total, 9).number_format = "0%"

    if fila_total >= fila_enc + 1:
        _estilo_tabla_reporte(ws, fila_enc + 1, fila_total, 1, 9)

    _ancho_columnas(
        ws,
        {
            "A": 8,
            "B": 16,
            "C": 34,
            "D": 15,
            "E": 24,
            "F": 16,
            "G": 14,
            "H": 16,
            "I": 14,
        },
    )


def _crear_hoja_desviaciones_mensuales(wb, mensual):
    ws = wb.create_sheet("Desviaciones mensuales")
    _estilo_titulo_reporte(ws, "A1", "Desviaciones mensuales 2026")
    meses = mensual.get("meses", []) or []
    totales_resumen = mensual.get("totales_resumen", {}) or {}

    # Tabla 1: exactamente los datos visibles en Codificaciones y desviaciones.
    encabezado = ["Mes"] + [m["mes"].title() for m in meses] + ["Total Gral"]
    ws.append([])
    for c, valor in enumerate(encabezado, start=1):
        ws.cell(3, c, valor)
    _estilo_encabezado_reporte(ws[3])

    filas = [
        ["Codificaciones"] + [int(m.get("codificaciones", 0) or 0) for m in meses] + [int(totales_resumen.get("codificaciones", 0) or 0)],
        ["Desviaciones"] + [int(m.get("desviaciones_resumen", 0) or 0) for m in meses] + [int(totales_resumen.get("desviaciones", 0) or 0)],
        ["Porcentaje"] + [float(m.get("porcentaje_resumen", 0) or 0) / 100 for m in meses] + [float(totales_resumen.get("porcentaje", 0) or 0) / 100],
    ]
    for r, fila in enumerate(filas, start=4):
        for c, valor in enumerate(fila, start=1):
            ws.cell(r, c, valor)
    for c in range(2, len(encabezado) + 1):
        ws.cell(6, c).number_format = "0.0%"
    _estilo_tabla_reporte(ws, 4, 6, 1, len(encabezado))

    # Tabla 2: distribución por tipo.
    fila_tabla2 = 9
    encabezado2 = ["Tipo de desviación"] + [m["mes"].title() for m in meses] + ["Total", "Porcentaje"]
    for c, valor in enumerate(encabezado2, start=1):
        ws.cell(fila_tabla2, c, valor)
    _estilo_encabezado_reporte(ws[fila_tabla2])

    tipos = mensual.get("tipos", []) or []
    r = fila_tabla2 + 1
    for tipo in tipos:
        fila = [tipo.get("nombre", "")]
        for mes in meses:
            fila.append(int(mes.get(tipo.get("clave", ""), 0) or 0))
        fila += [int(tipo.get("total", 0) or 0), float(tipo.get("porcentaje", 0) or 0) / 100]
        for c, valor in enumerate(fila, start=1):
            ws.cell(r, c, valor)
        ws.cell(r, len(encabezado2)).number_format = "0.0%"
        r += 1

    fila_total = r
    fila = ["Total Gral Desviaciones"] + [int(m.get("desviaciones_resumen", 0) or 0) for m in meses] + [int(totales_resumen.get("desviaciones", 0) or 0), 1]
    for c, valor in enumerate(fila, start=1):
        ws.cell(fila_total, c, valor)
    ws.cell(fila_total, len(encabezado2)).number_format = "0%"
    for c in range(1, len(encabezado2) + 1):
        ws.cell(fila_total, c).font = Font(bold=True)
    _estilo_tabla_reporte(ws, fila_tabla2 + 1, fila_total, 1, len(encabezado2))

    # Gráfica equivalente a la gráfica web: 4 tipos, series por mes,
    # sin Total general. Usa directamente la segunda tabla como fuente.
    if meses:
        chart = BarChart()
        chart.type = "col"
        chart.style = 10
        chart.grouping = "clustered"
        chart.overlap = 0
        chart.title = "Tipo de desviación"
        chart.y_axis.title = "Cantidad"
        chart.x_axis.title = "Tipo de desviación"
        chart.height = 10
        chart.width = 19
        data = Reference(
            ws,
            min_col=2,
            max_col=1 + len(meses),
            min_row=fila_tabla2,
            max_row=fila_tabla2 + 4,
        )
        cats = Reference(
            ws,
            min_col=1,
            min_row=fila_tabla2 + 1,
            max_row=fila_tabla2 + 4,
        )
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        verdes = ["375623", "548235", "70AD47", "A9D18E", "226B3A", "3F8C54", "65A765", "8FC17A", "2F6B3C", "4F8A4C", "73A95A", "A2C98B"]
        for serie, mes_info, color in zip(chart.series, meses, verdes):
            try:
                serie.title = mes_info["mes"].title()
                serie.graphicalProperties.solidFill = color
                serie.graphicalProperties.line.solidFill = color
            except Exception:
                pass
        ws.add_chart(chart, f"A{fila_total + 3}")

    for c in range(1, max(len(encabezado), len(encabezado2)) + 1):
        ws.column_dimensions[get_column_letter(c)].width = 16
    ws.column_dimensions["A"].width = 28
    ws.freeze_panes = "B3"


def _crear_hoja_usuarios_2026(wb, acumulado):
    ws = wb.create_sheet("Usuarios con desviaciones 2026")
    _estilo_titulo_reporte(ws, "A1", "Usuarios con desviaciones 2026")
    encabezado = ["Mes", "Usuario", "Nombre usuario", "Desviaciones"]
    for c, valor in enumerate(encabezado, start=1):
        ws.cell(3, c, valor)
    _estilo_encabezado_reporte(ws[3])

    r = 4
    mes_actual = None
    total_mes = 0
    for item in acumulado:
        mes = str(item.get("mes", ""))
        if mes_actual and mes != mes_actual:
            ws.cell(r, 1, f"TOTAL {mes_actual.upper()}")
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
            ws.cell(r, 4, total_mes)
            for c in range(1, 5):
                ws.cell(r, c).font = Font(bold=True)
                ws.cell(r, c).fill = PatternFill("solid", fgColor=_REPORTE_VERDE_CLARO)
            r += 1
            total_mes = 0
        mes_actual = mes
        desviaciones = int(item.get("desviaciones", 0) or 0)
        total_mes += desviaciones
        ws.cell(r, 1, mes)
        ws.cell(r, 2, str(item.get("usuario", "")))
        ws.cell(r, 3, item.get("nombre", "") or "No identificado")
        ws.cell(r, 4, desviaciones)
        r += 1
    if mes_actual:
        ws.cell(r, 1, f"TOTAL {mes_actual.upper()}")
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
        ws.cell(r, 4, total_mes)
        for c in range(1, 5):
            ws.cell(r, c).font = Font(bold=True)
            ws.cell(r, c).fill = PatternFill("solid", fgColor=_REPORTE_VERDE_CLARO)
    _estilo_tabla_reporte(ws, 4, max(4, r), 1, 4)
    _ancho_columnas(ws, {"A": 18, "B": 16, "C": 38, "D": 16})
    ws.freeze_panes = "A4"


def _crear_hoja_desviaciones_usuario(wb, datos, periodo):
    ws = wb.create_sheet("Top desviaciones")
    _estilo_titulo_reporte(ws, "A1", f"Desviaciones por usuario - {periodo.title()}")

    total_desviaciones = int(datos.get("con_observacion", 0) or 0)
    top5 = datos.get("top_usuarios_desviaciones", []) or []
    total_top5 = sum(int(x.get("cantidad", 0) or 0) for x in top5)
    porcentaje_top5 = (total_top5 / total_desviaciones) if total_desviaciones else 0

    ws["A3"] = "Top 5 usuarios con más desviaciones"
    ws["A3"].font = Font(size=12, bold=True)
    headers1 = ["Usuario", "Cant. desviaciones"]
    for c, h in enumerate(headers1, 1):
        ws.cell(5, c, h)
    _estilo_encabezado_reporte(ws[5])
    r = 6
    for item in top5:
        ws.cell(r, 1, str(item.get("usuario", "")))
        ws.cell(r, 2, int(item.get("cantidad", 0) or 0))
        r += 1
    ws.cell(r, 1, "Total Top 5")
    ws.cell(r, 2, total_top5)
    ws.cell(r + 1, 1, "Porcentaje")
    ws.cell(r + 1, 2, porcentaje_top5)
    ws.cell(r + 1, 2).number_format = "0.0%"
    ws.cell(r, 1).font = ws.cell(r, 2).font = Font(bold=True)
    _estilo_tabla_reporte(ws, 6, r + 1, 1, 2)

    col2 = 4
    ws.cell(3, col2, "Usuarios que codificaron")
    ws.cell(3, col2).font = Font(size=12, bold=True)
    ws.cell(5, col2, "Usuarios")
    ws.cell(5, col2 + 1, "Total")
    _estilo_encabezado_reporte(ws[5][col2 - 1:col2 + 1])
    usuarios_general = int(datos.get("usuarios_general", 0) or 0)
    usuarios_desv = int(datos.get("usuarios_con_desviaciones", 0) or 0)
    pct_usuarios = float(datos.get("porcentaje_usuarios_desviaciones", 0.0) or 0) / 100
    valores = [
        ["General", usuarios_general],
        ["Con desviaciones", usuarios_desv],
        ["% con desviaciones", pct_usuarios],
    ]
    for rr, fila in enumerate(valores, start=6):
        ws.cell(rr, col2, fila[0])
        ws.cell(rr, col2 + 1, fila[1])
    ws.cell(8, col2 + 1).number_format = "0.0%"
    _estilo_tabla_reporte(ws, 6, 8, col2, col2 + 1)

    fila3 = max(r + 4, 12)
    ws.cell(fila3, 1, "Códigos por usuario - Top 5 del mes")
    ws.cell(fila3, 1).font = Font(size=12, bold=True)
    headers3 = [
        "#", "Usuario", "Nombre de usuario", "Total c/error", "Total s/error",
        "Total generados", "Porcentaje c/error", "Porcentaje s/error",
    ]
    for c, h in enumerate(headers3, 1):
        ws.cell(fila3 + 2, c, h)
    _estilo_encabezado_reporte(ws[fila3 + 2])
    rr = fila3 + 3
    for item in datos.get("codigos_top5", []) or []:
        fila = [
            int(item.get("posicion", 0) or 0),
            str(item.get("usuario", "")),
            item.get("nombre", "") or "No identificado",
            int(item.get("total_error", 0) or 0),
            int(item.get("total_sin_error", 0) or 0),
            int(item.get("total_generados", 0) or 0),
            float(item.get("porcentaje_error", 0.0) or 0) / 100,
            float(item.get("porcentaje_sin_error", 0.0) or 0) / 100,
        ]
        for c, valor in enumerate(fila, 1):
            ws.cell(rr, c, valor)
        ws.cell(rr, 7).number_format = "0.0%"
        ws.cell(rr, 8).number_format = "0.0%"
        rr += 1
    if rr > fila3 + 3:
        _estilo_tabla_reporte(ws, fila3 + 3, rr - 1, 1, 8)
    _ancho_columnas(ws, {
        "A": 18, "B": 18, "C": 38, "D": 18, "E": 18,
        "F": 18, "G": 20, "H": 20,
    })


def _ajustar_articulos_para_descarga(wb):
    """
    Normaliza la hoja Artículos al formato definitivo del reporte:
    - elimina Notas/Comentarios;
    - elimina PORCENTAJE DE CONFIABILIDAD;
    - deja DETALLE GENERAL y Clasificacion Sugerida dentro de la misma tabla
      y con el mismo formato visual que Subobservación.
    """
    if "Artículos" not in wb.sheetnames:
        return

    ws = wb["Artículos"]

    encabezados = {
        str(ws.cell(1, c).value or "").strip(): c
        for c in range(1, ws.max_column + 1)
    }

    # Eliminar de derecha a izquierda para no desplazar índices pendientes.
    borrar = []
    for nombre in ["Notas/Comentarios", "PORCENTAJE DE CONFIABILIDAD"]:
        if nombre in encabezados:
            borrar.append(encabezados[nombre])

    for col in sorted(borrar, reverse=True):
        ws.delete_cols(col, 1)

    # Recalcular posiciones después de eliminar.
    encabezados = {
        str(ws.cell(1, c).value or "").strip(): c
        for c in range(1, ws.max_column + 1)
    }

    col_sub = encabezados.get("Subobservación")
    col_det = encabezados.get("DETALLE GENERAL")
    col_cla = encabezados.get("Clasificacion Sugerida")

    if col_sub and col_det and col_cla:
        # Encabezados con exactamente el mismo estilo que Subobservación.
        ws.cell(1, col_det)._style = copy(ws.cell(1, col_sub)._style)
        ws.cell(1, col_det).font = copy(ws.cell(1, col_sub).font)
        ws.cell(1, col_det).fill = copy(ws.cell(1, col_sub).fill)
        ws.cell(1, col_det).border = copy(ws.cell(1, col_sub).border)
        ws.cell(1, col_det).alignment = copy(ws.cell(1, col_sub).alignment)

        ws.cell(1, col_cla)._style = copy(ws.cell(1, col_sub)._style)
        ws.cell(1, col_cla).font = copy(ws.cell(1, col_sub).font)
        ws.cell(1, col_cla).fill = copy(ws.cell(1, col_sub).fill)
        ws.cell(1, col_cla).border = copy(ws.cell(1, col_sub).border)
        ws.cell(1, col_cla).alignment = copy(ws.cell(1, col_sub).alignment)

        for r in range(2, ws.max_row + 1):
            origen = ws.cell(r, col_sub)
            for col_destino in [col_det, col_cla]:
                destino = ws.cell(r, col_destino)
                destino._style = copy(origen._style)
                destino.font = copy(origen.font)
                destino.fill = copy(origen.fill)
                destino.border = copy(origen.border)
                destino.number_format = origen.number_format
                destino.alignment = Alignment(
                    horizontal="center",
                    vertical="center",
                    wrap_text=True,
                )

        ws.column_dimensions[get_column_letter(col_det)].width = 70
        ws.column_dimensions[get_column_letter(col_cla)].width = 35

    ultima_col = ws.max_column
    ultima_fila = max(2, ws.max_row)
    ws.auto_filter.ref = (
        f"A1:{get_column_letter(ultima_col)}{ultima_fila}"
    )


def actualizar_reporte_excel_desde_web(ruta_revision: Path) -> Path:
    """
    Convierte las hojas de reporte del Excel descargable en un reflejo
    de las mismas estructuras que alimentan la interfaz web.

    Artículos se conserva intacta.
    """
    ruta_revision = Path(ruta_revision)
    datos_mes = leer_resultado_excel(ruta_revision)
    mes, anio = _periodo_desde_nombre_revision(ruta_revision.name)
    periodo = f"{mes} {anio}" if mes else ruta_revision.stem.replace("REVISION_INTEGRADA_", "").replace("_", " ")

    mensual = obtener_desviaciones_mensuales_2026()
    acumulado = obtener_top5_acumulado_2026()

    wb = load_workbook(ruta_revision)
    try:
        if "Artículos" not in wb.sheetnames:
            raise ValueError("El reporte no contiene la hoja Artículos.")

        _ajustar_articulos_para_descarga(wb)

        for nombre in list(wb.sheetnames):
            if nombre != "Artículos":
                del wb[nombre]

        _crear_hoja_resumen_revision(wb, datos_mes, periodo)
        _crear_hoja_distribucion(wb, datos_mes, periodo)
        _crear_hoja_desviaciones_mensuales(wb, mensual)
        _crear_hoja_usuarios_2026(wb, acumulado)
        _crear_hoja_desviaciones_usuario(wb, datos_mes, periodo)

        orden = [
            "Artículos",
            "Resumen de revisión",
            "Distribución de desviaciones",
            "Desviaciones mensuales",
            "Usuarios con desviaciones 2026",
            "Top desviaciones",
        ]
        wb._sheets = [wb[n] for n in orden if n in wb.sheetnames]
        wb.save(ruta_revision)
    finally:
        wb.close()

    return ruta_revision


def _texto_excel(valor) -> str:
    if valor is None:
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0") and texto[:-2].isdigit():
        texto = texto[:-2]
    return texto


def _normalizar_encabezado(valor) -> str:
    texto = str(valor or "").strip().upper()
    reemplazos = str.maketrans("ÁÉÍÓÚÜÑ", "AEIOUUN")
    texto = texto.translate(reemplazos)
    texto = re.sub(r"\s+", " ", texto)
    return texto


def asegurar_tablas_reportes_historicos():
    REPORTES_HISTORICOS_DIR.mkdir(parents=True, exist_ok=True)
    con = conexion()
    try:
        con.execute("""
            CREATE TABLE IF NOT EXISTS reportes_historicos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                mes TEXT NOT NULL,
                anio INTEGER NOT NULL,
                nombre_original TEXT NOT NULL,
                nombre_guardado TEXT NOT NULL,
                ruta_relativa TEXT NOT NULL,
                fecha_carga TEXT NOT NULL,
                total_articulos INTEGER NOT NULL DEFAULT 0,
                UNIQUE(mes, anio)
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS articulos_reportes_historicos (
                codigo TEXT PRIMARY KEY,
                grupo TEXT,
                nombre_grupo TEXT,
                subgrupo TEXT,
                nombre_subgrupo TEXT,
                descripcion TEXT,
                usuario TEXT,
                nombre_usuario TEXT,
                um TEXT,
                mes TEXT NOT NULL,
                anio INTEGER NOT NULL,
                reporte_id INTEGER NOT NULL,
                FOREIGN KEY(reporte_id) REFERENCES reportes_historicos(id)
            )
        """)
        con.execute("""
            CREATE INDEX IF NOT EXISTS idx_art_hist_usuario
            ON articulos_reportes_historicos(usuario)
        """)
        con.execute("""
            CREATE INDEX IF NOT EXISTS idx_art_hist_periodo
            ON articulos_reportes_historicos(anio, mes)
        """)
        con.commit()
    finally:
        con.close()


def _buscar_hoja_articulos(wb):
    for nombre in wb.sheetnames:
        if _normalizar_encabezado(nombre) in {"ARTICULOS", "ARTICULO"}:
            return wb[nombre]
    # Compatibilidad con archivos antiguos.
    for nombre in wb.sheetnames:
        if _normalizar_encabezado(nombre) in {"REVISION_FINAL", "ORIGINAL", "MES ACTUAL"}:
            return wb[nombre]
    return None


def _mapear_encabezados_historicos(ws):
    alias = {}
    for clave, nombres in COLUMNAS_HISTORICAS.items():
        for n in nombres:
            alias[_normalizar_encabezado(n)] = clave

    mejor = None
    for fila in range(1, min(ws.max_row, 12) + 1):
        encontrado = {}
        for col in range(1, ws.max_column + 1):
            normal = _normalizar_encabezado(ws.cell(fila, col).value)
            if normal in alias and alias[normal] not in encontrado:
                encontrado[alias[normal]] = col
        if "codigo" in encontrado and "descripcion" in encontrado:
            if mejor is None or len(encontrado) > len(mejor[1]):
                mejor = (fila, encontrado)
    return mejor


def leer_articulos_reporte_historico(ruta: Path) -> list[dict]:
    wb = load_workbook(ruta, read_only=True, data_only=True)
    try:
        ws = _buscar_hoja_articulos(wb)
        if ws is None:
            raise ValueError(
                "No encontré una hoja llamada Artículos ni una hoja histórica compatible."
            )

        hallazgo = _mapear_encabezados_historicos(ws)
        if not hallazgo:
            raise ValueError(
                "No encontré las columnas Código y Descripción en el reporte."
            )

        fila_encabezado, columnas = hallazgo
        faltantes = [
            nombre for nombre in ("codigo", "grupo", "subgrupo", "descripcion", "usuario")
            if nombre not in columnas
        ]
        if faltantes:
            raise ValueError(
                "Al reporte le faltan columnas necesarias: "
                + ", ".join(faltantes)
                + "."
            )

        mapa_usuarios = mapa_usuarios_actual()
        articulos = []
        vistos = set()

        # Lectura secuencial: evita múltiples accesos ws.cell() por fila.
        for valores in ws.iter_rows(
            min_row=fila_encabezado + 1,
            max_row=ws.max_row,
            values_only=True,
        ):
            def valor(campo):
                col = columnas.get(campo)
                if not col or col - 1 >= len(valores):
                    return ""
                return _texto_excel(valores[col - 1])

            codigo = valor("codigo")
            if not codigo:
                continue
            if codigo in vistos:
                raise ValueError(
                    f"El código {codigo} aparece más de una vez dentro del mismo reporte."
                )
            vistos.add(codigo)

            usuario = valor("usuario")
            nombre_usuario = valor("nombre_usuario")
            if not nombre_usuario and usuario:
                nombre_usuario = mapa_usuarios.get(usuario, "")

            articulos.append({
                "codigo": codigo,
                "grupo": valor("grupo"),
                "nombre_grupo": valor("nombre_grupo"),
                "subgrupo": valor("subgrupo"),
                "nombre_subgrupo": valor("nombre_subgrupo"),
                "descripcion": valor("descripcion"),
                "usuario": usuario,
                "nombre_usuario": nombre_usuario,
                "um": valor("um"),
            })

        if not articulos:
            raise ValueError("El reporte no contiene artículos para registrar.")
        return articulos
    finally:
        wb.close()


def registrar_reporte_historico(ruta_origen: Path, nombre_original: str, mes: str, anio: int,
                                copiar_archivo: bool = True, rechazar_duplicados: bool = True):
    asegurar_tablas_reportes_historicos()
    articulos = leer_articulos_reporte_historico(ruta_origen)
    codigos = [a["codigo"] for a in articulos]

    con = conexion()
    destino = None
    try:
        periodo_existente = con.execute(
            "SELECT id FROM reportes_historicos WHERE mes=? AND anio=?",
            (mes, anio),
        ).fetchone()
        if periodo_existente:
            raise ValueError(f"Ya existe un reporte histórico para {mes.title()} {anio}.")

        duplicados = []
        # SQLite tiene un límite práctico de variables; consultar en bloques.
        for i in range(0, len(codigos), 800):
            bloque = codigos[i:i + 800]
            marcas = ",".join("?" for _ in bloque)
            duplicados.extend(
                fila[0] for fila in con.execute(
                    f"SELECT codigo FROM articulos_reportes_historicos WHERE codigo IN ({marcas})",
                    bloque,
                ).fetchall()
            )

        if duplicados and rechazar_duplicados:
            muestra = ", ".join(duplicados[:8])
            extra = f" y {len(duplicados) - 8} más" if len(duplicados) > 8 else ""
            raise ValueError(
                "No se cargó el reporte porque contiene códigos que ya están registrados: "
                + muestra + extra + "."
            )

        carpeta = REPORTES_HISTORICOS_DIR / str(anio)
        carpeta.mkdir(parents=True, exist_ok=True)
        nombre_guardado = f"{mes}_{anio}.xlsx"
        destino = carpeta / nombre_guardado

        if destino.exists():
            raise ValueError(f"Ya existe el archivo histórico {nombre_guardado}.")

        if copiar_archivo:
            shutil.copy2(ruta_origen, destino)
        else:
            shutil.copy2(ruta_origen, destino)

        ruta_relativa = str(destino.relative_to(BASE_DIR))
        ahora = datetime.now().isoformat(timespec="seconds")

        cur = con.execute(
            """
            INSERT INTO reportes_historicos
            (mes, anio, nombre_original, nombre_guardado, ruta_relativa, fecha_carga, total_articulos)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (mes, anio, nombre_original, nombre_guardado, ruta_relativa, ahora, len(articulos)),
        )
        reporte_id = cur.lastrowid

        con.executemany(
            """
            INSERT INTO articulos_reportes_historicos
            (codigo, grupo, nombre_grupo, subgrupo, nombre_subgrupo, descripcion,
             usuario, nombre_usuario, um, mes, anio, reporte_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                (
                    a["codigo"], a["grupo"], a["nombre_grupo"], a["subgrupo"],
                    a["nombre_subgrupo"], a["descripcion"], a["usuario"],
                    a["nombre_usuario"], a["um"], mes, anio, reporte_id,
                )
                for a in articulos
            ],
        )
        con.commit()
        return len(articulos)
    except Exception:
        con.rollback()
        if destino and destino.exists():
            try:
                destino.unlink()
            except OSError:
                pass
        raise
    finally:
        con.close()


def obtener_reportes_historicos() -> list[dict]:
    asegurar_tablas_reportes_historicos()
    con = conexion()
    try:
        filas = con.execute("""
            SELECT id, mes, anio, nombre_original, nombre_guardado,
                   ruta_relativa, fecha_carga, total_articulos
            FROM reportes_historicos
        """).fetchall()
    finally:
        con.close()

    resultados = []
    for fila in filas:
        resultados.append({
            "id": fila[0], "mes": fila[1], "anio": fila[2],
            "nombre_original": fila[3], "nombre_guardado": fila[4],
            "ruta_relativa": fila[5], "fecha_carga": fila[6],
            "total_articulos": fila[7],
        })
    resultados.sort(
        key=lambda x: (x["anio"], MESES_ORDEN.get(x["mes"], 0)),
        reverse=True,
    )
    return resultados


def buscar_articulo_historico(codigo: str):
    asegurar_tablas_reportes_historicos()
    codigo = _texto_excel(codigo)
    if not codigo:
        return None

    con = conexion()
    try:
        fila = con.execute("""
            SELECT a.codigo, a.grupo, a.nombre_grupo, a.subgrupo,
                   a.nombre_subgrupo, a.descripcion, a.usuario,
                   a.nombre_usuario, a.um, a.mes, a.anio,
                   r.id, r.nombre_original
            FROM articulos_reportes_historicos a
            JOIN reportes_historicos r ON r.id = a.reporte_id
            WHERE a.codigo = ?
        """, (codigo,)).fetchone()
    finally:
        con.close()

    if not fila:
        return None

    nombre_actual = mapa_usuarios_actual().get(fila[6], "") or fila[7]
    return {
        "codigo": fila[0], "grupo": fila[1], "nombre_grupo": fila[2],
        "subgrupo": fila[3], "nombre_subgrupo": fila[4],
        "descripcion": fila[5], "usuario": fila[6],
        "nombre_usuario": nombre_actual, "um": fila[8],
        "mes": fila[9], "anio": fila[10], "reporte_id": fila[11],
        "nombre_reporte": fila[12],
    }



def contexto_base(seccion: str, titulo: str) -> dict:
    return {
        "seccion": seccion,
        "titulo": titulo,
        "db_ok": DB_PATH.exists(),
        "almacenamiento_revisiones": str(REVISIONES_DIR),
        "db_path": str(DB_PATH),
    }




ICONS = {'home': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10.5V20h13v-9.5"/><path d="M9.5 20v-5h5v5"/></svg>', 'upload': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 16V4"/><path d="m7.5 8.5 4.5-4.5 4.5 4.5"/><path d="M5 14v5h14v-5"/></svg>', 'history': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/></svg>', 'users': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="9" cy="8" r="3"/><path d="M3.5 19c.5-3 2.2-5 5.5-5s5 2 5.5 5"/><path d="M16 6.5a2.7 2.7 0 0 1 0 5.2"/><path d="M16.2 14.2c2.7.3 4 2 4.3 4.3"/></svg>', 'grid': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg>', 'settings': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.4 1A8 8 0 0 0 15 6l-.3-2.6h-4L10.4 6A8 8 0 0 0 8.8 7.1l-2.4-1-2 3.4 2 1.5a7 7 0 0 0 0 2l-2 1.5 2 3.4 2.4-1A8 8 0 0 0 10.4 18l.3 2.6h4L15 18a8 8 0 0 0 1.6-1.1l2.4 1 2-3.4-2-1.5a7 7 0 0 0 .1-1Z"/></svg>', 'menu': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 7h16M4 12h16M4 17h16"/></svg>', 'plus': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 5v14M5 12h14"/></svg>', 'database': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>', 'archive': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="4" y="7" width="16" height="13" rx="1"/><path d="M3 4h18v4H3zM9 12h6"/></svg>', 'download': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 4v11"/><path d="m8 11 4 4 4-4"/><path d="M5 19h14"/></svg>', 'chevron': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m9 6 6 6-6 6"/></svg>', 'file': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v5h5"/></svg>', 'upload-cloud': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 18H6a4 4 0 0 1-.5-8A6 6 0 0 1 17 8a5 5 0 0 1 1 10h-1"/><path d="M12 16V9"/><path d="m9 12 3-3 3 3"/></svg>', 'shield': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3 5 6v5c0 4.8 2.8 8 7 10 4.2-2 7-5.2 7-10V6z"/><path d="m9 12 2 2 4-4"/></svg>', 'play': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m8 5 11 7-11 7z"/></svg>', 'alert': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 4 3 20h18z"/><path d="M12 9v5M12 17h.01"/></svg>', 'check': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m5 12 4 4L19 6"/></svg>', 'review': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/></svg>', 'search': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="6"/><path d="m16 16 4 4"/></svg>', 'info': '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></svg>'}

ICONS["chart"] = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20V8"/><path d="M2 20h22"/></svg>'

@app.context_processor
def inject_helpers():
    return {
        "icon": lambda nombre: ICONS.get(nombre, "")
    }


# ============================================================
# RUTAS
# ============================================================

@app.get("/")
def inicio():
    datos = obtener_dashboard()
    return render_template(
        "inicio.html",
        **contexto_base("inicio", "Inicio"),
        datos=datos,
    )


@app.get("/nueva-revision")
def nueva_revision():
    return render_template(
        "nueva_revision.html",
        **contexto_base("nueva", "Nueva revisión"),
        meses=MESES,
        anios=ANIOS_DISPONIBLES,
        mes_seleccionado="",
        anio_seleccionado=ANIO_ACTUAL,
    )


@app.post("/nueva-revision")
def procesar_revision():
    archivo = request.files.get("archivo")
    mes = request.form.get("mes", "").strip().upper()
    anio = request.form.get("anio", "").strip()

    contexto_form = {
        "meses": MESES,
        "anios": ANIOS_DISPONIBLES,
        "mes_seleccionado": mes,
        "anio_seleccionado": int(anio) if anio.isdigit() else ANIO_ACTUAL,
    }

    if mes not in MESES:
        return render_template(
            "nueva_revision.html",
            **contexto_base("nueva", "Nueva revisión"),
            **contexto_form,
            error="Selecciona el mes que corresponde al archivo.",
        )

    if not anio.isdigit() or int(anio) not in ANIOS_DISPONIBLES:
        return render_template(
            "nueva_revision.html",
            **contexto_base("nueva", "Nueva revisión"),
            **contexto_form,
            error="Selecciona un año válido.",
        )

    if archivo is None or not archivo.filename:
        return render_template(
            "nueva_revision.html",
            **contexto_base("nueva", "Nueva revisión"),
            **contexto_form,
            error="Selecciona un archivo Excel antes de iniciar el análisis.",
        )

    if Path(archivo.filename).suffix.lower() != ".xlsx":
        return render_template(
            "nueva_revision.html",
            **contexto_base("nueva", "Nueva revisión"),
            **contexto_form,
            error="El archivo debe tener extensión .xlsx.",
        )

    REVISIONES_DIR.mkdir(parents=True, exist_ok=True)
    UPLOADS_TEMP_DIR.mkdir(parents=True, exist_ok=True)

    nombre_original = nombre_seguro(archivo.filename)
    ruta_entrada = UPLOADS_TEMP_DIR / f"ENTRADA_{mes}_{anio}_{nombre_original}"
    archivo.save(ruta_entrada)

    salida_consola = io.StringIO()
    ruta_salida_final = REVISIONES_DIR / f"REVISION_INTEGRADA_{mes}_{anio}.xlsx"

    try:
        with contextlib.redirect_stdout(salida_consola):
            motor.procesar_revision_web(
                ruta_entrada=ruta_entrada,
                periodo=mes,
                anio=int(anio),
                ruta_salida=ruta_salida_final,
            )

        resumen = leer_resultado_excel(ruta_salida_final)

        return render_template(
            "resultado.html",
            **contexto_base("nueva", "Resultado de revisión"),
            archivo_original=nombre_original,
            archivo_resultado=ruta_salida_final.name,
            periodo=f"{mes.title()} {anio}",
            resumen=resumen,
            log=salida_consola.getvalue(),
        )

    except Exception as exc:
        return render_template(
            "nueva_revision.html",
            **contexto_base("nueva", "Nueva revisión"),
            **contexto_form,
            error=str(exc),
            archivo_original=nombre_original,
            log=salida_consola.getvalue(),
        )

    finally:
        if ruta_entrada.exists():
            try:
                ruta_entrada.unlink()
            except OSError:
                pass


@app.get("/historial")
def historial():
    resultados = obtener_historial()
    return render_template(
        "historial.html",
        **contexto_base("historial", "Historial"),
        resultados=resultados,
    )


@app.route("/reportes-historicos", methods=["GET", "POST"])
def reportes_historicos():
    mensaje = ""
    tipo_mensaje = ""

    if request.method == "POST":
        archivo = request.files.get("archivo")
        mes = request.form.get("mes", "").strip().upper()
        anio_txt = request.form.get("anio", "").strip()

        if mes not in MESES:
            mensaje, tipo_mensaje = "Selecciona un mes válido.", "error"
        elif not anio_txt.isdigit() or not (2000 <= int(anio_txt) <= 2100):
            mensaje, tipo_mensaje = "Captura un año válido.", "error"
        elif archivo is None or not archivo.filename:
            mensaje, tipo_mensaje = "Selecciona un archivo Excel.", "error"
        elif Path(archivo.filename).suffix.lower() != ".xlsx":
            mensaje, tipo_mensaje = "El archivo debe tener extensión .xlsx.", "error"
        else:
            temporal = BASE_DIR / ("__carga_historica_" + nombre_seguro(archivo.filename))
            try:
                archivo.save(temporal)
                total = registrar_reporte_historico(
                    temporal,
                    nombre_seguro(archivo.filename),
                    mes,
                    int(anio_txt),
                )
                mensaje = (
                    f"Reporte de {mes.title()} {anio_txt} almacenado correctamente. "
                    f"Se registraron {total:,} artículos."
                )
                tipo_mensaje = "success"
            except Exception as exc:
                mensaje, tipo_mensaje = str(exc), "error"
            finally:
                if temporal.exists():
                    try:
                        temporal.unlink()
                    except OSError:
                        pass

    reportes = obtener_reportes_historicos()
    return render_template(
        "reportes_historicos.html",
        **contexto_base("reportes_historicos", "Reportes históricos"),
        reportes=reportes,
        meses=MESES,
        anio_actual=ANIO_ACTUAL,
        mensaje=mensaje,
        tipo_mensaje=tipo_mensaje,
    )


@app.get("/reportes-historicos/descargar/<int:reporte_id>")
def descargar_reporte_historico(reporte_id):
    asegurar_tablas_reportes_historicos()
    con = conexion()
    try:
        fila = con.execute(
            "SELECT ruta_relativa, nombre_original FROM reportes_historicos WHERE id=?",
            (reporte_id,),
        ).fetchone()
    finally:
        con.close()

    if not fila:
        abort(404)
    ruta = BASE_DIR / fila[0]
    if not ruta.exists():
        abort(404)
    return send_file(ruta, as_attachment=True, download_name=fila[1])


@app.get("/consulta-articulos")
def consulta_articulos():
    codigo = request.args.get("codigo", "").strip()
    resultado = buscar_articulo_historico(codigo) if codigo else None
    buscado = bool(codigo)
    return render_template(
        "consulta_articulos.html",
        **contexto_base("consulta_articulos", "Consulta de artículos"),
        codigo=codigo,
        resultado=resultado,
        buscado=buscado,
    )


@app.get("/desviaciones-mensuales")
def desviaciones_mensuales():
    datos = obtener_desviaciones_mensuales_2026()
    return render_template(
        "desviaciones_mensuales.html",
        **contexto_base("mensual", "Desviaciones mensuales 2026"),
        datos=datos,
    )


@app.get("/usuarios")
def usuarios():
    acumulado = obtener_top5_acumulado_2026()
    meses_con_datos = []
    for fila in acumulado:
        if fila["mes"] not in meses_con_datos:
            meses_con_datos.append(fila["mes"])

    return render_template(
        "usuarios.html",
        **contexto_base("usuarios", "Usuarios con desviaciones 2026"),
        acumulado=acumulado,
        meses_con_datos=meses_con_datos,
    )


@app.route("/usuarios/lista", methods=["GET", "POST"])
def usuarios_lista():
    mensaje = ""
    tipo_mensaje = ""

    if request.method == "POST":
        numero = str(request.form.get("numero_empleado", "")).strip()
        nombre = str(request.form.get("nombre_empleado", "")).strip()

        # Normalizar números provenientes de Excel o captura manual.
        if numero.endswith(".0") and numero[:-2].isdigit():
            numero = numero[:-2]

        if not numero or not nombre:
            mensaje = "Captura el número de empleado y el nombre."
            tipo_mensaje = "error"
        elif not numero.isdigit():
            mensaje = "El número de empleado debe contener únicamente números."
            tipo_mensaje = "error"
        else:
            con = conexion()
            try:
                existente = con.execute(
                    "SELECT nombre_usuario FROM usuarios WHERE usuario = ?",
                    (numero,)
                ).fetchone()

                if existente:
                    mensaje = (
                        f"El usuario {numero} ya está registrado como "
                        f"{existente[0]}."
                    )
                    tipo_mensaje = "warning"
                else:
                    con.execute(
                        """
                        INSERT INTO usuarios (usuario, nombre_usuario)
                        VALUES (?, ?)
                        """,
                        (numero, nombre.upper())
                    )
                    con.commit()
                    mensaje = f"Usuario {numero} agregado correctamente."
                    tipo_mensaje = "success"
            finally:
                con.close()

            # Si el alta fue exitosa, actualizar inmediatamente las
            # revisiones ya generadas para que páginas y descargas
            # de meses anteriores reflejen el nombre nuevo.
            if tipo_mensaje == "success":
                cambios = sincronizar_todas_las_revisiones()
                if cambios:
                    mensaje += (
                        f" Se actualizaron {cambios} registro(s) "
                        "en las revisiones existentes."
                    )

    q = request.args.get("q", "").strip()
    filas = obtener_usuarios(q)

    return render_template(
        "usuarios_lista.html",
        **contexto_base("usuarios", "Lista de usuarios"),
        usuarios=filas,
        q=q,
        total=contar_tabla("usuarios"),
        mensaje=mensaje,
        tipo_mensaje=tipo_mensaje,
    )


@app.get("/usuarios/desviaciones")
def usuarios_desviaciones():
    archivos = obtener_historial()

    datos = None
    periodo = ""
    archivo_resultado = ""

    if archivos:
        ultimo = archivos[0]
        ruta = REVISIONES_DIR / ultimo["archivo"]
        datos = leer_resultado_excel(ruta)
        periodo = ultimo.get("periodo", "")
        archivo_resultado = ultimo.get("archivo", "")

    total_desviaciones = 0
    top5 = []
    total_top5 = 0
    porcentaje_top5 = 0.0
    usuarios_general = 0
    usuarios_con_desviaciones = 0
    porcentaje_usuarios_desviaciones = 0.0
    codigos_top5 = []

    if datos:
        total_desviaciones = int(datos.get("con_observacion", 0) or 0)
        top5 = datos.get("top_usuarios_desviaciones", []) or []
        total_top5 = sum(int(item.get("cantidad", 0) or 0) for item in top5)

        if total_desviaciones > 0:
            porcentaje_top5 = (total_top5 / total_desviaciones) * 100

        usuarios_general = int(datos.get("usuarios_general", 0) or 0)
        usuarios_con_desviaciones = int(
            datos.get("usuarios_con_desviaciones", 0) or 0
        )
        porcentaje_usuarios_desviaciones = float(
            datos.get("porcentaje_usuarios_desviaciones", 0.0) or 0.0
        )
        codigos_top5 = datos.get("codigos_top5", []) or []

    return render_template(
        "usuarios_desviaciones.html",
        **contexto_base("usuarios", "Usuarios - Top desviaciones"),
        periodo=periodo,
        archivo_resultado=archivo_resultado,
        total_desviaciones=total_desviaciones,
        top5=top5,
        total_top5=total_top5,
        porcentaje_top5=porcentaje_top5,
        usuarios_general=usuarios_general,
        usuarios_con_desviaciones=usuarios_con_desviaciones,
        porcentaje_usuarios_desviaciones=porcentaje_usuarios_desviaciones,
        codigos_top5=codigos_top5,
    )


@app.get("/usuarios/distribucion")
def usuarios_distribucion():
    archivos = obtener_historial()
    periodo = ""
    distribucion = []

    # Valores del panel "Usuarios que codificaron".
    # Se inicializan siempre para evitar errores si no hay historial,
    # si el archivo no contiene alguna métrica o si se abre la página
    # antes de generar una revisión nueva.
    usuarios_general = 0
    usuarios_con_desviaciones = 0
    porcentaje_usuarios_desviaciones = 0.0

    if archivos:
        ultimo = archivos[0]
        ruta = REVISIONES_DIR / ultimo["archivo"]
        datos = leer_resultado_excel(ruta) or {}
        periodo = ultimo.get("periodo", "")

        distribucion = datos.get("distribucion_usuarios", []) or []
        usuarios_general = int(datos.get("usuarios_general", 0) or 0)
        usuarios_con_desviaciones = int(
            datos.get("usuarios_con_desviaciones", 0) or 0
        )
        porcentaje_usuarios_desviaciones = float(
            datos.get("porcentaje_usuarios_desviaciones", 0.0) or 0.0
        )

    # Acceso defensivo con .get(): revisiones anteriores pueden no contener
    # exactamente todas las claves de la tabla de distribución.
    totales = {
        "ortografia": sum(int(x.get("ortografia", 0) or 0) for x in distribucion),
        "especificacion": sum(int(x.get("especificacion", 0) or 0) for x in distribucion),
        "clasificacion": sum(int(x.get("clasificacion", 0) or 0) for x in distribucion),
        "duplicado": sum(int(x.get("duplicado", 0) or 0) for x in distribucion),
        "total": sum(int(x.get("total", 0) or 0) for x in distribucion),
    }

    return render_template(
        "usuarios_distribucion.html",
        **contexto_base("usuarios", "Usuarios - Distribución de desviaciones"),
        periodo=periodo,
        distribucion=distribucion,
        totales=totales,
        usuarios_general=usuarios_general,
        usuarios_con_desviaciones=usuarios_con_desviaciones,
        porcentaje_usuarios_desviaciones=porcentaje_usuarios_desviaciones,
    )


@app.get("/catalogo")
def catalogo():
    q = request.args.get("q", "").strip()
    filas = obtener_catalogo(q)
    return render_template(
        "catalogo.html",
        **contexto_base("catalogo", "Catálogo"),
        catalogo=filas,
        q=q,
        total=contar_tabla("catalogo_subgrupos"),
    )


@app.get("/configuracion")
def configuracion():
    tablas = {
        "Artículos históricos": contar_tabla("articulos_historico"),
        "Usuarios": contar_tabla("usuarios"),
        "Catálogo de subgrupos": contar_tabla("catalogo_subgrupos"),
        "Campos de plantilla": contar_tabla("campos_plantilla"),
        "Revisiones históricas": contar_tabla("revisiones_historicas"),
        "Diccionario de redacción": contar_tabla("diccionario_redaccion"),
    }
    return render_template(
        "configuracion.html",
        **contexto_base("configuracion", "Configuración"),
        tablas=tablas,
    )


@app.get("/descargar/<path:nombre>")
def descargar(nombre):
    nombre = nombre_seguro(nombre)

    if not nombre.upper().startswith("REVISION_INTEGRADA_"):
        abort(403)

    ruta = REVISIONES_DIR / nombre

    if not ruta.exists() or ruta.suffix.lower() != ".xlsx":
        abort(404)

    # Las revisiones creadas antes del nuevo formato se convierten
    # automáticamente justo antes de la descarga. No hace falta reprocesarlas.
    motor.asegurar_formato_reporte_descargable(ruta)

    # Asegurar que la descarga siempre use la lista de usuarios actual.
    sincronizar_revision_con_usuarios(ruta)

    # Las hojas de reporte se reconstruyen con las mismas estructuras y
    # cálculos que alimentan la página web. Artículos se conserva intacta.
    actualizar_reporte_excel_desde_web(ruta)

    return send_file(
        ruta,
        as_attachment=True,
        download_name=ruta.name,
    )


@app.errorhandler(413)
def archivo_demasiado_grande(_):
    return render_template(
        "nueva_revision.html",
        **contexto_base("nueva", "Nueva revisión"),
        error="El archivo supera el límite máximo permitido de 80 MB.",
    ), 413


if __name__ == "__main__":
    print("=" * 72)
    print("SISTEMA WEB DE REVISION DE CODIFICACIONES")
    print("=" * 72)
    print("Abre en tu navegador:")
    print("http://127.0.0.1:5000")
    print()
    app.run(host="127.0.0.1", port=5000, debug=False)
