# -*- coding: utf-8 -*-
"""
SEGUNDA CAPA CONSERVADORA DE REVISION HISTORICA
================================================

Este módulo NO sustituye los diagnósticos validados.
Solo intenta resolver artículos que ya terminaron como REVISAR y que no
poseen una observación oficial.

Fuentes:
- SQLite: tabla revisiones_historicas.
- Decisiones manuales de meses anteriores.

Principio de seguridad:
- La ausencia de evidencia nunca se interpreta como OK.
- Un antecedente contradictorio cercano impide la resolución automática.
- No crea desviaciones nuevas; únicamente puede convertir REVISAR -> OK.
"""

import re
import sqlite3
import unicodedata
from collections import defaultdict
from difflib import SequenceMatcher


# Umbrales deliberadamente altos para priorizar precisión sobre cobertura.
UMBRAL_BUSQUEDA = 0.78
UMBRAL_CONTRADICCION = 0.86
UMBRAL_UN_CASO = 0.97
UMBRAL_DOS_CASOS = 0.91
UMBRAL_TRES_CASOS = 0.88
MAX_CANDIDATOS_DETALLE = 3

PALABRAS_VACIAS = {
    "DE", "DEL", "LA", "EL", "LOS", "LAS", "UN", "UNA", "UNOS", "UNAS",
    "PARA", "POR", "CON", "Y", "E", "EN", "A", "AL", "QUE", "TIPO",
}


def _sin_acentos(texto):
    texto = "" if texto is None else str(texto)
    return "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )


def normalizar_clave(valor):
    texto = "" if valor is None else str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    if texto.isdigit():
        texto = texto.zfill(2)
    return texto.upper()


def normalizar_texto(texto, abstraer_numeros=False):
    texto = _sin_acentos(texto).upper()
    texto = texto.replace("Ø", " DIAMETRO ")
    texto = texto.replace("°", " GRADOS ")

    # Homologaciones conservadoras frecuentes en el catálogo.
    reemplazos = {
        "ACERO AL CARBONO": "ACERO AL CARBON",
        "PULGADAS": "PULG",
        "PULGADA": "PULG",
        "CEDULA": "CED",
        "DIAMETRO": "DIAM",
        "ESPECIFICACION": "ESPEC",
    }
    for origen, destino in reemplazos.items():
        texto = texto.replace(origen, destino)

    if abstraer_numeros:
        # Para reconocer el mismo patrón técnico en distintas dimensiones.
        # A234, 16", 300, etc. se convierten en marcadores de valor, pero
        # los términos técnicos que los rodean se conservan.
        texto = re.sub(r"\d+(?:[./-]\d+)*", " NUM ", texto)

    texto = re.sub(r"[^A-Z0-9#]+", " ", texto)
    tokens = [
        t for t in texto.split()
        if t and t not in PALABRAS_VACIAS
    ]
    return " ".join(tokens)


def _tokens(texto):
    return set(normalizar_texto(texto, abstraer_numeros=True).split())


def similitud(descripcion_a, descripcion_b):
    """Similitud de estructura técnica, no solo de caracteres."""
    a = normalizar_texto(descripcion_a, abstraer_numeros=True)
    b = normalizar_texto(descripcion_b, abstraer_numeros=True)
    if not a or not b:
        return 0.0

    seq = SequenceMatcher(None, a, b).ratio()
    ta = set(a.split())
    tb = set(b.split())
    if not ta or not tb:
        return seq

    inter = len(ta & tb)
    union = len(ta | tb)
    jaccard = inter / union if union else 0.0
    contencion = inter / min(len(ta), len(tb)) if min(len(ta), len(tb)) else 0.0

    # La secuencia conserva estructura; Jaccard y contención toleran cambios
    # de medida sin perder los términos técnicos principales.
    return round((0.50 * seq) + (0.30 * jaccard) + (0.20 * contencion), 6)


def _obs(valor):
    # Normalización de ETIQUETAS de base de datos. No aplicar las
    # homologaciones técnicas de descripciones (p. ej. ESPECIFICACION -> ESPEC).
    texto = _sin_acentos(valor).upper().strip()
    texto = re.sub(r"[^A-Z0-9]+", " ", texto)
    return re.sub(r"\s+", " ", texto).strip()


class MotorRevisionHistorica:
    def __init__(self, db_path):
        self.db_path = db_path
        self.por_clasificacion = defaultdict(list)
        self.total_registros = 0
        self.disponible = False
        self._cargar()

    def _cargar(self):
        try:
            con = sqlite3.connect(self.db_path)
        except Exception:
            return

        try:
            existe = con.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' "
                "AND name='revisiones_historicas'"
            ).fetchone()
            if not existe:
                return

            columnas = {
                fila[1].lower(): fila[1]
                for fila in con.execute(
                    "PRAGMA table_info(revisiones_historicas)"
                ).fetchall()
            }

            necesarios = {"codigo", "grupo", "subgrupo", "descripcion", "observacion"}
            if not necesarios.issubset(columnas):
                return

            def col(nombre, defecto="''"):
                real = columnas.get(nombre)
                return f'"{real}"' if real else defecto

            sql = f"""
                SELECT
                    {col('codigo')},
                    {col('grupo')},
                    {col('subgrupo')},
                    {col('descripcion')},
                    {col('observacion')},
                    {col('subobservacion')},
                    {col('estado_clasificacion')},
                    {col('mes')},
                    {col('anio', 'NULL')}
                FROM revisiones_historicas
                WHERE TRIM(COALESCE({col('descripcion')}, '')) <> ''
            """

            for fila in con.execute(sql):
                codigo, grupo, subgrupo, descripcion, observacion, subobs, estado_clas, mes, anio = fila
                clave = (normalizar_clave(grupo), normalizar_clave(subgrupo))
                if not all(clave):
                    continue
                registro = {
                    "codigo": "" if codigo is None else str(codigo).strip(),
                    "grupo": clave[0],
                    "subgrupo": clave[1],
                    "descripcion": "" if descripcion is None else str(descripcion),
                    "observacion": _obs(observacion),
                    "subobservacion": _obs(subobs),
                    "estado_clasificacion": _obs(estado_clas),
                    "mes": "" if mes is None else str(mes).strip(),
                    "anio": anio,
                }
                self.por_clasificacion[clave].append(registro)
                self.total_registros += 1

            self.disponible = self.total_registros > 0
        except Exception:
            self.disponible = False
        finally:
            con.close()

    @staticmethod
    def _modulos_pendientes(casos_revisar):
        modulos = {
            _obs(caso.get("Modulo", ""))
            for caso in casos_revisar
            if caso
        }
        return {m for m in modulos if m}

    @staticmethod
    def _apoya(registro, modulos):
        obs = registro["observacion"]
        est = registro["estado_clasificacion"]

        # Para incertidumbre de plantilla, solo un artículo manualmente OK
        # se considera respaldo suficiente. Una desviación técnica previa no
        # se usa para "perdonar" el caso actual.
        if any("PLANTILLA" in m for m in modulos):
            if obs != "OK":
                return False

        # Para clasificación, cualquier decisión histórica que explícitamente
        # valide la clasificación o que sea OK respalda la clasificación actual.
        if any("CLASIFICACION" in m for m in modulos):
            clas_ok = (
                "CORRECT" in est
                or est in {"OK", "COINCIDE"}
                or obs == "OK"
            )
            if not clas_ok:
                return False

        # Otros módulos no se resuelven automáticamente con histórico.
        conocidos = all(
            ("PLANTILLA" in m) or ("CLASIFICACION" in m)
            for m in modulos
        )
        return bool(modulos) and conocidos

    @staticmethod
    def _contradice(registro, modulos):
        obs = registro["observacion"]
        est = registro["estado_clasificacion"]

        if any("PLANTILLA" in m for m in modulos):
            if obs == "ESPECIFICACION TECNICA":
                return True

        if any("CLASIFICACION" in m for m in modulos):
            if obs == "CLASIFICACION":
                return True
            if "INCORRECT" in est:
                return True
            if "GRUPO" in est and "CORRECT" not in est:
                return True
            if "SUBGRUPO" in est and "CORRECT" not in est:
                return True

        return False

    def evaluar(self, descripcion, grupo, subgrupo, casos_revisar):
        respuesta_base = {
            "resolver": False,
            "confianza": 0.0,
            "detalle": "",
            "ejemplos": [],
            "mejor_similitud": 0.0,
            "apoyos": 0,
            "contradicciones": 0,
        }

        if not self.disponible:
            return respuesta_base

        modulos = self._modulos_pendientes(casos_revisar)
        if not modulos:
            return respuesta_base

        # No resolver módulos para los que esta capa no fue diseñada.
        if any(
            ("PLANTILLA" not in m) and ("CLASIFICACION" not in m)
            for m in modulos
        ):
            return respuesta_base

        clave = (normalizar_clave(grupo), normalizar_clave(subgrupo))
        historicos = self.por_clasificacion.get(clave, [])
        if not historicos:
            return respuesta_base

        evaluados = []
        for reg in historicos:
            sim = similitud(descripcion, reg["descripcion"])
            if sim < UMBRAL_BUSQUEDA:
                continue
            evaluados.append((sim, reg))

        if not evaluados:
            return respuesta_base

        evaluados.sort(key=lambda x: x[0], reverse=True)
        apoyos = [x for x in evaluados if self._apoya(x[1], modulos)]
        contradicciones = [x for x in evaluados if self._contradice(x[1], modulos)]

        respuesta_base["apoyos"] = len(apoyos)
        respuesta_base["contradicciones"] = len(contradicciones)
        respuesta_base["mejor_similitud"] = round(evaluados[0][0] * 100, 1)

        # Cualquier contradicción suficientemente cercana bloquea el OK.
        contradiccion_fuerte = next(
            (x for x in contradicciones if x[0] >= UMBRAL_CONTRADICCION),
            None,
        )
        if contradiccion_fuerte:
            sim, reg = contradiccion_fuerte
            respuesta_base["detalle"] = (
                "Antecedente contradictorio cercano: "
                f'{reg["codigo"]} ({sim * 100:.1f}%).'
            )
            return respuesta_base

        sims_apoyo = [x[0] for x in apoyos]
        resolver = False
        if len(sims_apoyo) >= 1 and sims_apoyo[0] >= UMBRAL_UN_CASO:
            resolver = True
        elif len(sims_apoyo) >= 2 and sum(sims_apoyo[:2]) / 2 >= UMBRAL_DOS_CASOS:
            resolver = True
        elif len(sims_apoyo) >= 3 and sum(sims_apoyo[:3]) / 3 >= UMBRAL_TRES_CASOS:
            resolver = True

        if not resolver:
            return respuesta_base

        ejemplos = []
        for sim, reg in apoyos[:MAX_CANDIDATOS_DETALLE]:
            ejemplos.append({
                "codigo": reg["codigo"],
                "similitud": round(sim * 100, 1),
                "mes": reg["mes"],
                "observacion": reg["observacion"],
            })

        # Confianza operacional de la regla, no probabilidad estadística.
        if len(sims_apoyo) >= 3:
            base = sum(sims_apoyo[:3]) / 3
        elif len(sims_apoyo) >= 2:
            base = sum(sims_apoyo[:2]) / 2
        else:
            base = sims_apoyo[0]
        confianza = min(98.0, max(90.0, base * 100))

        refs = ", ".join(
            f'{e["codigo"]} ({e["similitud"]:.1f}%)'
            for e in ejemplos
        )
        respuesta_base.update({
            "resolver": True,
            "confianza": round(confianza, 1),
            "ejemplos": ejemplos,
            "detalle": (
                f"{len(apoyos)} antecedente(s) manual(es) del mismo Grupo/Subgrupo "
                f"respaldan el patrón técnico. Referencias: {refs}. "
                "Sin contradicciones históricas cercanas."
            ),
        })
        return respuesta_base
