@echo off
cd /d "%~dp0"
echo Instalando dependencias de la interfaz web...
python -m pip install -r requirements.txt
echo.
echo Instalacion terminada.
pause
