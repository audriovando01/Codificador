# -*- coding: utf-8 -*-
"""
SISTEMA INTEGRADO DE REVISION DE CODIFICACIONES
================================================

Integra los módulos ya validados:
- ORTOGRAFIA
- REDACCION INCORRECTA
- DUPLICADOS
- ESPECIFICACION TECNICA:
    * SUB-ESPECIFICADO
    * LLENADO INADECUADO DE PLANTILLA
- CLASIFICACION:
    * GRUPO INCORRECTO
    * SUBGRUPO INCORRECTO
    * COINCIDE / REVISAR

SOBRE-ESPECIFICADO NO se evalúa por ahora.

Entrada:
    El RESULTADO_*.xlsx más reciente de la carpeta de revisión.

Base de datos:
    base_datos.db ubicada en la misma carpeta que este script.

Salida:
    REVISION_INTEGRADA_<PERIODO>.xlsx

IMPORTANTE:
Las reglas internas de cada módulo se mantienen separadas en espacios
de nombres para evitar colisiones entre funciones homónimas.
"""

import os
import re
import glob
import sqlite3
import time
import unicodedata
from pathlib import Path
from collections import Counter, defaultdict

import pandas as pd

from copy import copy
from openpyxl import load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side

from diagnostico_revision_historica import MotorRevisionHistorica

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "base_datos.db")
REVISIONES_DIR = os.path.join(BASE_DIR, "revisiones_web")


# ============================================================
# UTILIDADES GENERALES
# ============================================================

def quitar_acentos_general(texto):
    texto = "" if pd.isna(texto) else str(texto)
    return "".join(
        c for c in unicodedata.normalize("NFD", texto)
        if unicodedata.category(c) != "Mn"
    )


def clave_columna(texto):
    return quitar_acentos_general(texto).upper().strip()


def normalizar_codigo_general(valor):
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    return texto


def normalizar_clave_general(valor):
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    if texto.isdigit() and len(texto) < 2:
        texto = texto.zfill(2)
    return texto


def normalizar_periodo(texto):
    return quitar_acentos_general(texto).upper().strip()


MESES = [
    "ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO",
    "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE",
]

def localizar_hoja_original(ruta):
    """
    Localiza la hoja que contiene el archivo mensual original.
    Se da prioridad a una hoja llamada ORIGINAL. Si no existe, busca
    una hoja que tenga las columnas mínimas necesarias.
    """
    excel = pd.ExcelFile(ruta, engine="openpyxl")

    hojas_ordenadas = list(excel.sheet_names)
    hojas_ordenadas.sort(
        key=lambda h: 0 if normalizar_periodo(h) == "ORIGINAL" else 1
    )

    requeridas = {
        "CODIGO", "GRUPO", "SUBGRUPO", "DESCRIPCION", "USUARIO", "UM"
    }

    for hoja in hojas_ordenadas:
        try:
            muestra = pd.read_excel(
                ruta,
                sheet_name=hoja,
                nrows=5,
                dtype=str,
                engine="openpyxl",
            )
        except Exception:
            continue

        claves = {clave_columna(c) for c in muestra.columns}
        if requeridas.issubset(claves):
            return hoja

    return None


def cargar_archivo_mensual_original(ruta_entrada, periodo):
    """Lee exclusivamente el Excel recibido desde la aplicación web."""
    ruta_entrada = os.path.abspath(str(ruta_entrada))
    if not os.path.exists(ruta_entrada):
        raise FileNotFoundError("El archivo subido ya no está disponible.")
    periodo = normalizar_periodo(periodo)
    if periodo not in MESES:
        raise ValueError("El mes seleccionado en la web no es válido.")
    hoja = localizar_hoja_original(ruta_entrada)
    if hoja is None:
        raise ValueError("El Excel subido no contiene Codigo, Grupo, Subgrupo, Descripción, Usuario y UM.")
    df = pd.read_excel(ruta_entrada, sheet_name=hoja, dtype=str, engine="openpyxl")
    df.columns = [str(c).strip() for c in df.columns]
    mapa = {clave_columna(c): c for c in df.columns}
    requeridas = ["CODIGO", "GRUPO", "SUBGRUPO", "DESCRIPCION", "USUARIO", "UM"]
    faltantes = [c for c in requeridas if c not in mapa]
    if faltantes:
        raise ValueError("Faltan columnas requeridas: " + ", ".join(faltantes))
    return ruta_entrada, hoja, df, mapa, periodo


def preparar_nuevos_desde_sqlite(df, mapa, periodo, anio):
    """
    Compara directamente el archivo mensual original contra articulos_historico.

    - Código inexistente en SQLite -> NUEVO y se agrega al histórico.
    - Código ya guardado con mes = periodo actual -> NUEVO (permite reejecuciones).
    - Cualquier otro código existente -> YA EXISTIA.

    Devuelve el DataFrame completo con una columna Estado agregada.
    """
    c_codigo = mapa["CODIGO"]
    c_grupo = mapa["GRUPO"]
    c_subgrupo = mapa["SUBGRUPO"]
    c_desc = mapa["DESCRIPCION"]
    c_usuario = mapa["USUARIO"]
    c_um = mapa["UM"]

    periodo_bd = normalizar_periodo(periodo)
    anio = int(anio)

    conn = sqlite3.connect(DB_PATH)
    try:
        existe_tabla = conn.execute(
            """
            SELECT 1
            FROM sqlite_master
            WHERE type = 'table' AND name = 'articulos_historico'
            """
        ).fetchone()

        if not existe_tabla:
            raise RuntimeError(
                "No existe la tabla articulos_historico en base_datos.db."
            )

        columnas_bd = {str(f[1]).lower() for f in conn.execute("PRAGMA table_info(articulos_historico)").fetchall()}
        if "anio" not in columnas_bd:
            conn.execute("ALTER TABLE articulos_historico ADD COLUMN anio INTEGER")
            marcas = ",".join("?" for _ in MESES)
            conn.execute(
                f"UPDATE articulos_historico SET anio=2026 WHERE anio IS NULL AND UPPER(TRIM(COALESCE(mes,''))) IN ({marcas})",
                MESES,
            )
            conn.commit()

        # Índices persistentes: aceleran búsquedas actuales y futuras.
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_articulos_historico_codigo "
            "ON articulos_historico(codigo)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_articulos_historico_periodo "
            "ON articulos_historico(anio, mes)"
        )
        conn.commit()

        # Consultar únicamente los códigos presentes en el Excel subido,
        # en lugar de cargar toda la base histórica a Python.
        codigos_archivo = [
            normalizar_codigo_general(v) for v in df[c_codigo].tolist()
        ]
        codigos_unicos = list(dict.fromkeys(c for c in codigos_archivo if c))
        historico = {}
        for i in range(0, len(codigos_unicos), 800):
            bloque = codigos_unicos[i:i + 800]
            if not bloque:
                continue
            marcas = ",".join("?" for _ in bloque)
            filas_bd = conn.execute(
                f"SELECT codigo, mes, anio FROM articulos_historico "
                f"WHERE codigo IN ({marcas})",
                bloque,
            ).fetchall()
            for codigo, mes, anio_bd in filas_bd:
                historico[normalizar_codigo_general(codigo)] = (
                    normalizar_periodo(mes),
                    int(anio_bd) if anio_bd is not None else None,
                )


        estados = []
        registros_nuevos = []
        codigos_a_insertar = set()

        for _, fila in df.iterrows():
            codigo = normalizar_codigo_general(fila[c_codigo])

            if not codigo:
                estados.append("")
                continue

            periodo_existente = historico.get(codigo)

            if periodo_existente is None:
                estado = "NUEVO"

                if codigo not in codigos_a_insertar:
                    registros_nuevos.append((
                        codigo,
                        normalizar_clave_general(fila[c_grupo]),
                        normalizar_clave_general(fila[c_subgrupo]),
                        "" if pd.isna(fila[c_desc]) else str(fila[c_desc]).strip(),
                        normalizar_usuario(fila[c_usuario]),
                        "" if pd.isna(fila[c_um]) else str(fila[c_um]).strip(),
                        periodo_bd,
                        anio,
                    ))
                    codigos_a_insertar.add(codigo)
                    historico[codigo] = (periodo_bd, anio)

            elif periodo_existente == (periodo_bd, anio):
                # El artículo ya fue cargado en una ejecución anterior del mismo mes.
                estado = "NUEVO"
            else:
                estado = "YA EXISTIA"

            estados.append(estado)

        if registros_nuevos:
            conn.executemany(
                """
                INSERT OR IGNORE INTO articulos_historico
                    (codigo, grupo, subgrupo, descripcion, usuario, um, mes, anio)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                registros_nuevos,
            )
            conn.commit()

    finally:
        conn.close()

    resultado = df.copy()
    resultado["Estado"] = estados

    # Colocar Estado después de Codigo para mantener una estructura familiar.
    columnas = list(resultado.columns)
    columnas.remove("Estado")
    pos_codigo = columnas.index(c_codigo)
    columnas.insert(pos_codigo + 1, "Estado")
    resultado = resultado[columnas]

    mapa_resultado = {clave_columna(c): c for c in resultado.columns}

    return resultado, mapa_resultado, len(registros_nuevos)


def periodo_desde_archivo(ruta):
    # Se conserva esta función para compatibilidad interna.
    return detectar_periodo_archivo(ruta)


def preparar_modulo(source, nombre):
    ns = {
        "__name__": f"_modulo_{nombre}",
        "__file__": os.path.join(BASE_DIR, f"{nombre}.py"),
    }
    exec(compile(source, f"<{nombre}>", "exec"), ns)
    # Forzamos que todos los módulos usen la misma base SQLite del sistema.
    ns["DB_PATH"] = DB_PATH
    return ns



# ============================================================
# CATALOGO DE USUARIOS
# ============================================================

def normalizar_usuario(valor):
    """Normaliza el número de usuario/empleado para poder relacionarlo."""
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    return texto


def asegurar_tabla_usuarios():
    """Crea la tabla de usuarios si todavía no existe."""
    conn = sqlite3.connect(DB_PATH)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS usuarios (
                usuario TEXT PRIMARY KEY,
                nombre_usuario TEXT NOT NULL
            )
            """
        )
        conn.commit()
    finally:
        conn.close()


def cargar_mapa_usuarios():
    """
    Devuelve {numero_usuario: nombre_usuario} desde SQLite.
    La carga inicial se realiza con importar_usuarios.py.
    """
    asegurar_tabla_usuarios()

    conn = sqlite3.connect(DB_PATH)
    try:
        filas = conn.execute(
            """
            SELECT usuario, nombre_usuario
            FROM usuarios
            """
        ).fetchall()
    finally:
        conn.close()

    return {
        normalizar_usuario(usuario): str(nombre).strip()
        for usuario, nombre in filas
        if normalizar_usuario(usuario)
    }


# ============================================================
# MODULOS VALIDADOS EMBEBIDOS
# ============================================================

_SOURCE_ORTOGRAFIA = 'import re\n\nfrom openpyxl import load_workbook, Workbook\n\n# ============================================================\n\n# CONFIGURACIÓN\n\n# ============================================================\n\nARCHIVO_ENTRADA = (\n    r"__WEB_ONLY__"\n    r"RESULTADO_SEPTIEMBRE.xlsx"\n)\n\nARCHIVO_SALIDA = (\n    r"__WEB_ONLY__"\n    r"DIAGNOSTICO_ORTOGRAFIA_SEPTIEMBRE.xlsx"\n)\n\n\n# ============================================================\n\n# CONFIGURACIÓN DE ORTOGRAFÍA\n\n# ============================================================\n\npalabras_permitidas = {\n    "DE",\n    "ASME",\n    "NPT",\n    "MR",\n    "MHZ",\n    "HZ",\n}\n\nCARACTERES_INVALIDOS = {\n    "Ø",\n    "ø",\n    "¿",\n    "?",\n    "|",\n    "®",\n    "™",\n}\n\n\n# ============================================================\n\n# DETECTAR PALABRAS DUPLICADAS\n\n# ============================================================\n\n\ndef detectar_palabras_duplicadas(texto):\n    """\n    Detecta palabras realmente consecutivas en el texto original.\n\n    Los valores numéricos y alfanuméricos se conservan como separadores.\n    Esto evita falsos positivos como:\n      DC:340MM, DC:130MM\n      2/0 AWG ... 6 AWG\n      12.7 CENTIMETROS, 45.7 CENTIMETROS\n\n    Antes los números se eliminaban antes de comparar y las palabras\n    técnicas quedaban artificialmente juntas.\n    """\n    texto_mayusculas = str(texto).upper()\n\n    # Conserva palabras y valores técnicos/números en el orden original.\n    # Ejemplos de tokens: DC, 340MM, DC, 130MM / 2, 0, AWG / 6, AWG.\n    tokens = re.findall(\n        r"[A-ZÁÉÍÓÚÜÑ]+|\\d+(?:[.,]\\d+)?(?:/\\d+)?(?:[A-ZÁÉÍÓÚÜÑ]+)?",\n        texto_mayusculas,\n    )\n\n    palabras_permitidas = {\n        "DE",\n        "ASME",\n        "NPT",\n        "MR",\n        "MHZ",\n        "HZ",\n        "PSI",\n    }\n\n    duplicadas = []\n    palabra_anterior = None\n\n    for token in tokens:\n        # Cualquier token que contenga número rompe la consecutividad.\n        # Así dos unidades iguales asociadas a valores distintos no se\n        # interpretan como palabras duplicadas.\n        if any(caracter.isdigit() for caracter in token):\n            palabra_anterior = None\n            continue\n\n        palabra = token\n\n        # La X se utiliza como separador de dimensiones o extremos.\n        if palabra == "X":\n            palabra_anterior = None\n            continue\n\n        # Si es una palabra técnica permitida, no se reporta como error.\n        if palabra in palabras_permitidas:\n            palabra_anterior = palabra\n            continue\n\n        # Detectar únicamente palabras consecutivas reales.\n        if palabra == palabra_anterior:\n            if palabra not in duplicadas:\n                duplicadas.append(palabra)\n\n        palabra_anterior = palabra\n\n    return duplicadas\n\n\n# ============================================================\n\n# DETECTAR USO DE MINÚSCULAS\n\n# ============================================================\n\n\ndef detectar_minusculas(texto):\n\n    unidades = {\n        "mm",\n        "cm",\n        "m",\n        "km",\n        "ft",\n        "in",\n        "kg",\n        "g",\n        "mg",\n        "lb",\n        "lbs",\n        "hz",\n        "khz",\n        "mhz",\n        "ghz",\n        "kw",\n        "kva",\n        "kvar",\n        "kwh",\n        "mah",\n        "dbm",\n        "psi",\n        "pa",\n        "mpa",\n        "lm",\n        "lm/w",\n        "ma",\n        "ua",\n        "v",\n        "w",\n        "a",\n        "ka",\n        "kaic",\n    }\n\n    palabras_detectadas = []\n\n    tokens = re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9°±./:+\\-]+", texto)\n\n    for token in tokens:\n\n        if not token:\n\n            continue\n\n        if token.upper() == "NO":\n\n            continue\n\n        if token.upper() == "X":\n\n            continue\n\n        if any(char.isdigit() for char in token):\n\n            continue\n\n        if any(char in token for char in ["/", "-", ":", "+", ".", "°", "±"]):\n\n            continue\n\n        if token.lower() in unidades:\n\n            continue\n\n        if token == token.upper():\n\n            continue\n\n        palabras_detectadas.append(token)\n\n    return palabras_detectadas\n\n\n# ============================================================\n\n# DETECTAR CARACTERES INVÁLIDOS\n\n# ============================================================\n\n\ndef detectar_caracteres_invalidos(texto):\n\n    encontrados = []\n\n    # --------------------------------------------------------\n    # CARACTERES PROHIBIDOS\n    # --------------------------------------------------------\n\n    for caracter in CARACTERES_INVALIDOS:\n\n        if caracter in texto and caracter not in encontrados:\n\n            encontrados.append(caracter)\n\n    # --------------------------------------------------------\n    # VALORES QUE NO DEBEN UTILIZARSE\n    # --------------------------------------------------------\n\n    texto_mayusculas = texto.upper()\n\n    patrones_valores_invalidos = [\n        r"\\bNO\\s+APLICA\\b",\n        r"\\bN/A\\b",\n        r"\\bNA\\b",\n    ]\n\n    for patron in patrones_valores_invalidos:\n\n        if re.search(patron, texto_mayusculas):\n\n            valor = re.search(patron, texto_mayusculas).group()\n\n            if valor not in encontrados:\n\n                encontrados.append(valor)\n\n    # --------------------------------------------------------\n    # PUNTO O GUION COMO VALOR DE UN CAMPO\n    #\n    # Ejemplos incorrectos:\n    # EXTREMO .\n    # EXTREMO -\n    # MATERIAL .\n    # TIPO -\n    #\n    # No se consideran inválidos puntos o guiones que formen\n    # parte de valores normales como:\n    # A-36, 15.2, 10-1757, etc.\n    # --------------------------------------------------------\n\n    patron_campo_vacio = re.compile(\n        r"\\b("\n        r"EXTREMO|"\n        r"MATERIAL|"\n        r"TIPO|"\n        r"MARCA|"\n        r"MODELO|"\n        r"FABRICANTE|"\n        r"DESCRIPCION|"\n        r"DESCRIPCIÓN|"\n        r"COLOR|"\n        r"ACABADO|"\n        r"OBSERVACION|"\n        r"OBSERVACIÓN|"\n        r"CLASE|"\n        r"CONEXION|"\n        r"CONEXIÓN|"\n        r"DIAMETRO|"\n        r"DIÁMETRO|"\n        r"LONGITUD|"\n        r"LARGO|"\n        r"ANCHO|"\n        r"ALTO|"\n        r"ALTURA|"\n        r"ESPESOR|"\n        r"PROFUNDIDAD"\n        r")"\n        r"\\s*(?:\\.|-)\\s*(?=,|$)",\n        re.IGNORECASE,\n    )\n\n    for coincidencia in patron_campo_vacio.finditer(texto):\n\n        valor = coincidencia.group(0).strip()\n\n        if valor not in encontrados:\n\n            encontrados.append(valor)\n\n    return encontrados\n\n\n# ============================================================\n\n# DETECTAR MISSING UNITS\n\n# ============================================================\n\n\ndef detectar_missing_units(texto):\n\n    # --------------------------------------------------------\n    # Normalizar texto\n    # --------------------------------------------------------\n\n    texto_mayusculas = texto.upper()\n\n    # Corrige números escritos accidentalmente con espacio:\n    # 15. 24 M -> 15.24 M\n    # 15, 24 M -> 15.24 M\n    texto_mayusculas = re.sub(r"(\\d+)\\s*[.,]\\s*(\\d+)", r"\\1.\\2", texto_mayusculas)\n\n    errores = []\n\n    # --------------------------------------------------------\n    # CAMPOS DE DIMENSIONES EXPLÍCITOS\n    # --------------------------------------------------------\n\n    campos = [\n        "DIAMETRO",\n        "LONGITUD",\n        "LARGO",\n        "ANCHO",\n        "ALTO",\n        "ALTURA",\n        "PROFUNDIDAD",\n        "ESPESOR",\n    ]\n\n    # Número entero, decimal, fracción o fracción mixta\n    # Número entero, decimal, fracción, fracción mixta o fracción mixta con guion.\n    # Ejemplos: 4, 4.5, 1/2, 4 1/2, 4-1/2.\n    # La alternativa con guion debe evaluarse antes que el entero para\n    # evitar que "4-1/2\\"" se interprete solamente como "4".\n    numero = r"(?:\\d+\\s*-\\s*\\d+/\\d+|\\d+\\s+\\d+/\\d+|\\d+/\\d+|\\d+(?:[.,]\\d+)?)"\n\n    # Unidades aceptadas\n    # IMPORTANTE: aquí se incluye M\n    # Unidades abreviadas, símbolos y nombres completos.\n    unidades = (\n        r\'(?:MM2|MM|CM|M|MT|MTS|\'\n        r\'METROS?|MILIMETROS?|CENTIMETROS?|\'\n        r\'IN|PULG(?:ADA|ADAS)?|PULGADAS?|\'\n        r\'FT|PIE|PIES|")\'\n    )\n\n    for campo in campos:\n\n        patron = re.compile(rf"\\b{campo}\\s*(?:DE\\s*)?({numero})", re.IGNORECASE)\n\n        for coincidencia in patron.finditer(texto_mayusculas):\n\n            valor = coincidencia.group(1)\n\n            posicion_final = coincidencia.end()\n\n            # Texto inmediatamente después del número\n            siguiente = texto_mayusculas[posicion_final : posicion_final + 30]\n\n            # ------------------------------------------------\n            # CASO 1:\n            # El número tiene unidad inmediatamente después\n            #\n            # Ejemplos:\n            # DIAMETRO 3"\n            # LONGITUD 50 M\n            # LONGITUD 15.2 M\n            # LARGO 2 M\n            # ALTO 5.3 M\n            # ------------------------------------------------\n\n            # También acepta expresiones como 7/16 DE PULGADA.\n            if re.match(rf"\\s*(?:DE\\s+)?{unidades}(?=\\s|$|[,.;:)])", siguiente):\n                continue\n\n            # ------------------------------------------------\n            # CASO 2:\n            # Dimensiones encadenadas\n            #\n            # Ejemplo:\n            # ALTURA 61 X 121.9 CM\n            #\n            # Si después del primer número aparece X y\n            # posteriormente aparece una unidad, no marcar\n            # el primer número.\n            # ------------------------------------------------\n\n            siguiente_limpio = siguiente.strip()\n\n            if re.match(r"^X\\b", siguiente_limpio):\n\n                if re.search(rf"\\b{unidades}\\b", siguiente_limpio):\n                    continue\n\n            # ------------------------------------------------\n            # Si llegamos aquí, no encontramos unidad\n            # ------------------------------------------------\n\n            detalle = f"{campo}: {valor}"\n\n            if detalle not in errores:\n                errores.append(detalle)\n\n    # --------------------------------------------------------\n    # CLASE\n    # --------------------------------------------------------\n\n    patron_clase = re.compile(r"\\bCLASE\\s+(#?\\s*\\d+(?:\\s*/\\s*\\d+)?#?)", re.IGNORECASE)\n\n    for coincidencia in patron_clase.finditer(texto_mayusculas):\n\n        valor = coincidencia.group(1).strip()\n\n        siguiente = texto_mayusculas[coincidencia.end() : coincidencia.end() + 25]\n\n        # No marcar:\n        # CLASE I\n        # CLASE II\n        # CLASE III\n        # CLASE 1 DIV. 1&2\n        # etc.\n        if re.match(r"\\s*[,.\\-]?\\s*DIV\\b", siguiente):\n            continue\n\n        # Si tiene #, está correctamente especificada\n        if "#" in valor:\n            continue\n\n        detalle = f"CLASE: {valor}"\n\n        if detalle not in errores:\n            errores.append(detalle)\n\n    return errores\n\n\n'

_SOURCE_PLANTILLAS = 'import os\nimport re\nimport glob\nimport sqlite3\nimport unicodedata\nimport pandas as pd\n\n# ============================================================\n# CONFIGURACION\n# ============================================================\nBASE_DIR = os.path.dirname(os.path.abspath(__file__))\nDB_PATH = os.path.join(BASE_DIR, "base_datos.db")\n\n# Si el archivo RESULTADO_*.xlsx no esta en la carpeta del proyecto,\n# cambia esta ruta por la carpeta donde lo genera procesar_mensual.py.\nCARPETA_RESULTADOS = r"__WEB_ONLY__"\n\n# Si quieres forzar un archivo especifico, escribe su ruta aqui.\n# Ejemplo: ARCHIVO_ENTRADA = r"C:\\...\\RESULTADO_SEPTIEMBRE.xlsx"\nARCHIVO_ENTRADA = None\n\n# Solo analiza articulos marcados como NUEVO.\nSOLO_NUEVOS = True\n\n# ============================================================\n# NORMALIZACION\n# ============================================================\ndef normalizar(texto):\n    if pd.isna(texto):\n        return ""\n    texto = str(texto).upper().strip()\n    texto = unicodedata.normalize("NFD", texto)\n    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")\n    texto = texto.replace("Ø", " DIAMETRO ")\n    texto = re.sub(r"\\s+", " ", texto)\n    return texto\n\n\ndef codigo_2d(valor):\n    texto = str(valor).strip() if not pd.isna(valor) else ""\n    if re.fullmatch(r"\\d+(?:\\.0+)?", texto):\n        return f"{int(float(texto)):02d}"\n    return texto.zfill(2) if texto.isdigit() else texto\n\n\n# ============================================================\n# PATRONES GENERALES DE CAMPOS\n# ============================================================\n# Un campo solo se declara FALTANTE cuando existe una regla suficientemente\n# confiable. Si no hay regla, queda NO_EVALUABLE y no genera error.\nPATRONES = {\n    "DIAMETRO": [\n        r"\\bDIAMETRO\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n        r"\\b(?:DN|NPS)\\s*\\d",\n        r"\\b\\d+(?:\\s+\\d+/\\d+|/\\d+)?\\s*(?:\\"|PULG(?:ADA|ADAS)?|IN\\b|MM\\b|CM\\b)",\n    ],\n    "CEDULA": [\n        r"\\bCED(?:ULA)?\\.?\\s*\\d+[A-Z]?\\b",\n        r"\\bSCH\\.?\\s*\\d+[A-Z]?\\b",\n        r"\\bSCHEDULE\\s*\\d+[A-Z]?\\b",\n    ],\n    "ESPECIFICACION DE MATERIAL": [\n        r"\\bASTM\\s+[A-Z0-9\\-./]+",\n        r"\\bAPI\\s+[0-9A-Z\\-./]+",\n        r"\\bAISI\\s+[0-9A-Z\\-./]+",\n        r"\\bSAE\\s+[0-9A-Z\\-./]+",\n        r"\\bEN\\s+\\d{3,}",\n        r"\\bA[- ]?\\d{2,4}[A-Z]?\\b",\n    ],\n    "ESPECIFICACIÓN DE MATERIAL": [\n        r"\\bASTM\\s+[A-Z0-9\\-./]+",\n        r"\\bAPI\\s+[0-9A-Z\\-./]+",\n        r"\\bAISI\\s+[0-9A-Z\\-./]+",\n        r"\\bSAE\\s+[0-9A-Z\\-./]+",\n        r"\\bEN\\s+\\d{3,}",\n        r"\\bA[- ]?\\d{2,4}[A-Z]?\\b",\n    ],\n    "EXT": [\n        r"\\b(?:BISELAD[OA]S?|ROSCAD[OA]S?|RANURAD[OA]S?|BRIDAD[OA]S?|SOLDABLES?|BW|SW|NPT|BSP|FLANGEAD[OA]S?)\\b",\n    ],\n    "EXTREMO": [\n        r"\\b(?:BISELAD[OA]S?|ROSCAD[OA]S?|RANURAD[OA]S?|BRIDAD[OA]S?|SOLDABLES?|BW|SW|NPT|BSP|FLANGEAD[OA]S?)\\b",\n    ],\n    "EXTREMOS": [\n        r"\\b(?:BISELAD[OA]S?|ROSCAD[OA]S?|RANURAD[OA]S?|BRIDAD[OA]S?|SOLDABLES?|BW|SW|NPT|BSP|FLANGEAD[OA]S?)\\b",\n    ],\n    "CLASE": [\n        r"\\bCLASE\\s*#?\\s*\\d+\\b",\n        r"\\bCLASS\\s*#?\\s*\\d+\\b",\n        r"\\b\\d+\\s*(?:LB|LBS|#)\\b",\n    ],\n    "ESPESOR": [\n        r"\\bESPESOR(?:\\s+DE\\s+PARED)?\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n    ],\n    "ESPESOR DE PARED": [\n        r"\\bESPESOR(?:\\s+DE\\s+PARED)?\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n    ],\n    "LONGITUD": [\n        r"\\bLONGITUD\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n        r"\\bLARGO\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n    ],\n    "LARGO": [\n        r"\\bLARGO\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n        r"\\bLONGITUD\\s*(?:DE\\s*)?[:=]?\\s*\\d",\n    ],\n    "ANCHO": [r"\\bANCHO\\s*(?:DE\\s*)?[:=]?\\s*\\d"],\n    "ALTO": [r"\\b(?:ALTO|ALTURA)\\s*(?:DE\\s*)?[:=]?\\s*\\d"],\n    "ALTURA": [r"\\b(?:ALTO|ALTURA)\\s*(?:DE\\s*)?[:=]?\\s*\\d"],\n    "POTENCIA": [\n        r"\\bPOTENCIA\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*(?:HP|KW|W)\\b",\n    ],\n    "VOLTAJE": [\n        r"\\bVOLTAJE\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*V(?:AC|DC)?\\b",\n    ],\n    "PRESION": [\n        r"\\bPRESION(?:\\s+(?:MAXIMA|DE\\s+DISENO|DE\\s+OPERACION))?\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*(?:PSI|BAR|KPA|MPA)\\b",\n    ],\n    "PRESION DISEÑO": [\n        r"\\bPRESION(?:\\s+DE)?\\s+DISENO\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*(?:PSI|BAR|KPA|MPA)\\b",\n    ],\n    "PRESION MAXIMA": [\n        r"\\bPRESION\\s+MAXIMA\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*(?:PSI|BAR|KPA|MPA)\\b",\n    ],\n    "TEMPERATURA": [\n        r"\\bTEMPERATURA(?:\\s+(?:MAXIMA|MINIMA|DE\\s+OPERACION|DE\\s+DISENO))?\\s*[:=]?\\s*-?\\d",\n        r"-?\\d+(?:\\.\\d+)?\\s*°?\\s*[CF]\\b",\n    ],\n    "TEMPERATURA DE OPERACIÓN": [\n        r"\\bTEMPERATURA(?:\\s+DE)?\\s+OPERACION\\s*[:=]?\\s*-?\\d",\n        r"-?\\d+(?:\\.\\d+)?\\s*°?\\s*[CF]\\b",\n    ],\n    "TEMPERATURA DE DISEÑO": [\n        r"\\bTEMPERATURA(?:\\s+DE)?\\s+DISENO\\s*[:=]?\\s*-?\\d",\n        r"-?\\d+(?:\\.\\d+)?\\s*°?\\s*[CF]\\b",\n    ],\n    "DENSIDAD": [\n        r"\\bDENSIDAD\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*(?:G/CM3|KG/M3|KG/L)\\b",\n    ],\n    "CALIBRE": [\n        r"\\bCALIBRE\\s*[:=]?\\s*[0-9A-Z]+",\n        r"\\b(?:AWG|CAL)\\s*\\d+\\b",\n    ],\n    "CAPACIDAD": [\n        r"\\bCAPACIDAD\\s*[:=]?\\s*\\d",\n    ],\n    "MODELO": [r"\\bMODELO\\s*[:=]?\\s*[A-Z0-9]"],\n    "FABRICANTE": [r"\\bFABRICANTE\\s*[:=]?\\s*[A-Z0-9]"],\n    "MARCA": [r"\\bMARCA\\s*[:=]?\\s*[A-Z0-9]"],\n    "COLOR": [r"\\bCOLOR\\s*[:=]?\\s*[A-Z]"],\n    "SERVICIO": [r"\\bSERVICIO\\s*[:=]?\\s*[A-Z0-9]"],\n    "GRADO PUREZA": [\n        r"\\bGRADO\\s+(?:DE\\s+)?PUREZA\\s*[:=]?\\s*[A-Z0-9]",\n        r"\\bPUREZA\\s*[:=]?\\s*\\d+(?:\\.\\d+)?\\s*%",\n    ],\n    "NORMATIVA": [\n        r"\\b(?:ASTM|API|ASME|ANSI|ISO|DIN|NOM|NMX|NFPA|UL|FM)\\s*[A-Z0-9\\-./]*",\n    ],\n    "DIMENSIONES": [\n        r"\\bDIMENSIONES\\s*[:=]?\\s*\\d",\n        r"\\b\\d+(?:\\.\\d+)?\\s*[Xx]\\s*\\d+(?:\\.\\d+)?(?:\\s*[Xx]\\s*\\d+(?:\\.\\d+)?)?\\s*(?:MM|CM|M|IN|\\")?",\n    ],\n    "MATERIAL": [\n        r"\\bMATERIAL\\s*[:=]?\\s*[A-Z0-9]",\n        r"\\b(?:ACERO(?:\\s+AL\\s+CARBON|\\s+INOXIDABLE)?|INOXIDABLE|PVC|CPVC|HDPE|PEAD|POLIETILENO|POLIPROPILENO|PTFE|TEFLON|LATON|BRONCE|ALUMINIO|HIERRO(?:\\s+FUNDIDO)?|NITRILO|EPDM|NEOPRENO|VITON|POLIURETANO|COBRE|CAUCHO|HULE)\\b",\n    ],\n}\n\n# Alias para nombres equivalentes que aparecen en las plantillas.\nALIAS_CAMPO = {\n    "DIAMETRO2": "DIAMETRO",\n    "EXTREMO2": "EXTREMO",\n    "PRESION DE DISEÑO": "PRESION DISEÑO",\n    "PRESION DE DISENO": "PRESION DISEÑO",\n    "TEMPERATURA DE OPERACION": "TEMPERATURA DE OPERACIÓN",\n    "TEMPERATURA DE DISENO": "TEMPERATURA DE DISEÑO",\n    "ESPECIFICACION DE MATERIAL": "ESPECIFICACION DE MATERIAL",\n    "ESPECIFICACIÓN DE MATERIAL": "ESPECIFICACION DE MATERIAL",\n}\n\n\ndef clave_patron(campo):\n    c = normalizar(campo)\n    # restauramos claves canonicas sin acentos porque normalizar los quita\n    equivalencias = {\n        "ESPECIFICACION DE MATERIAL": "ESPECIFICACION DE MATERIAL",\n        "PRESION DISENO": "PRESION DISEÑO",\n        "PRESION DE DISENO": "PRESION DISEÑO",\n        "TEMPERATURA DE OPERACION": "TEMPERATURA DE OPERACIÓN",\n        "TEMPERATURA DE DISENO": "TEMPERATURA DE DISEÑO",\n    }\n    c = equivalencias.get(c, c)\n    return ALIAS_CAMPO.get(c, c)\n\n\ndef detectar_campo(campo, descripcion):\n    clave = clave_patron(campo)\n    texto = normalizar(descripcion)\n\n    # Caso especial: campos numerados usan la misma logica base.\n    clave_base = re.sub(r"\\d+$", "", clave).strip()\n    if clave not in PATRONES and clave_base in PATRONES:\n        clave = clave_base\n\n    patrones = PATRONES.get(clave)\n    if not patrones:\n        # Si el propio nombre del campo aparece escrito y trae un valor despues,\n        # podemos considerarlo detectado sin conocer la semantica del campo.\n        etiqueta = normalizar(campo)\n        m = re.search(rf"\\b{re.escape(etiqueta)}\\b\\s*[:=,-]?\\s*([A-Z0-9])", texto)\n        if m:\n            return "DETECTADO", f"El campo {campo} aparece explicitamente con valor"\n        return "NO_EVALUABLE", "Sin regla automatica suficientemente confiable"\n\n    for patron in patrones:\n        if re.search(patron, texto, re.IGNORECASE):\n            return "DETECTADO", f"Coincide con patron de {campo}"\n\n    return "FALTANTE", f"No se encontro evidencia suficiente de {campo}"\n\n\n# ============================================================\n# LLENADO INADECUADO DE PLANTILLA\n# ============================================================\n# N/A, NA y NO APLICA pertenecen a ORTOGRAFIA /\n# USO INCORRECTO DE CARACTERES. Plantillas no debe apropiarse\n# de esos casos como LLENADO INADECUADO.\nVALORES_INVALIDOS = {"-", "."}\n\n\ndef detectar_campo_mal_llenado(descripcion, campos_plantilla):\n    """\n    Detecta casos fuertes donde el nombre de un campo aparece en la descripcion\n    pero no tiene valor, tiene un valor invalido o inmediatamente aparece otro\n    nombre de campo.\n    """\n    texto = normalizar(descripcion)\n    nombres = [normalizar(c) for c in campos_plantilla if c]\n    nombres = sorted(set(nombres), key=len, reverse=True)\n    errores = []\n\n    if not texto or not nombres:\n        return errores\n\n    # Construimos una expresion con nombres de campos conocidos de ESA plantilla.\n    alternancia = "|".join(re.escape(n) for n in nombres if len(n) >= 3)\n    if not alternancia:\n        return errores\n\n    for campo in nombres:\n        # Solo revisamos si la etiqueta del campo aparece literalmente.\n        patron = re.compile(rf"\\b{re.escape(campo)}\\b", re.IGNORECASE)\n        for m in patron.finditer(texto):\n            # Si la etiqueta funciona como unidad y viene precedida por una\n            # cantidad (ej. 75 GRAMOS), la cantidad es el valor del campo.\n            antes = texto[:m.start()].rstrip()\n            if re.search(r"(?:^|[ ,;:(])\\d+(?:[.,]\\d+)?(?:\\s+\\d+/\\d+|/\\d+)?\\s*$", antes):\n                continue\n\n            despues = texto[m.end():].lstrip(" :,-.;")\n\n            if not despues:\n                errores.append(f"{campo}: sin valor")\n                continue\n\n            # Otro campo inmediatamente después puede indicar campo vacío,\n            # pero TIPO suele formar parte natural del valor anterior:\n            # EMPAQUE TIPO O-RING, CONEXION TIPO NPT, etc.\n            otro = re.match(rf"(?:{alternancia})\\b", despues, re.IGNORECASE)\n            if otro:\n                otro_campo = normalizar(otro.group(0))\n                if otro_campo != campo and otro_campo != "TIPO":\n                    errores.append(f"{campo}: seguido por otro campo ({otro.group(0)})")\n                    continue\n\n            primer_fragmento = re.split(r"[,;]", despues, maxsplit=1)[0].strip()\n            if primer_fragmento in VALORES_INVALIDOS:\n                errores.append(f"{campo}: valor invalido ({primer_fragmento})")\n\n    # quitar duplicados manteniendo orden\n    vistos = set()\n    salida = []\n    for e in errores:\n        if e not in vistos:\n            vistos.add(e)\n            salida.append(e)\n    return salida\n\n\n# ============================================================\n# ENTRADA / BASE DE DATOS\n# ============================================================\ndef localizar_archivo_entrada():\n    if ARCHIVO_ENTRADA:\n        if not os.path.exists(ARCHIVO_ENTRADA):\n            raise FileNotFoundError(f"No existe ARCHIVO_ENTRADA:\\n{ARCHIVO_ENTRADA}")\n        return ARCHIVO_ENTRADA\n\n    patrones = [\n        os.path.join(CARPETA_RESULTADOS, "RESULTADO_*.xlsx"),\n        os.path.join(BASE_DIR, "RESULTADO_*.xlsx"),\n    ]\n    candidatos = []\n    for patron in patrones:\n        candidatos.extend(glob.glob(patron))\n\n    candidatos = [p for p in candidatos if not os.path.basename(p).startswith("~$")]\n    if not candidatos:\n        raise FileNotFoundError(\n            "No encontre ningun archivo RESULTADO_*.xlsx.\\n"\n            "Configura ARCHIVO_ENTRADA al inicio del script."\n        )\n\n    return max(candidatos, key=os.path.getmtime)\n\n\ndef cargar_plantillas(conn):\n    catalogo = pd.read_sql_query("""\n        SELECT grupo, subgrupo, nombre_grupo, nombre_subgrupo, um\n        FROM catalogo_subgrupos\n    """, conn)\n\n    campos = pd.read_sql_query("""\n        SELECT grupo, subgrupo, orden, elemento, tipo_elemento, obligatorio\n        FROM campos_plantilla\n        ORDER BY grupo, subgrupo, orden\n    """, conn)\n\n    for df in (catalogo, campos):\n        df["grupo"] = df["grupo"].astype(str).str.zfill(2)\n        df["subgrupo"] = df["subgrupo"].astype(str).str.zfill(2)\n\n    return catalogo, campos\n\n\n# ============================================================\n# ANALISIS\n# ============================================================\ndef analizar():\n    if not os.path.exists(DB_PATH):\n        raise FileNotFoundError(f"No existe la base de datos:\\n{DB_PATH}")\n\n    entrada = localizar_archivo_entrada()\n    print("=" * 72)\n    print("DIAGNOSTICO DE PLANTILLAS")\n    print("=" * 72)\n    print(f"Entrada: {entrada}")\n    print(f"Base de datos: {DB_PATH}")\n    print()\n\n    df = pd.read_excel(entrada, dtype=str, engine="openpyxl")\n    df.columns = [str(c).strip() for c in df.columns]\n\n    # Resolver nombres de columnas tolerando mayusculas/acentos.\n    mapa = {normalizar(c): c for c in df.columns}\n    requeridas = ["CODIGO", "GRUPO", "SUBGRUPO", "DESCRIPCION"]\n    faltan = [c for c in requeridas if c not in mapa]\n    if faltan:\n        raise ValueError("Faltan columnas en el archivo de entrada: " + ", ".join(faltan))\n\n    col_codigo = mapa["CODIGO"]\n    col_grupo = mapa["GRUPO"]\n    col_subgrupo = mapa["SUBGRUPO"]\n    col_desc = mapa["DESCRIPCION"]\n    col_estado = mapa.get("ESTADO")\n\n    if SOLO_NUEVOS and col_estado:\n        df = df[df[col_estado].fillna("").astype(str).str.upper().str.strip() == "NUEVO"].copy()\n\n    conn = sqlite3.connect(DB_PATH)\n    try:\n        catalogo, campos = cargar_plantillas(conn)\n    finally:\n        conn.close()\n\n    catalogo_idx = catalogo.set_index(["grupo", "subgrupo"])\n    grupos_campos = {\n        k: g.copy() for k, g in campos.groupby(["grupo", "subgrupo"], sort=False)\n    }\n\n    resultados = []\n    detalles = []\n\n    cont_sub = 0\n    cont_llenado = 0\n    cont_ok = 0\n    cont_sin_plantilla = 0\n    cont_revisar = 0\n\n    for _, fila in df.iterrows():\n        codigo = str(fila[col_codigo]).strip()\n        grupo = codigo_2d(fila[col_grupo])\n        subgrupo = codigo_2d(fila[col_subgrupo])\n        descripcion = str(fila[col_desc]) if not pd.isna(fila[col_desc]) else ""\n        clave = (grupo, subgrupo)\n\n        if clave not in catalogo_idx.index or clave not in grupos_campos:\n            cont_sin_plantilla += 1\n            resultados.append({\n                "Codigo": codigo,\n                "Grupo": grupo,\n                "Subgrupo": subgrupo,\n                "Descripcion": descripcion,\n                "Nombre Subgrupo": "",\n                "Campos obligatorios": "",\n                "Obligatorios detectados": "",\n                "Obligatorios faltantes": "",\n                "Obligatorios no evaluables": "",\n                "Errores de llenado": "",\n                "OBSERVACION PROPUESTA": "REVISAR",\n                "SUBOBSERVACION PROPUESTA": "SIN PLANTILLA EN CATALOGO",\n                "Detalle": "No se encontro plantilla para este grupo/subgrupo",\n            })\n            continue\n\n        info = catalogo_idx.loc[clave]\n        gcampos = grupos_campos[clave]\n        campos_reales = gcampos[gcampos["tipo_elemento"] == "CAMPO"]["elemento"].tolist()\n        obligatorios = gcampos[\n            (gcampos["tipo_elemento"] == "CAMPO") & (gcampos["obligatorio"] == 1)\n        ]["elemento"].tolist()\n\n        detectados = []\n        faltantes = []\n        no_evaluables = []\n\n        for campo in obligatorios:\n            estado, motivo = detectar_campo(campo, descripcion)\n            detalles.append({\n                "Codigo": codigo,\n                "Grupo": grupo,\n                "Subgrupo": subgrupo,\n                "Campo obligatorio": campo,\n                "Estado": estado,\n                "Motivo": motivo,\n            })\n            if estado == "DETECTADO":\n                detectados.append(campo)\n            elif estado == "FALTANTE":\n                faltantes.append(campo)\n            else:\n                no_evaluables.append(campo)\n\n        errores_llenado = detectar_campo_mal_llenado(descripcion, campos_reales)\n\n        # Priorizacion: un llenado claramente incorrecto es mas especifico.\n        if errores_llenado:\n            observacion = "ESPECIFICACION TECNICA"\n            subobservacion = "LLENADO INADECUADO DE PLANTILLA"\n            detalle_final = "; ".join(errores_llenado)\n            cont_llenado += 1\n        elif faltantes or no_evaluables:\n            # SUB-ESPECIFICADO queda desactivado por decisión de negocio.\n            # La ausencia automática de un campo obligatorio no genera\n            # observación ni REVISAR. Solo se conserva como información\n            # diagnóstica interna.\n            observacion = "OK"\n            subobservacion = "OK"\n            partes = []\n            if faltantes:\n                partes.append(\n                    "Campos sin evidencia ignorados por regla de negocio: "\n                    + ", ".join(faltantes)\n                )\n            if no_evaluables:\n                partes.append(\n                    "Campos no evaluables ignorados: "\n                    + ", ".join(no_evaluables)\n                )\n            detalle_final = "; ".join(partes) or "Sin error automatico"\n            cont_ok += 1\n        else:\n            observacion = "OK"\n            subobservacion = "OK"\n            detalle_final = "Todos los campos obligatorios evaluables fueron detectados"\n            cont_ok += 1\n\n        resultados.append({\n            "Codigo": codigo,\n            "Grupo": grupo,\n            "Subgrupo": subgrupo,\n            "Descripcion": descripcion,\n            "Nombre Subgrupo": info["nombre_subgrupo"],\n            "Campos obligatorios": ", ".join(obligatorios),\n            "Obligatorios detectados": ", ".join(detectados),\n            "Obligatorios faltantes": ", ".join(faltantes),\n            "Obligatorios no evaluables": ", ".join(no_evaluables),\n            "Errores de llenado": "; ".join(errores_llenado),\n            "OBSERVACION PROPUESTA": observacion,\n            "SUBOBSERVACION PROPUESTA": subobservacion,\n            "Detalle": detalle_final,\n        })\n\n    res = pd.DataFrame(resultados)\n    det = pd.DataFrame(detalles)\n\n    nombre_base = os.path.splitext(os.path.basename(entrada))[0]\n    sufijo = nombre_base.replace("RESULTADO_", "")\n    salida = os.path.join(os.path.dirname(entrada), f"DIAGNOSTICO_PLANTILLAS_{sufijo}.xlsx")\n\n    resumen = pd.DataFrame([\n        ["Articulos analizados", len(res)],\n        ["SUB-ESPECIFICADO (DESACTIVADO)", 0],\n        ["LLENADO INADECUADO DE PLANTILLA", cont_llenado],\n        ["REVISAR - campos no evaluables", cont_revisar],\n        ["Sin plantilla en catalogo", cont_sin_plantilla],\n        ["OK", cont_ok],\n    ], columns=["Indicador", "Cantidad"])\n\n    with pd.ExcelWriter(salida, engine="openpyxl") as writer:\n        resumen.to_excel(writer, index=False, sheet_name="RESUMEN")\n        res.to_excel(writer, index=False, sheet_name="DIAGNOSTICO")\n        det.to_excel(writer, index=False, sheet_name="DETALLE_CAMPOS")\n\n        for nombre_hoja in writer.book.sheetnames:\n            ws = writer.book[nombre_hoja]\n            ws.freeze_panes = "A2"\n            ws.auto_filter.ref = ws.dimensions\n            for col in ws.columns:\n                letra = col[0].column_letter\n                ancho = 0\n                for celda in col[:200]:\n                    valor = "" if celda.value is None else str(celda.value)\n                    ancho = max(ancho, min(len(valor) + 2, 60))\n                ws.column_dimensions[letra].width = max(ancho, 12)\n\n    print("Diagnostico terminado correctamente.")\n    print("-" * 72)\n    print(f"Articulos analizados:                  {len(res)}")\n    print(f"SUB-ESPECIFICADO:                     {cont_sub}")\n    print(f"LLENADO INADECUADO DE PLANTILLA:      {cont_llenado}")\n    print(f"REVISAR - campos no evaluables:        {cont_revisar}")\n    print(f"Sin plantilla en catalogo:             {cont_sin_plantilla}")\n    print(f"OK:                                    {cont_ok}")\n    print()\n    print(f"Archivo generado:\\n{salida}")\n    print("=" * 72)\n\n\nif __name__ == "__main__":\n    analizar()\n'

_SOURCE_DUPLICADOS = 'import os\nimport re\nimport glob\nimport unicodedata\nfrom difflib import SequenceMatcher\nfrom collections import defaultdict\n\nimport pandas as pd\n\n# ============================================================\n# CONFIGURACION\n# ============================================================\n\nREVISIONES_DIR = r"__WEB_ONLY__"\n\n# Umbrales deliberadamente conservadores para reducir falsos positivos.\nUMBRAL_MISMO_GRUPO_SUBGRUPO = 0.90\n\nPALABRAS_POCO_INFORMATIVAS = {\n    "DE", "DEL", "LA", "LAS", "EL", "LOS", "PARA", "CON", "SIN",\n    "TIPO", "MODELO", "MARCA", "NO", "NUMERO", "NUM", "Y"\n}\n\n# ============================================================\n# UTILIDADES\n# ============================================================\n\ndef quitar_acentos(texto):\n    texto = "" if pd.isna(texto) else str(texto)\n    return "".join(\n        c for c in unicodedata.normalize("NFD", texto)\n        if unicodedata.category(c) != "Mn"\n    )\n\ndef normalizar_codigo(valor):\n    if pd.isna(valor):\n        return ""\n    texto = str(valor).strip()\n    if texto.endswith(".0"):\n        texto = texto[:-2]\n    return texto\n\ndef normalizar_clave(valor):\n    """Normaliza grupo/subgrupo sin destruir ceros iniciales si ya existen."""\n    if pd.isna(valor):\n        return ""\n    texto = str(valor).strip()\n    if texto.endswith(".0"):\n        texto = texto[:-2]\n    return texto\n\ndef normalizar_descripcion(texto):\n    texto = quitar_acentos(texto).upper()\n\n    # Unificar variantes frecuentes.\n    reemplazos = {\n        " PULGADAS ": \' " \',\n        " PULGADA ": \' " \',\n        " PULG ": \' " \',\n        " INCH ": \' " \',\n        " SCH ": " CEDULA ",\n        " CED ": " CEDULA ",\n        " ACERO AL CARBONO ": " ACERO AL CARBON ",\n    }\n\n    texto = f" {texto} "\n    for origen, destino in reemplazos.items():\n        texto = texto.replace(origen, destino)\n\n    # Mantener letras, números y símbolos técnicos relevantes.\n    texto = re.sub(r"[^A-Z0-9/#.%+\\-\\" ]+", " ", texto)\n    texto = re.sub(r"\\s+", " ", texto).strip()\n\n    return texto\n\ndef tokens_informativos(texto_normalizado):\n    tokens = re.findall(r\'[A-Z0-9]+(?:/[A-Z0-9]+)?|(?:\\d+(?:\\.\\d+)?)|["#%]\', texto_normalizado)\n    return [\n        t for t in tokens\n        if t not in PALABRAS_POCO_INFORMATIVAS and len(t) > 1\n    ]\n\ndef firma_numerica(texto_normalizado):\n    """\n    Extrae números para evitar comparar como duplicados artículos muy parecidos\n    pero con medidas/capacidades diferentes.\n    """\n    numeros = re.findall(r\'\\d+(?:\\.\\d+)?(?:/\\d+)?\', texto_normalizado)\n    return tuple(numeros)\n\ndef jaccard_tokens(a, b):\n    sa = set(tokens_informativos(a))\n    sb = set(tokens_informativos(b))\n\n    if not sa and not sb:\n        return 1.0\n    if not sa or not sb:\n        return 0.0\n\n    return len(sa & sb) / len(sa | sb)\n\ndef similitud_secuencia(a, b):\n    return SequenceMatcher(None, a, b).ratio()\n\ndef similitud_total(a, b):\n    """\n    Combina similitud de secuencia y coincidencia de palabras.\n    Da mayor peso a la estructura completa.\n    """\n    sec = similitud_secuencia(a, b)\n    jac = jaccard_tokens(a, b)\n    return 0.65 * sec + 0.35 * jac\n\ndef numeros_compatibles(a, b):\n    """\n    Si ambas descripciones contienen números, exige coincidencia fuerte.\n    Esto evita marcar, por ejemplo, una válvula de 1" como duplicado de una de 2".\n    """\n    na = firma_numerica(a)\n    nb = firma_numerica(b)\n\n    if not na or not nb:\n        return True\n\n    return na == nb\n\ndef extraer_atributo(texto_normalizado, nombres):\n    """\n    Extrae el valor que aparece después de una etiqueta como TALLA o COLOR.\n    Ejemplos:\n      TALLA M\n      TALL L\n      COLOR AZUL MARINO\n\n    El valor se corta al encontrar coma implícita normalizada, otra etiqueta\n    conocida o después de un máximo razonable de palabras.\n    """\n    etiquetas_fin = {\n        "TALLA", "TALL", "COLOR", "MARCA", "MODELO", "MATERIAL",\n        "TIPO", "MEDIDA", "TAMANO", "TAMAÑO", "GENERO", "SEXO",\n        "PRESENTACION", "CAPACIDAD"\n    }\n\n    palabras = texto_normalizado.split()\n\n    for i, palabra in enumerate(palabras):\n        if palabra in nombres:\n            valores = []\n\n            for siguiente in palabras[i + 1:i + 5]:\n                if siguiente in etiquetas_fin:\n                    break\n                valores.append(siguiente)\n\n            if valores:\n                return " ".join(valores).strip()\n\n    return ""\n\n\ndef extraer_modelo(texto_normalizado):\n    """Extrae un modelo explícito; un modelo distinto define una variante."""\n    m = re.search(r"\\bMODELO\\s+([A-Z0-9][A-Z0-9./#%+\\-]*)", texto_normalizado)\n    return m.group(1) if m else ""\n\n\ndef extraer_tipo_caja_registro(texto_normalizado):\n    """\n    Reconoce el tipo constructivo escrito después de CAJA REGISTRO.\n    Ej.: CAJA REGISTRO L DIAMETRO... / T / C.\n    """\n    m = re.search(\n        r"\\bCAJA\\s+REGISTRO\\s+([A-Z]{1,3})\\s+(?:DIAMETRO|MEDIDA|TAMANO|TAMAÑO)\\b",\n        texto_normalizado,\n    )\n    return m.group(1) if m else ""\n\n\ndef atributos_variantes_compatibles(a, b):\n    """\n    Atributos técnicos distintos convierten artículos en variantes.\n    Se conserva el criterio ya validado de TALLA/COLOR y se añaden\n    MODELO y el tipo constructivo explícito de CAJA REGISTRO.\n    """\n    talla_a = extraer_atributo(a, {"TALLA", "TALL"})\n    talla_b = extraer_atributo(b, {"TALLA", "TALL"})\n    if talla_a and talla_b and talla_a != talla_b:\n        return False\n\n    color_a = extraer_atributo(a, {"COLOR"})\n    color_b = extraer_atributo(b, {"COLOR"})\n    if color_a and color_b and color_a != color_b:\n        return False\n\n    modelo_a = extraer_modelo(a)\n    modelo_b = extraer_modelo(b)\n    if modelo_a and modelo_b and modelo_a != modelo_b:\n        return False\n\n    tipo_a = extraer_tipo_caja_registro(a)\n    tipo_b = extraer_tipo_caja_registro(b)\n    if tipo_a and tipo_b and tipo_a != tipo_b:\n        return False\n\n    return True\n\ndef buscar_archivo_resultado():\n    patron = os.path.join(REVISIONES_DIR, "RESULTADO_*.xlsx")\n    archivos = glob.glob(patron)\n\n    if not archivos:\n        raise FileNotFoundError(\n            f"No se encontro ningun archivo RESULTADO_*.xlsx en:\\n{REVISIONES_DIR}"\n        )\n\n    # Evitar tomar un diagnóstico como entrada, por seguridad.\n    archivos = [\n        a for a in archivos\n        if "DIAGNOSTICO_" not in os.path.basename(a).upper()\n    ]\n\n    if not archivos:\n        raise FileNotFoundError("No se encontro un RESULTADO_*.xlsx valido.")\n\n    return max(archivos, key=os.path.getmtime)\n\ndef nombre_salida(archivo_entrada):\n    base = os.path.basename(archivo_entrada)\n    periodo = os.path.splitext(base)[0].replace("RESULTADO_", "")\n    return os.path.join(\n        REVISIONES_DIR,\n        f"DIAGNOSTICO_DUPLICADOS_{periodo}.xlsx"\n    )\n\n# ============================================================\n# DETECCION\n# ============================================================\n\ndef detectar_duplicados(df):\n    df = df.copy()\n\n    # Detectar columnas tolerando acentos y mayúsculas.\n    mapa = {}\n    for col in df.columns:\n        clave = quitar_acentos(col).upper().strip()\n        mapa[clave] = col\n\n    requeridas = ["CODIGO", "ESTADO", "GRUPO", "SUBGRUPO", "DESCRIPCION"]\n    faltantes = [c for c in requeridas if c not in mapa]\n\n    if faltantes:\n        raise ValueError(\n            "Faltan columnas requeridas en el archivo: "\n            + ", ".join(faltantes)\n        )\n\n    c_codigo = mapa["CODIGO"]\n    c_estado = mapa["ESTADO"]\n    c_grupo = mapa["GRUPO"]\n    c_subgrupo = mapa["SUBGRUPO"]\n    c_desc = mapa["DESCRIPCION"]\n\n    nuevos = df[\n        df[c_estado].astype(str).str.strip().str.upper().eq("NUEVO")\n    ].copy()\n\n    nuevos["_codigo"] = nuevos[c_codigo].apply(normalizar_codigo)\n    nuevos["_grupo"] = nuevos[c_grupo].apply(normalizar_clave)\n    nuevos["_subgrupo"] = nuevos[c_subgrupo].apply(normalizar_clave)\n    nuevos["_desc_norm"] = nuevos[c_desc].apply(normalizar_descripcion)\n\n    # Preparar grupos de comparación.\n    por_grupo_subgrupo = defaultdict(list)\n\n    for idx, fila in nuevos.iterrows():\n        por_grupo_subgrupo[(fila["_grupo"], fila["_subgrupo"])].append(idx)\n\n    candidatos = []\n\n    # -------------------------------\n    # 1) Mismo grupo + mismo subgrupo\n    # -------------------------------\n    for clave, indices in por_grupo_subgrupo.items():\n        for i_pos in range(len(indices)):\n            for j_pos in range(i_pos + 1, len(indices)):\n                i = indices[i_pos]\n                j = indices[j_pos]\n                a = nuevos.at[i, "_desc_norm"]\n                b = nuevos.at[j, "_desc_norm"]\n\n                if not a or not b:\n                    continue\n\n                exacto = a == b\n                score = 1.0 if exacto else similitud_total(a, b)\n\n                if not exacto:\n                    if score < UMBRAL_MISMO_GRUPO_SUBGRUPO:\n                        continue\n                    if not numeros_compatibles(a, b):\n                        continue\n\n                # TALLA y COLOR distintos convierten los artículos en variantes,\n                # no en duplicados, aunque el resto de la descripción coincida.\n                if not atributos_variantes_compatibles(a, b):\n                    continue\n\n                candidatos.append({\n                    "idx_a": i,\n                    "idx_b": j,\n                    "tipo": "MISMO GRUPO Y SUBGRUPO",\n                    "similitud": score,\n                    "exacto": exacto,\n                })\n\n    # Para cada artículo, conservar la mejor coincidencia.\n    mejor_por_idx = {}\n\n    for cand in candidatos:\n        i = cand["idx_a"]\n        j = cand["idx_b"]\n\n        for origen, otro in [(i, j), (j, i)]:\n            actual = mejor_por_idx.get(origen)\n            if actual is None or cand["similitud"] > actual["similitud"]:\n                mejor_por_idx[origen] = {\n                    **cand,\n                    "otro_idx": otro,\n                }\n\n    filas_salida = []\n\n    for idx, fila in nuevos.iterrows():\n        mejor = mejor_por_idx.get(idx)\n\n        if mejor is None:\n            filas_salida.append({\n                "Codigo": fila["_codigo"],\n                "Grupo": fila["_grupo"],\n                "Subgrupo": fila["_subgrupo"],\n                "Descripción": fila[c_desc],\n                "Observación propuesta": "OK",\n                "Subobservación propuesta": "OK",\n                "Código duplicado": "",\n                "Descripción duplicada": "",\n                "Tipo de coincidencia": "",\n                "Similitud %": "",\n                "Detalle": "",\n            })\n            continue\n\n        otro = nuevos.loc[mejor["otro_idx"]]\n        porcentaje = round(mejor["similitud"] * 100, 1)\n\n        if mejor["exacto"]:\n            detalle = "Descripción normalizada idéntica a otro artículo NUEVO del mismo Grupo/Subgrupo."\n        else:\n            detalle = "Descripción muy similar a otro artículo NUEVO del mismo Grupo/Subgrupo."\n\n        filas_salida.append({\n            "Codigo": fila["_codigo"],\n            "Grupo": fila["_grupo"],\n            "Subgrupo": fila["_subgrupo"],\n            "Descripción": fila[c_desc],\n            "Observación propuesta": "DUPLICADO",\n            "Subobservación propuesta": "ARTICULO DUPLICADO",\n            "Código duplicado": otro["_codigo"],\n            "Descripción duplicada": otro[c_desc],\n            "Tipo de coincidencia": mejor["tipo"],\n            "Similitud %": porcentaje,\n            "Detalle": detalle,\n        })\n\n    resultado = pd.DataFrame(filas_salida)\n\n    # Hoja separada solo con casos detectados.\n    duplicados = resultado[\n        resultado["Observación propuesta"].eq("DUPLICADO")\n    ].copy()\n\n    return resultado, duplicados, len(nuevos), len(candidatos)\n\n# ============================================================\n# MAIN\n# ============================================================\n\ndef main():\n    print("=" * 72)\n    print("DIAGNOSTICO DE DUPLICADOS - SOLO ARTICULOS DEL MES")\n    print("=" * 72)\n\n    entrada = buscar_archivo_resultado()\n    salida = nombre_salida(entrada)\n\n    print(f"Entrada: {entrada}")\n    print()\n    print("Criterio:")\n    print("- Solo se comparan articulos con Estado = NUEVO.")\n    print("- NO se comparan contra articulos historicos.")\n    print("- Solo se comparan artículos del mismo Grupo + mismo Subgrupo.")\n    print("- Si el Subgrupo es diferente, NO entra en el análisis de DUPLICADOS.")\n    print("- TALLA o COLOR diferentes se consideran variantes, NO duplicados.")\n    print()\n\n    df = pd.read_excel(\n        entrada,\n        dtype=str,\n        engine="openpyxl"\n    )\n\n    resultado, duplicados, total_nuevos, total_pares = detectar_duplicados(df)\n\n    resumen = pd.DataFrame([\n        ["Articulos NUEVO analizados", total_nuevos],\n        ["Articulos marcados como DUPLICADO", len(duplicados)],\n        ["Articulos sin duplicado fuerte", total_nuevos - len(duplicados)],\n        ["Pares candidatos detectados", total_pares],\n        ["Umbral mismo Grupo/Subgrupo", f"{UMBRAL_MISMO_GRUPO_SUBGRUPO * 100:.0f}%"],\n    ], columns=["Concepto", "Resultado"])\n\n    with pd.ExcelWriter(salida, engine="openpyxl") as writer:\n        resumen.to_excel(writer, sheet_name="RESUMEN", index=False)\n        duplicados.to_excel(writer, sheet_name="DUPLICADOS", index=False)\n        resultado.to_excel(writer, sheet_name="DIAGNOSTICO", index=False)\n\n        # Ajustes visuales básicos.\n        for hoja in writer.book.worksheets:\n            hoja.freeze_panes = "A2"\n            hoja.auto_filter.ref = hoja.dimensions\n\n            for columna in hoja.columns:\n                letra = columna[0].column_letter\n                max_len = 0\n\n                for celda in columna:\n                    valor = "" if celda.value is None else str(celda.value)\n                    max_len = max(max_len, min(len(valor), 80))\n\n                hoja.column_dimensions[letra].width = max(12, min(max_len + 2, 60))\n\n    print("Diagnostico terminado correctamente.")\n    print("-" * 72)\n    print(f"Articulos NUEVO analizados:         {total_nuevos}")\n    print(f"Articulos marcados DUPLICADO:       {len(duplicados)}")\n    print(f"Sin duplicado fuerte:               {total_nuevos - len(duplicados)}")\n    print(f"Pares candidatos detectados:        {total_pares}")\n    print()\n    print("Archivo generado:")\n    print(salida)\n    print("=" * 72)\n\n\nif __name__ == "__main__":\n    main()\n'

_SOURCE_REDACCION = 'import os\nimport re\nimport glob\nimport sqlite3\nimport unicodedata\n\nimport pandas as pd\n\n\n# ============================================================\n# CONFIGURACION\n# ============================================================\n\nREVISIONES_DIR = (\n    r"__WEB_ONLY__"\n)\n\nBASE_DIR = os.path.dirname(os.path.abspath(__file__))\nDB_PATH = os.path.join(BASE_DIR, "base_datos.db")\n\n\n# ============================================================\n# CORRECCIONES HISTORICAS VALIDADAS\n# Julio + Agosto\n# ============================================================\n#\n# Se guardan en SQLite para que en el futuro puedan ampliarse\n# sin modificar la lógica principal del programa.\n#\n\nCORRECCIONES_INICIALES = {\n    "CONECOR": "CONECTOR",\n    "COCENTRICA": "CONCENTRICA",\n    "CABRON": "CARBON",\n    "ALUMINO": "ALUMINIO",\n    "LUQUIDOS": "LIQUIDOS",\n    "FLEXBLE": "FLEXIBLE",\n    "MAGUERA": "MANGUERA",\n    "SERVIVIO": "SERVICIO",\n    "REDUCIION": "REDUCCION",\n    "COMBISTIBLE": "COMBUSTIBLE",\n    "POLICARBONTO": "POLICARBONATO",\n    "CONFIRGUARACION": "CONFIGURACION",\n    "MODEN": "MODEM",\n    "NVEL": "NIVEL",\n    "MUTICOLOR": "MULTICOLOR",\n    "ANTIBATERIAL": "ANTIBACTERIAL",\n    "MEMEBER\'S": "MEMBER\'S",\n    "HORIZONAL": "HORIZONTAL",\n    "CARTULLO": "CARTUCHO",\n    "IIMPRESORA": "IMPRESORA",\n    "AGUHA": "AGUJA",\n    "DIVICIONES": "DIVISIONES",\n    "CACUCHA": "CACHUCHA",\n    "BISCELADO": "BISELADO",\n    "BISCELADOS": "BISELADOS",\n    "TONILLO": "TORNILLO",\n    "SUJESION": "SUJECION",\n}\n\n\n# ============================================================\n# UTILIDADES\n# ============================================================\n\ndef quitar_acentos(texto):\n    texto = "" if pd.isna(texto) else str(texto)\n    return "".join(\n        c\n        for c in unicodedata.normalize("NFD", texto)\n        if unicodedata.category(c) != "Mn"\n    )\n\n\ndef normalizar_para_busqueda(texto):\n    return quitar_acentos(texto).upper()\n\n\ndef normalizar_codigo(valor):\n    if pd.isna(valor):\n        return ""\n\n    texto = str(valor).strip()\n\n    if texto.endswith(".0"):\n        texto = texto[:-2]\n\n    return texto\n\n\ndef buscar_archivo_resultado():\n    patron = os.path.join(REVISIONES_DIR, "RESULTADO_*.xlsx")\n    archivos = glob.glob(patron)\n\n    if not archivos:\n        raise FileNotFoundError(\n            "No se encontro ningun RESULTADO_*.xlsx en:\\n"\n            + REVISIONES_DIR\n        )\n\n    archivos = [\n        archivo\n        for archivo in archivos\n        if "DIAGNOSTICO_" not in os.path.basename(archivo).upper()\n    ]\n\n    if not archivos:\n        raise FileNotFoundError(\n            "No se encontro un archivo RESULTADO_*.xlsx valido."\n        )\n\n    return max(archivos, key=os.path.getmtime)\n\n\ndef nombre_salida(archivo_entrada):\n    base = os.path.basename(archivo_entrada)\n    periodo = os.path.splitext(base)[0].replace("RESULTADO_", "")\n\n    return os.path.join(\n        REVISIONES_DIR,\n        f"DIAGNOSTICO_REDACCION_{periodo}.xlsx",\n    )\n\n\n# ============================================================\n# DICCIONARIO EN SQLITE\n# ============================================================\n\ndef preparar_diccionario():\n    conn = sqlite3.connect(DB_PATH)\n\n    conn.execute(\n        """\n        CREATE TABLE IF NOT EXISTS diccionario_redaccion (\n            error TEXT PRIMARY KEY,\n            correccion TEXT NOT NULL,\n            origen TEXT\n        )\n        """\n    )\n\n    for error, correccion in CORRECCIONES_INICIALES.items():\n        conn.execute(\n            """\n            INSERT OR IGNORE INTO diccionario_redaccion\n            (error, correccion, origen)\n            VALUES (?, ?, ?)\n            """,\n            (error, correccion, "HISTORICO JULIO-AGOSTO"),\n        )\n\n    conn.commit()\n    conn.close()\n\n\ndef cargar_diccionario():\n    conn = sqlite3.connect(DB_PATH)\n\n    filas = conn.execute(\n        """\n        SELECT error, correccion\n        FROM diccionario_redaccion\n        ORDER BY LENGTH(error) DESC\n        """\n    ).fetchall()\n\n    conn.close()\n\n    return dict(filas)\n\n\n# ============================================================\n# DETECTORES\n# ============================================================\n\ndef detectar_palabras_incorrectas(texto, diccionario):\n    """\n    Detecta únicamente palabras/fragmentos que ya fueron validados\n    históricamente como REDACCION INCORRECTA.\n    """\n    texto_norm = normalizar_para_busqueda(texto)\n    hallazgos = []\n\n    for error, correccion in diccionario.items():\n        error_norm = normalizar_para_busqueda(error)\n        correccion_norm = normalizar_para_busqueda(correccion)\n\n        # Si la forma correcta ya aparece exactamente en lugar del error,\n        # no se marca.\n        patron_error = rf"(?<![A-Z0-9]){re.escape(error_norm)}(?![A-Z0-9])"\n\n        if re.search(patron_error, texto_norm):\n            hallazgos.append(\n                {\n                    "tipo": "PALABRA/CAPTURA",\n                    "detectado": error,\n                    "correccion": correccion,\n                    "detalle": f"{error} → {correccion}",\n                }\n            )\n\n    return hallazgos\n\n\ndef detectar_estructura_incorrecta(texto):\n    """\n    Actualmente NO se generan observaciones automáticas por estructura.\n\n    Después de validar septiembre se comprobó que patrones como:\n      - ", X,"\n      - ",,"\n      - "LONGITUD X ..."\n    pueden aparecer legítimamente en descripciones técnicas o como\n    consecuencia de la plantilla del codificador.\n\n    Para evitar falsos positivos, REDACCION INCORRECTA se limita por ahora\n    a errores ortográficos/de captura previamente validados.\n    """\n    return []\n\n\ndef analizar_redaccion(texto, diccionario):\n    hallazgos = []\n\n    hallazgos.extend(\n        detectar_palabras_incorrectas(texto, diccionario)\n    )\n\n    hallazgos.extend(\n        detectar_estructura_incorrecta(texto)\n    )\n\n    # Eliminar duplicados conservando orden.\n    unicos = []\n    claves = set()\n\n    for h in hallazgos:\n        clave = (\n            h["tipo"],\n            h["detectado"],\n            h["correccion"],\n        )\n\n        if clave not in claves:\n            claves.add(clave)\n            unicos.append(h)\n\n    return unicos\n\n\n# ============================================================\n# PROCESAMIENTO\n# ============================================================\n\ndef localizar_columnas(df):\n    mapa = {}\n\n    for col in df.columns:\n        clave = quitar_acentos(col).upper().strip()\n        mapa[clave] = col\n\n    requeridas = [\n        "CODIGO",\n        "ESTADO",\n        "GRUPO",\n        "SUBGRUPO",\n        "DESCRIPCION",\n    ]\n\n    faltantes = [\n        nombre\n        for nombre in requeridas\n        if nombre not in mapa\n    ]\n\n    if faltantes:\n        raise ValueError(\n            "Faltan columnas requeridas: "\n            + ", ".join(faltantes)\n        )\n\n    return mapa\n\n\ndef procesar():\n    preparar_diccionario()\n    diccionario = cargar_diccionario()\n\n    entrada = buscar_archivo_resultado()\n    salida = nombre_salida(entrada)\n\n    print("=" * 72)\n    print("DIAGNOSTICO ORTOGRAFIA - REDACCION INCORRECTA")\n    print("=" * 72)\n    print(f"Entrada: {entrada}")\n    print(f"Base de datos: {DB_PATH}")\n    print()\n    print(\n        f"Correcciones historicas cargadas: {len(diccionario)}"\n    )\n    print()\n\n    df = pd.read_excel(\n        entrada,\n        dtype=str,\n        engine="openpyxl",\n    )\n\n    mapa = localizar_columnas(df)\n\n    c_codigo = mapa["CODIGO"]\n    c_estado = mapa["ESTADO"]\n    c_grupo = mapa["GRUPO"]\n    c_subgrupo = mapa["SUBGRUPO"]\n    c_desc = mapa["DESCRIPCION"]\n\n    nuevos = df[\n        df[c_estado]\n        .astype(str)\n        .str.strip()\n        .str.upper()\n        .eq("NUEVO")\n    ].copy()\n\n    resultados = []\n    detalle = []\n\n    for _, fila in nuevos.iterrows():\n        codigo = normalizar_codigo(fila[c_codigo])\n        grupo = str(fila[c_grupo]).strip()\n        subgrupo = str(fila[c_subgrupo]).strip()\n        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])\n\n        hallazgos = analizar_redaccion(\n            descripcion,\n            diccionario,\n        )\n\n        if hallazgos:\n            observacion = "ORTOGRAFIA"\n            subobservacion = "REDACCION INCORRECTA"\n\n            motivos = "; ".join(\n                h["detalle"]\n                for h in hallazgos\n            )\n\n            correcciones = "; ".join(\n                h["correccion"]\n                for h in hallazgos\n            )\n        else:\n            observacion = "OK"\n            subobservacion = "OK"\n            motivos = ""\n            correcciones = ""\n\n        resultados.append(\n            {\n                "Codigo": codigo,\n                "Grupo": grupo,\n                "Subgrupo": subgrupo,\n                "Descripción": descripcion,\n                "Observación propuesta": observacion,\n                "Subobservación propuesta": subobservacion,\n                "Hallazgos": motivos,\n                "Corrección sugerida": correcciones,\n            }\n        )\n\n        for h in hallazgos:\n            detalle.append(\n                {\n                    "Codigo": codigo,\n                    "Grupo": grupo,\n                    "Subgrupo": subgrupo,\n                    "Descripción": descripcion,\n                    "Tipo de hallazgo": h["tipo"],\n                    "Texto detectado": h["detectado"],\n                    "Corrección sugerida": h["correccion"],\n                    "Detalle": h["detalle"],\n                }\n            )\n\n    resultado_df = pd.DataFrame(resultados)\n    detalle_df = pd.DataFrame(detalle)\n\n    casos_df = resultado_df[\n        resultado_df["Subobservación propuesta"]\n        .eq("REDACCION INCORRECTA")\n    ].copy()\n\n    resumen_df = pd.DataFrame(\n        [\n            [\n                "Articulos NUEVO analizados",\n                len(resultado_df),\n            ],\n            [\n                "REDACCION INCORRECTA",\n                len(casos_df),\n            ],\n            [\n                "Sin hallazgo de redaccion",\n                len(resultado_df) - len(casos_df),\n            ],\n            [\n                "Hallazgos individuales",\n                len(detalle_df),\n            ],\n            [\n                "Correcciones historicas disponibles",\n                len(diccionario),\n            ],\n        ],\n        columns=["Concepto", "Resultado"],\n    )\n\n    with pd.ExcelWriter(\n        salida,\n        engine="openpyxl",\n    ) as writer:\n        resumen_df.to_excel(\n            writer,\n            sheet_name="RESUMEN",\n            index=False,\n        )\n\n        casos_df.to_excel(\n            writer,\n            sheet_name="REDACCION INCORRECTA",\n            index=False,\n        )\n\n        detalle_df.to_excel(\n            writer,\n            sheet_name="DETALLE",\n            index=False,\n        )\n\n        resultado_df.to_excel(\n            writer,\n            sheet_name="DIAGNOSTICO",\n            index=False,\n        )\n\n        for hoja in writer.book.worksheets:\n            hoja.freeze_panes = "A2"\n            hoja.auto_filter.ref = hoja.dimensions\n\n            for columna in hoja.columns:\n                letra = columna[0].column_letter\n                max_len = 0\n\n                for celda in columna:\n                    valor = (\n                        ""\n                        if celda.value is None\n                        else str(celda.value)\n                    )\n\n                    max_len = max(\n                        max_len,\n                        min(len(valor), 80),\n                    )\n\n                hoja.column_dimensions[letra].width = max(\n                    12,\n                    min(max_len + 2, 60),\n                )\n\n    print("Diagnostico terminado correctamente.")\n    print("-" * 72)\n    print(\n        f"Articulos NUEVO analizados:         {len(resultado_df)}"\n    )\n    print(\n        f"REDACCION INCORRECTA:               {len(casos_df)}"\n    )\n    print(\n        f"Sin hallazgo de redaccion:          "\n        f"{len(resultado_df) - len(casos_df)}"\n    )\n    print(\n        f"Hallazgos individuales:             {len(detalle_df)}"\n    )\n    print()\n    print("Archivo generado:")\n    print(salida)\n    print("=" * 72)\n\n\nif __name__ == "__main__":\n    procesar()\n'

_SOURCE_CLASIFICACION = 'import os\nimport re\nimport glob\nimport sqlite3\nimport unicodedata\nfrom collections import Counter\n\nimport pandas as pd\n\n\nREVISIONES_DIR = (\n    r"__WEB_ONLY__"\n)\n\nBASE_DIR = os.path.dirname(os.path.abspath(__file__))\nDB_PATH = os.path.join(BASE_DIR, "base_datos.db")\n\nUMBRAL_MARCAR = 0.80\nUMBRAL_REVISAR = 0.58\nMARGEN_MINIMO = 0.16\n\n# Evidencia histórica: se usa de forma conservadora.\nHIST_SIM_MINIMA = 0.40\nHIST_SIM_FUERTE = 0.62\nHIST_CONSENSO_FUERTE = 0.72\nHIST_MARGEN_MINIMO = 0.12\nHIST_MAX_VECINOS = 30\n\nCLASIFICACIONES_GENERICAS = {\n    ("12", "08"),\n}\n\n# Contextos técnicos que tienen prioridad sobre una coincidencia genérica\n# del nombre del artículo. No son excepciones por código: son reglas\n# reutilizables para familias completas.\nPATRONES_CONTEXTO_ACTUAL = {\n    # ACCESORIOS TUBING\n    ("02", "16"): [\n        r"\\bRACOR\\b",\n        r"\\bOD\\b",\n        r"\\bNPTM\\b",\n        r"\\bDOBLE\\s+FER(?:UL|RUL|ULA)\\b",\n        r"\\bCOMPRESION\\b",\n    ],\n\n    # ACCESORIOS R.C.I. / RED CONTRA INCENDIO\n    ("02", "19"): [\n        r"\\bUL\\s*/\\s*FM\\b",\n        r"\\bCERTIFICACION\\s+UL\\b",\n        r"\\bEXTREMO[S]?\\s+RANURAD",\n    ],\n\n    # CONEXIONES PARA MANGUERA\n    ("06", "04"): [\n        r"\\bESPIGA\\b",\n        r"\\bGARRAS?\\b",\n        r"\\bFLARE\\b",\n        r"\\bMANGUERA\\b",\n        r"\\bCAMPANA\\s+CARA\\s+PLANA\\b",\n    ],\n\n    # VALVULAS PARA INSTRUMENTOS\n    ("07", "10"): [\n        r"\\bOD\\b",\n        r"\\bMONTAJE\\s+EN\\s+PANEL\\b",\n        r"\\bNO\\s+VIAS\\b",\n        r"\\b3\\s+VIAS\\b",\n        r"\\bINSTRUMENT",\n    ],\n\n    # PLOMERIA\n    ("12", "01"): [\n        r"\\bCPVC\\b",\n        r"\\bPVC\\b",\n        r"\\bPLOMERIA\\b",\n    ],\n\n    # HERRAMIENTAS MANUALES\n    ("15", "01"): [\n        r"^\\s*CORTA(?:DOR|DORA)?\\b",\n        r"^\\s*LLAVE\\b",\n        r"^\\s*PINZA[S]?\\b",\n        r"^\\s*EXTRACTOR\\b",\n        r"^\\s*HERRAMIENTA\\b",\n    ],\n\n    # ACCESORIOS ELECTRICOS DE CONSTRUCCION\n    ("20", "03"): [\n        r"\\bCONDUIT\\b",\n        r"\\bCROUSE[\\s-]*HIND",\n        r"\\bEATON\\b",\n        r"\\bUNY[-\\s]?\\d*",\n        r"\\bUNF[-\\s]?\\d*",\n        r"\\bCLASIFICACION\\s+DE\\s+AREA\\b",\n        r"\\bCLASE\\s+I\\b",\n        r"\\bDIV\\.?\\s*[12]\\b",\n    ],\n\n    # EPP Y EPPE\n    ("40", "09"): [\n        r"\\bARCO\\s+ELECT",\n        r"\\bCAL\\s*/\\s*CM2\\b",\n        r"\\bCHAQUETA\\b",\n        r"\\bOVEROL\\b",\n        r"\\bCASCO\\b",\n        r"\\bCARETA\\b",\n        r"\\bCAPUCHA\\b",\n        r"\\bPASAMONTANAS\\b",\n        r"\\bSALISBURY\\b",\n    ],\n\n    # SISTEMA DE FRENOS\n    ("61", "05"): [\n        r"\\bFRENO[S]?\\b",\n        r"\\bBOMBA\\s+DE\\s+FRENO\\b",\n        r"\\bBALATA[S]?\\b",\n        r"\\bDISCO[S]?\\s+DE\\s+FRENO\\b",\n    ],\n}\n\nSTOPWORDS = {\n    "DE", "DEL", "LA", "EL", "LOS", "LAS", "PARA", "CON", "SIN",\n    "EN", "Y", "O", "A", "AL", "POR", "TIPO", "MARCA", "MODELO",\n    "MATERIAL", "ESPECIFICACION", "ESPECIFICACIÓN", "CLASE",\n    "DIAMETRO", "DIÁMETRO", "LONGITUD", "LARGO", "ANCHO",\n    "ALTO", "ALTURA", "ESPESOR", "COLOR", "ACABADO", "MEDIDA",\n    "NO", "NUMERO", "NÚMERO", "PZA", "PZAS", "UNIDAD", "UNIDADES",\n    "SERIE", "FABRICANTE", "NORMA", "NORMATIVA", "GRADO",\n    "CAPACIDAD", "PRESION", "PRESIÓN", "VOLTAJE", "CORRIENTE",\n}\n\nPALABRAS_DEBILES = {\n    "GENERAL", "GENERALES", "ACCESORIO", "ACCESORIOS",\n    "MATERIAL", "MATERIALES", "EQUIPO", "EQUIPOS",\n    "SISTEMA", "SISTEMAS", "SERVICIO", "SERVICIOS",\n    "TECNICO", "TECNICOS", "MECANICA", "MECANICO",\n    "MECANICOS", "PROCESO", "PROCESOS", "SEGURIDAD",\n    "CALIDAD", "CANAL", "REFACCION", "REFACCIONES",\n    "REPUESTO", "REPUESTOS",\n}\n\nTERMINOS_CONTEXTUALES = {\n    "MOTOR", "COMPRESOR", "BOMBA", "MADERA", "CEMENTO",\n    "COMBUSTIBLE", "ANTICONGELANTE", "CANAL", "SEGURIDAD",\n    "PROCESOS", "MECANICA", "O-RING", "ORING", "PEAD",\n    "PVC", "CPVC", "ACERO", "INOXIDABLE", "CARBONO",\n    "ALUMINIO", "LATON", "BRONCE", "PLASTICO", "CAUCHO",\n    "GRAFITO", "POLIETILENO", "CONDUIT",\n}\n\n\ndef quitar_acentos(texto):\n    texto = "" if pd.isna(texto) else str(texto)\n    return "".join(\n        c for c in unicodedata.normalize("NFD", texto)\n        if unicodedata.category(c) != "Mn"\n    )\n\n\ndef normalizar(texto):\n    texto = quitar_acentos(texto).upper()\n    texto = texto.replace("Ø", " ")\n    texto = re.sub(r"[^A-Z0-9/#.+\\- ]+", " ", texto)\n    texto = re.sub(r"\\s+", " ", texto).strip()\n    return texto\n\n\ndef tokenizar(texto):\n    return [\n        t for t in normalizar(texto).split()\n        if len(t) >= 2 and t not in STOPWORDS\n    ]\n\n\ndef normalizar_codigo(valor):\n    if pd.isna(valor):\n        return ""\n    texto = str(valor).strip()\n    if texto.endswith(".0"):\n        texto = texto[:-2]\n    return texto\n\n\ndef normalizar_clave(valor):\n    if pd.isna(valor):\n        return ""\n    texto = str(valor).strip()\n    if texto.endswith(".0"):\n        texto = texto[:-2]\n    if texto.isdigit() and len(texto) < 2:\n        texto = texto.zfill(2)\n    return texto\n\n\ndef contiene_frase(texto, frase):\n    texto_norm = normalizar(texto)\n    frase_norm = normalizar(frase)\n    if not frase_norm:\n        return False\n\n    return re.search(\n        rf"(?<![A-Z0-9]){re.escape(frase_norm)}(?![A-Z0-9])",\n        texto_norm,\n    ) is not None\n\n\ndef primer_segmento(texto):\n    """\n    Conserva la puntuación hasta separar el primer segmento.\n    Antes se normalizaba primero y las comas/punto y coma desaparecían,\n    por lo que se podían mezclar atributos con el objeto principal.\n    """\n    raw = quitar_acentos(texto).upper()\n    if not raw.strip():\n        return ""\n\n    raw = re.split(r"[,;]", raw, maxsplit=1)[0]\n    return normalizar(raw)\n\n\ndef objeto_principal(texto):\n    seg = primer_segmento(texto)\n    if not seg:\n        return ""\n    return " ".join(seg.split()[:10])\n\n\ndef tokens_objeto(texto):\n    return [\n        t for t in tokenizar(objeto_principal(texto))\n        if t not in PALABRAS_DEBILES\n    ]\n\n\ndef detectar_especializaciones(texto):\n    t = normalizar(texto)\n    return [\n        termino\n        for termino in TERMINOS_CONTEXTUALES\n        if contiene_frase(t, termino)\n    ]\n\n\ndef es_mencion_secundaria(descripcion, termino):\n    desc = normalizar(descripcion)\n    obj = objeto_principal(descripcion)\n    termino = normalizar(termino)\n\n    if not termino:\n        return True\n\n    if not contiene_frase(obj, termino):\n        return True\n\n    patron = (\n        rf"\\b(?:PARA|DE|DEL|CON|EN|USO|APLICACION|APLICACIÓN)\\s+"\n        rf"(?:[A-Z0-9\\-]+\\s+){{0,3}}{re.escape(termino)}\\b"\n    )\n\n    if re.search(patron, desc):\n        return True\n\n    return False\n\n\ndef buscar_archivo_resultado():\n    archivos = glob.glob(\n        os.path.join(REVISIONES_DIR, "RESULTADO_*.xlsx")\n    )\n\n    if not archivos:\n        raise FileNotFoundError(\n            "No se encontro ningun RESULTADO_*.xlsx en:\\n"\n            + REVISIONES_DIR\n        )\n\n    return max(archivos, key=os.path.getmtime)\n\n\ndef nombre_salida(archivo_entrada):\n    base = os.path.basename(archivo_entrada)\n    periodo = os.path.splitext(base)[0].replace("RESULTADO_", "")\n\n    return os.path.join(\n        REVISIONES_DIR,\n        f"DIAGNOSTICO_CLASIFICACION_{periodo}.xlsx",\n    )\n\n\ndef cargar_catalogo():\n    conn = sqlite3.connect(DB_PATH)\n\n    catalogo = pd.read_sql_query(\n        """\n        SELECT\n            grupo,\n            subgrupo,\n            especialidad,\n            nombre_grupo,\n            nombre_subgrupo,\n            ica,\n            um,\n            determinante\n        FROM catalogo_subgrupos\n        """,\n        conn,\n    )\n\n    campos = pd.read_sql_query(\n        """\n        SELECT\n            grupo,\n            subgrupo,\n            orden,\n            elemento,\n            tipo_elemento,\n            obligatorio\n        FROM campos_plantilla\n        ORDER BY grupo, subgrupo, orden\n        """,\n        conn,\n    )\n\n    conn.close()\n\n    for tabla in (catalogo, campos):\n        tabla["grupo"] = tabla["grupo"].map(normalizar_clave)\n        tabla["subgrupo"] = tabla["subgrupo"].map(normalizar_clave)\n\n    return catalogo, campos\n\n\ndef cargar_revisiones_historicas():\n    """\n    Carga únicamente la tabla SQLite. Los Excel de enero-agosto NO se\n    consultan durante el diagnóstico mensual.\n    """\n    conn = sqlite3.connect(DB_PATH)\n\n    historico = pd.read_sql_query(\n        """\n        SELECT\n            codigo,\n            grupo,\n            subgrupo,\n            descripcion,\n            mes,\n            estado_clasificacion\n        FROM revisiones_historicas\n        WHERE COALESCE(TRIM(descripcion), \'\') <> \'\'\n          AND estado_clasificacion <> \'SIN_REVISION\'\n        """,\n        conn,\n    )\n\n    conn.close()\n\n    historico["grupo"] = historico["grupo"].map(normalizar_clave)\n    historico["subgrupo"] = historico["subgrupo"].map(normalizar_clave)\n\n    return historico\n\n\ndef tokens_historicos(texto):\n    """\n    Tokens técnicos normalizados para comparación histórica.\n    Se eliminan palabras débiles y se unifican plurales simples.\n    """\n    resultado = set()\n\n    for token in tokenizar(texto):\n        raiz = raiz_token(token)\n\n        if not raiz:\n            continue\n\n        if raiz in PALABRAS_DEBILES:\n            continue\n\n        if len(raiz) < 3:\n            continue\n\n        resultado.add(raiz)\n\n    return resultado\n\n\ndef construir_indice_historico(historico):\n    """\n    Índice invertido token -> registros históricos.\n    Evita comparar cada artículo nuevo contra los 11 mil registros.\n    """\n    registros = []\n    indice = {}\n\n    for _, fila in historico.iterrows():\n        tokens = tokens_historicos(fila["descripcion"])\n\n        if not tokens:\n            continue\n\n        registro = {\n            "codigo": normalizar_codigo(fila["codigo"]),\n            "clave": (\n                normalizar_clave(fila["grupo"]),\n                normalizar_clave(fila["subgrupo"]),\n            ),\n            "descripcion": str(fila["descripcion"]),\n            "mes": str(fila["mes"]),\n            "estado": str(fila["estado_clasificacion"]).strip().upper(),\n            "tokens": tokens,\n        }\n\n        idx = len(registros)\n        registros.append(registro)\n\n        for token in tokens:\n            indice.setdefault(token, set()).add(idx)\n\n    return {\n        "registros": registros,\n        "indice": indice,\n    }\n\n\ndef similitud_historica(tokens_a, tokens_b):\n    """\n    Dice sobre tokens técnicos. Es deliberadamente conservadora:\n    una sola palabra compartida no basta para dar una clasificación.\n    """\n    if not tokens_a or not tokens_b:\n        return 0.0, 0\n\n    comunes = tokens_a & tokens_b\n    n_comunes = len(comunes)\n\n    if n_comunes == 0:\n        return 0.0, 0\n\n    score = (2.0 * n_comunes) / (len(tokens_a) + len(tokens_b))\n\n    return score, n_comunes\n\n\ndef evaluar_evidencia_historica(\n    descripcion,\n    clave_actual,\n    indice_historico,\n):\n    """\n    Resume antecedentes parecidos.\n\n    Positivos:\n      CLASIFICACION_CORRECTA -> respalda grupo + subgrupo.\n\n    Negativos:\n      GRUPO_INCORRECTO -> evidencia contra ese grupo.\n      SUBGRUPO_INCORRECTO -> respalda el grupo, pero evidencia contra\n      ese subgrupo.\n\n    Los conteos brutos por mes NO deciden. Solo cuentan antecedentes\n    cuya descripción es suficientemente parecida al artículo nuevo.\n    """\n    vacio = {\n        "disponible": False,\n        "actual_score": 0.0,\n        "actual_count": 0,\n        "mejor_clave": None,\n        "mejor_score": 0.0,\n        "mejor_count": 0,\n        "segundo_score": 0.0,\n        "neg_grupo_actual": 0.0,\n        "neg_subgrupo_actual": 0.0,\n        "ejemplos_actual": [],\n        "ejemplos_mejor": [],\n        "detalle": "",\n    }\n\n    if not indice_historico:\n        return vacio\n\n    q_tokens = tokens_historicos(descripcion)\n\n    if len(q_tokens) < 2:\n        return vacio\n\n    candidatos = set()\n\n    for token in q_tokens:\n        candidatos.update(\n            indice_historico["indice"].get(token, set())\n        )\n\n    if not candidatos:\n        return vacio\n\n    vecinos = []\n\n    for idx in candidatos:\n        reg = indice_historico["registros"][idx]\n        sim, comunes = similitud_historica(\n            q_tokens,\n            reg["tokens"],\n        )\n\n        # Una descripción corta necesita una semejanza mayor.\n        minimo = HIST_SIM_MINIMA\n        if len(q_tokens) <= 4:\n            minimo = 0.50\n\n        if sim < minimo:\n            continue\n\n        if comunes < 2:\n            continue\n\n        vecinos.append((sim, comunes, reg))\n\n    if not vecinos:\n        return vacio\n\n    vecinos.sort(\n        key=lambda x: (x[0], x[1]),\n        reverse=True,\n    )\n    vecinos = vecinos[:HIST_MAX_VECINOS]\n\n    positivos = {}\n    negativos_grupo = {}\n    negativos_subgrupo = {}\n\n    def agregar(dic, clave, sim, reg):\n        bloque = dic.setdefault(\n            clave,\n            {"pesos": [], "ejemplos": []},\n        )\n        # Elevar al cuadrado evita que muchos parecidos débiles ganen\n        # frente a pocos antecedentes muy similares.\n        bloque["pesos"].append(sim ** 2)\n        if len(bloque["ejemplos"]) < 3:\n            bloque["ejemplos"].append(\n                (\n                    reg["codigo"],\n                    reg["mes"],\n                    sim,\n                )\n            )\n\n    for sim, _, reg in vecinos:\n        clave = reg["clave"]\n        estado = reg["estado"]\n\n        if estado == "CLASIFICACION_CORRECTA":\n            agregar(positivos, clave, sim, reg)\n\n        elif estado == "GRUPO_INCORRECTO":\n            agregar(\n                negativos_grupo,\n                clave[0],\n                sim,\n                reg,\n            )\n\n        elif estado == "SUBGRUPO_INCORRECTO":\n            # El grupo sí fue aceptado.\n            agregar(\n                positivos,\n                (clave[0], "__GRUPO__"),\n                sim * 0.80,\n                reg,\n            )\n            agregar(\n                negativos_subgrupo,\n                clave,\n                sim,\n                reg,\n            )\n\n    def resumir_bloque(bloque):\n        if not bloque:\n            return 0.0, 0, []\n\n        pesos = sorted(\n            bloque["pesos"],\n            reverse=True,\n        )[:5]\n\n        # Score de consenso: combina la mejor similitud con repetición.\n        mejor = pesos[0] ** 0.5\n        repeticion = min(1.0, len(pesos) / 3.0)\n        score = min(\n            1.0,\n            (0.78 * mejor) + (0.22 * repeticion),\n        )\n\n        return score, len(pesos), bloque["ejemplos"]\n\n    positivos_exactos = []\n\n    for clave, bloque in positivos.items():\n        if clave[1] == "__GRUPO__":\n            continue\n\n        score, count, ejemplos = resumir_bloque(bloque)\n        positivos_exactos.append(\n            (score, count, clave, ejemplos)\n        )\n\n    positivos_exactos.sort(reverse=True)\n\n    mejor_score = positivos_exactos[0][0] if positivos_exactos else 0.0\n    mejor_count = positivos_exactos[0][1] if positivos_exactos else 0\n    mejor_clave = positivos_exactos[0][2] if positivos_exactos else None\n    ejemplos_mejor = positivos_exactos[0][3] if positivos_exactos else []\n\n    segundo_score = (\n        positivos_exactos[1][0]\n        if len(positivos_exactos) > 1\n        else 0.0\n    )\n\n    actual_score = 0.0\n    actual_count = 0\n    ejemplos_actual = []\n\n    if clave_actual in positivos:\n        (\n            actual_score,\n            actual_count,\n            ejemplos_actual,\n        ) = resumir_bloque(\n            positivos[clave_actual]\n        )\n\n    neg_grupo_actual = 0.0\n    if clave_actual[0] in negativos_grupo:\n        neg_grupo_actual = resumir_bloque(\n            negativos_grupo[clave_actual[0]]\n        )[0]\n\n    neg_subgrupo_actual = 0.0\n    if clave_actual in negativos_subgrupo:\n        neg_subgrupo_actual = resumir_bloque(\n            negativos_subgrupo[clave_actual]\n        )[0]\n\n    def formatear_ejemplos(ejemplos):\n        return ", ".join(\n            f"{codigo} ({mes}, {sim:.0%})"\n            for codigo, mes, sim in ejemplos\n        )\n\n    partes = []\n\n    if actual_score:\n        partes.append(\n            "histórico respalda actual "\n            f"{clave_actual[0]}/{clave_actual[1]} "\n            f"({actual_score:.0%}; {actual_count} antecedente(s))"\n        )\n\n    if mejor_clave:\n        partes.append(\n            "mejor histórico "\n            f"{mejor_clave[0]}/{mejor_clave[1]} "\n            f"({mejor_score:.0%}; {mejor_count} antecedente(s))"\n        )\n\n    if neg_grupo_actual:\n        partes.append(\n            f"histórico cuestiona grupo actual ({neg_grupo_actual:.0%})"\n        )\n\n    if neg_subgrupo_actual:\n        partes.append(\n            f"histórico cuestiona subgrupo actual "\n            f"({neg_subgrupo_actual:.0%})"\n        )\n\n    return {\n        "disponible": True,\n        "actual_score": actual_score,\n        "actual_count": actual_count,\n        "mejor_clave": mejor_clave,\n        "mejor_score": mejor_score,\n        "mejor_count": mejor_count,\n        "segundo_score": segundo_score,\n        "neg_grupo_actual": neg_grupo_actual,\n        "neg_subgrupo_actual": neg_subgrupo_actual,\n        "ejemplos_actual": ejemplos_actual,\n        "ejemplos_mejor": ejemplos_mejor,\n        "detalle": "; ".join(partes),\n        "ejemplos_actual_txt": formatear_ejemplos(ejemplos_actual),\n        "ejemplos_mejor_txt": formatear_ejemplos(ejemplos_mejor),\n    }\n\n\ndef construir_perfiles(catalogo, campos):\n    perfiles = {}\n\n    campos_por_clave = {}\n    for clave, bloque in campos.groupby(["grupo", "subgrupo"]):\n        campos_por_clave[clave] = bloque.to_dict("records")\n\n    for _, fila in catalogo.iterrows():\n        grupo = normalizar_clave(fila["grupo"])\n        subgrupo = normalizar_clave(fila["subgrupo"])\n        clave = (grupo, subgrupo)\n\n        textos_fijos = []\n        obligatorios = []\n\n        for campo in campos_por_clave.get(clave, []):\n            elemento = str(campo["elemento"]).strip()\n\n            if campo["tipo_elemento"] == "TEXTO_FIJO":\n                textos_fijos.append(elemento)\n            elif int(campo["obligatorio"]) == 1:\n                obligatorios.append(elemento)\n\n        perfiles[clave] = {\n            "grupo": grupo,\n            "subgrupo": subgrupo,\n            "especialidad": "" if pd.isna(fila["especialidad"]) else str(fila["especialidad"]),\n            "nombre_grupo": "" if pd.isna(fila["nombre_grupo"]) else str(fila["nombre_grupo"]),\n            "nombre_subgrupo": "" if pd.isna(fila["nombre_subgrupo"]) else str(fila["nombre_subgrupo"]),\n            "um": "" if pd.isna(fila["um"]) else str(fila["um"]),\n            "determinante": "" if pd.isna(fila["determinante"]) else str(fila["determinante"]),\n            "textos_fijos": textos_fijos,\n            "obligatorios": obligatorios,\n        }\n\n    return perfiles\n\n\ndef es_servicio(perfil):\n    texto = normalizar(\n        " ".join(\n            [\n                perfil.get("especialidad", ""),\n                perfil.get("nombre_grupo", ""),\n                perfil.get("nombre_subgrupo", ""),\n            ]\n        )\n    )\n    return "SERVICIO" in texto\n\n\ndef articulo_actual_es_servicio(descripcion, um, perfil_actual):\n    if normalizar(um) == "SV":\n        return True\n    if perfil_actual:\n        return es_servicio(perfil_actual)\n    return objeto_principal(descripcion).startswith("SERVICIO")\n\n\ndef raiz_token(token):\n    """\n    Normalización lexical muy conservadora para comparar singular/plural.\n    No pretende ser un stemmer lingüístico completo.\n    """\n    t = normalizar(token)\n\n    if len(t) <= 4:\n        return t\n\n    # MANGUERAS -> MANGUERA, VALVULAS -> VALVULA, BOMBAS -> BOMBA\n    if t.endswith("ES") and len(t) > 6:\n        return t[:-2]\n\n    if t.endswith("S") and len(t) > 5:\n        return t[:-1]\n\n    return t\n\n\ndef tokens_raiz(texto):\n    return {\n        raiz_token(t)\n        for t in tokenizar(texto)\n        if t not in PALABRAS_DEBILES\n    }\n\n\ndef evidencia_actual_suficiente(\n    descripcion,\n    perfil_actual,\n    clave_actual,\n):\n    """\n    Busca evidencia positiva para CONFIRMAR la clasificación actual.\n\n    Es deliberadamente más flexible que la lógica utilizada para acusar\n    una clasificación incorrecta. Para marcar un error seguimos exigiendo\n    evidencia fuerte; para confirmar la clasificación actual basta una\n    coincidencia técnica coherente y que no exista una alternativa fuerte.\n    """\n    if not perfil_actual:\n        return False, []\n\n    evidencias = []\n\n    # 1. Reglas técnicas específicas ya definidas para la familia actual.\n    contexto, senales = contexto_actual_fuerte(\n        descripcion,\n        clave_actual,\n    )\n    if contexto:\n        evidencias.append("CONTEXTO TECNICO ACTUAL")\n        return True, evidencias\n\n    obj = objeto_principal(descripcion)\n    obj_raices = tokens_raiz(obj)\n\n    # 2. Coincidencia con el nombre del subgrupo, admitiendo singular/plural.\n    sub_raices = tokens_raiz(\n        perfil_actual.get("nombre_subgrupo", "")\n    )\n\n    comunes_sub = sorted(obj_raices & sub_raices)\n\n    if comunes_sub:\n        evidencias.append(\n            "SUBGRUPO ACTUAL: " + ", ".join(comunes_sub)\n        )\n        return True, evidencias\n\n    # 3. Texto fijo de la plantilla actual presente en el objeto.\n    for fijo in perfil_actual.get("textos_fijos", []):\n        fijo_norm = normalizar(fijo)\n\n        if (\n            fijo_norm\n            and fijo_norm not in PALABRAS_DEBILES\n            and contiene_frase(obj, fijo_norm)\n        ):\n            evidencias.append(\n                "TEXTO FIJO ACTUAL: " + fijo_norm\n            )\n            return True, evidencias\n\n    # 4. Familia actual. Solo se usa si no es una familia genérica.\n    grupo = normalizar(\n        perfil_actual.get("nombre_grupo", "")\n    )\n\n    familias_genericas = {\n        "ARTICULOS DE FERRETERIA",\n        "MATERIALES PARA OBRA CIVIL",\n        "REPUESTOS",\n        "REFACCIONES",\n        "EQUIPOS",\n    }\n\n    if grupo not in familias_genericas:\n        grupo_raices = tokens_raiz(grupo)\n        comunes_grupo = sorted(obj_raices & grupo_raices)\n\n        if comunes_grupo:\n            evidencias.append(\n                "FAMILIA ACTUAL: " + ", ".join(comunes_grupo)\n            )\n            return True, evidencias\n\n    return False, evidencias\n\n\ndef regla_negocio_directa(descripcion):\n    """\n    Reglas técnicas de alta precisión.\n    No se usan excepciones por código.\n    """\n    t = normalizar(descripcion)\n\n    if (\n        re.search(r"\\bZAPATA\\s+TERMINAL\\b", t)\n        and re.search(r"\\b(?:CABLE|CONDUCTOR|CALIBRE)\\b", t)\n        and re.search(r"\\bAWG\\b", t)\n    ):\n        return (\n            ("20", "03"),\n            "REGLA TECNICA: ZAPATA TERMINAL PARA CABLE ELECTRICO EN AWG",\n        )\n\n    if (\n        re.search(r"\\bADAPTADOR\\s+MACHO\\b", t)\n        and re.search(r"\\bCPVC\\b", t)\n    ):\n        return (\n            ("12", "01"),\n            "REGLA TECNICA: ADAPTADOR MACHO DE CPVC",\n        )\n\n    # TEE de PVC/CPVC se trata como accesorio de plomeria (12/01).\n    # La regla exige tanto el objeto TEE como el material PVC/CPVC;\n    # no convierte cualquier articulo de PVC/CPVC en plomeria.\n    if (\n        re.search(r"\\bTEE\\b", t)\n        and re.search(r"\\b(?:PVC|CPVC)\\b", t)\n    ):\n        return (\n            ("12", "01"),\n            "REGLA TECNICA: TEE DE PVC/CPVC PARA PLOMERIA",\n        )\n\n    return None, ""\n\ndef tokens_nombre_utiles(nombre):\n    return [\n        t for t in tokenizar(nombre)\n        if t not in PALABRAS_DEBILES\n    ]\n\n\ndef puntuar_familia(descripcion, perfil):\n    desc_tokens = set(tokenizar(descripcion))\n    grupo_tokens = set(tokens_nombre_utiles(perfil["nombre_grupo"]))\n\n    if not grupo_tokens:\n        return 0.0, []\n\n    comunes = grupo_tokens & desc_tokens\n    if not comunes:\n        return 0.0, []\n\n    proporcion = len(comunes) / len(grupo_tokens)\n    score = min(0.18, 0.18 * proporcion)\n\n    return score, [\n        "FAMILIA: " + ", ".join(sorted(comunes))\n    ]\n\n\ndef puntuar_objeto(descripcion, perfil):\n    obj = objeto_principal(descripcion)\n    nombre = perfil["nombre_subgrupo"]\n\n    if not obj or not nombre:\n        return 0.0, [], False\n\n    evidencias = []\n    score = 0.0\n    ancla = False\n\n    nombre_norm = normalizar(nombre)\n\n    if (\n        nombre_norm not in PALABRAS_DEBILES\n        and contiene_frase(obj, nombre_norm)\n        and not es_mencion_secundaria(descripcion, nombre_norm)\n    ):\n        score += 0.62\n        evidencias.append(f"OBJETO PRINCIPAL: {nombre}")\n        ancla = True\n\n    else:\n        tokens_nombre = tokens_nombre_utiles(nombre)\n        tokens_obj = set(tokens_objeto(descripcion))\n\n        if len(tokens_nombre) >= 2:\n            presentes = [\n                t for t in tokens_nombre\n                if t in tokens_obj\n            ]\n            proporcion = (\n                len(presentes) / len(tokens_nombre)\n                if tokens_nombre else 0\n            )\n\n            if proporcion >= 0.80:\n                score += 0.48\n                evidencias.append(\n                    "OBJETO PARCIAL: " + ", ".join(presentes)\n                )\n                ancla = True\n            elif proporcion >= 0.60:\n                score += 0.30\n                evidencias.append(\n                    "OBJETO PARCIAL: " + ", ".join(presentes)\n                )\n\n    for texto in perfil["textos_fijos"]:\n        texto_norm = normalizar(texto)\n\n        if (\n            not texto_norm\n            or texto_norm in PALABRAS_DEBILES\n        ):\n            continue\n\n        if (\n            contiene_frase(obj, texto_norm)\n            and not es_mencion_secundaria(descripcion, texto_norm)\n        ):\n            score += 0.24\n            evidencias.append(f"TEXTO FIJO: {texto}")\n            ancla = True\n            break\n\n    return min(0.86, score), evidencias, ancla\n\n\ndef puntuar_especializacion(descripcion, perfil):\n    especializaciones = detectar_especializaciones(descripcion)\n\n    if not especializaciones:\n        return 0.0, []\n\n    texto_perfil = normalizar(\n        perfil["nombre_grupo"]\n        + " "\n        + perfil["nombre_subgrupo"]\n        + " "\n        + perfil["determinante"]\n    )\n\n    coincidencias = [\n        e for e in especializaciones\n        if contiene_frase(texto_perfil, e)\n    ]\n\n    if not coincidencias:\n        return 0.0, []\n\n    return min(0.18, 0.09 * len(coincidencias)), [\n        "ESPECIALIZACION: " + ", ".join(coincidencias[:3])\n    ]\n\n\ndef puntuar_campos(descripcion, perfil):\n    obligatorios = perfil["obligatorios"]\n\n    if not obligatorios:\n        return 0.0, []\n\n    detectados = []\n\n    for campo in obligatorios:\n        campo_norm = normalizar(campo)\n        if campo_norm and contiene_frase(descripcion, campo_norm):\n            detectados.append(campo)\n\n    if not detectados:\n        return 0.0, []\n\n    proporcion = len(detectados) / len(obligatorios)\n    score = min(0.08, 0.08 * proporcion)\n\n    return score, [\n        "CAMPOS: " + ", ".join(detectados[:4])\n    ]\n\n\ndef puntuar_perfil(descripcion, perfil):\n    score_familia, evid_familia = puntuar_familia(descripcion, perfil)\n    score_objeto, evid_objeto, ancla = puntuar_objeto(descripcion, perfil)\n    score_especial, evid_especial = puntuar_especializacion(descripcion, perfil)\n    score_campos, evid_campos = puntuar_campos(descripcion, perfil)\n\n    if score_objeto < 0.30:\n        score_especial *= 0.25\n        score_familia *= 0.50\n        score_campos *= 0.50\n\n    total = (\n        score_objeto\n        + score_especial\n        + score_familia\n        + score_campos\n    )\n\n    return {\n        "score": min(1.0, total),\n        "score_objeto": score_objeto,\n        "score_especial": score_especial,\n        "score_familia": score_familia,\n        "score_campos": score_campos,\n        "ancla": ancla,\n        "evidencias": (\n            evid_objeto\n            + evid_especial\n            + evid_familia\n            + evid_campos\n        ),\n    }\n\n\ndef especializacion_actual_respaldada(descripcion, perfil_actual):\n    if not perfil_actual:\n        return False, []\n\n    texto_perfil = normalizar(\n        perfil_actual["nombre_grupo"]\n        + " "\n        + perfil_actual["nombre_subgrupo"]\n    )\n\n    encontrados = []\n\n    for termino in detectar_especializaciones(descripcion):\n        if contiene_frase(texto_perfil, termino):\n            encontrados.append(termino)\n\n    if encontrados:\n        return True, encontrados\n\n    return False, []\n\n\ndef tokens_contexto_perfil(perfil):\n    """\n    Tokens representativos de la familia actual. Se usan para evitar\n    saltos entre dominios técnicos cuando la descripción respalda\n    claramente la familia donde ya está dado de alta el artículo.\n    """\n    texto = (\n        perfil.get("especialidad", "")\n        + " "\n        + perfil.get("nombre_grupo", "")\n        + " "\n        + perfil.get("nombre_subgrupo", "")\n    )\n\n    ignorar = PALABRAS_DEBILES | {\n        "ARTICULO", "ARTICULOS", "GENERAL", "GENERALES",\n        "ACCESORIO", "ACCESORIOS", "MATERIAL", "MATERIALES",\n    }\n\n    return {\n        t for t in tokenizar(texto)\n        if t not in ignorar and len(t) >= 3\n    }\n\n\ndef familia_actual_respaldada(descripcion, perfil_actual):\n    """\n    Detecta si la descripción contiene vocabulario técnico que respalda\n    la familia actual (eléctrico, instrumentación, tubing, PEAD, etc.).\n    """\n    if not perfil_actual:\n        return False, []\n\n    desc = set(tokenizar(descripcion))\n    familia = tokens_contexto_perfil(perfil_actual)\n    comunes = sorted(desc & familia)\n\n    return bool(comunes), comunes\n\n\ndef candidato_cambia_familia_respaldada(\n    descripcion,\n    perfil_actual,\n    perfil_candidato,\n):\n    """\n    Si la familia actual está explícitamente respaldada por la descripción,\n    una alternativa de otro grupo necesita conservar ese contexto o se\n    considera una pérdida de información.\n    """\n    if not perfil_actual or not perfil_candidato:\n        return False, []\n\n    respaldada, comunes = familia_actual_respaldada(\n        descripcion,\n        perfil_actual,\n    )\n\n    if not respaldada:\n        return False, []\n\n    if (\n        normalizar_clave(perfil_actual.get("grupo", ""))\n        == normalizar_clave(perfil_candidato.get("grupo", ""))\n    ):\n        return False, []\n\n    candidato_tokens = tokens_contexto_perfil(perfil_candidato)\n    conservados = [t for t in comunes if t in candidato_tokens]\n\n    if conservados:\n        return False, []\n\n    return True, comunes\n\n\ndef candidato_es_mas_generico(\n    descripcion,\n    perfil_actual,\n    perfil_candidato,\n):\n    """\n    Protege clasificaciones especializadas frente a categorías que solo\n    nombran el objeto genérico.\n\n    Ejemplos:\n      ACCESORIOS PEAD -> CODO\n      VALVULAS PARA INSTRUMENTOS -> VALVULA DE BOLA\n      ACCESORIOS TUBING -> TAPON\n    """\n    if not perfil_actual or not perfil_candidato:\n        return False, []\n\n    actual_texto = normalizar(\n        perfil_actual.get("nombre_grupo", "")\n        + " "\n        + perfil_actual.get("nombre_subgrupo", "")\n    )\n    candidato_texto = normalizar(\n        perfil_candidato.get("nombre_grupo", "")\n        + " "\n        + perfil_candidato.get("nombre_subgrupo", "")\n    )\n\n    especializaciones = []\n\n    for termino in (\n        "PEAD", "PVC", "CPVC", "TUBING", "CONDUIT",\n        "INSTRUMENTACION", "INSTRUMENTOS", "ELECTRICO",\n        "ELECTRICA", "FRENOS", "VEHICULAR", "AUTOMOTRIZ",\n    ):\n        if (\n            contiene_frase(actual_texto, termino)\n            and contiene_frase(descripcion, termino)\n            and not contiene_frase(candidato_texto, termino)\n        ):\n            especializaciones.append(termino)\n\n    return bool(especializaciones), especializaciones\n\n\ndef objeto_es_herramienta_o_accesorio_funcional(descripcion):\n    """\n    Detecta encabezados cuyo primer término describe una herramienta o\n    accesorio funcional y donde el término posterior es el material/equipo\n    sobre el que trabaja. Evita clasificar CORTA TUBING como TUBING.\n    """\n    obj = objeto_principal(descripcion)\n    tokens = normalizar(obj).split()\n\n    if not tokens:\n        return False\n\n    prefijos = (\n        "CORTA", "CORTADOR", "CORTADORA", "LLAVE", "PINZA",\n        "PINZAS", "EXTRACTOR", "ADAPTADOR", "SOPORTE",\n        "HERRAMIENTA", "KIT",\n    )\n\n    return tokens[0] in prefijos\n\ndef candidato_pierde_especializacion(\n    descripcion,\n    perfil_actual,\n    perfil_candidato,\n):\n    protegido, especializaciones = especializacion_actual_respaldada(\n        descripcion,\n        perfil_actual,\n    )\n\n    if not protegido:\n        return False, []\n\n    texto_candidato = normalizar(\n        perfil_candidato["nombre_grupo"]\n        + " "\n        + perfil_candidato["nombre_subgrupo"]\n    )\n\n    perdidas = [\n        e for e in especializaciones\n        if not contiene_frase(texto_candidato, e)\n    ]\n\n    return bool(perdidas), perdidas\n\n\ndef contexto_actual_fuerte(descripcion, clave_actual):\n    """\n    Comprueba si la descripción contiene señales técnicas propias del\n    grupo/subgrupo actual. Dos señales dan protección fuerte; una señal\n    especialmente distintiva también puede bastar.\n    """\n    patrones = PATRONES_CONTEXTO_ACTUAL.get(clave_actual, [])\n    if not patrones:\n        return False, []\n\n    texto = normalizar(descripcion)\n    encontrados = []\n\n    for patron in patrones:\n        if re.search(patron, texto, flags=re.IGNORECASE):\n            encontrados.append(patron)\n\n    # Una sola señal es suficiente en familias cuyos indicadores son\n    # muy distintivos; en el resto se piden dos.\n    familias_una_senal = {\n        ("02", "19"),  # UL/FM o ranurado\n        ("06", "04"),  # espiga / flare / garras\n        ("15", "01"),  # herramienta al inicio\n        ("20", "03"),  # conduit / UNY / Crouse-Hinds\n        ("40", "09"),  # EPP / arco eléctrico\n        ("61", "05"),  # frenos\n    }\n\n    minimo = 1 if clave_actual in familias_una_senal else 2\n    return len(encontrados) >= minimo, encontrados\n\n\ndef termino_candidato_es_unidad_o_atributo(descripcion, perfil_candidato):\n    """\n    Evita que unidades, materiales o atributos secundarios se conviertan\n    en el objeto principal. Caso típico: 20 CAL/CM2 no es \'CAL\' material.\n    """\n    desc = normalizar(descripcion)\n    nombre = normalizar(perfil_candidato.get("nombre_subgrupo", ""))\n\n    if nombre == "CAL":\n        if re.search(r"\\b\\d+(?:\\.\\d+)?\\s*CAL(?:\\s*/\\s*CM2|\\b)", desc):\n            return True\n        if "ARCO ELECT" in desc:\n            return True\n\n    # CPVC/PVC por sí solos no deben convertir un ADAPTADOR en TUBERIA.\n    if nombre in {"CPVC", "PVC", "PEAD", "TUBING"}:\n        inicio = objeto_principal(descripcion).split()\n        if inicio and inicio[0] in {\n            "ADAPTADOR", "CONECTOR", "COPLE", "CODO", "TEE",\n            "TAPON", "TUERCA", "VALVULA", "HERRAMIENTA",\n            "CORTA", "CORTADOR", "CORTADORA",\n        }:\n            return True\n\n    return False\n\ndef candidatos_permitidos(\n    descripcion,\n    um,\n    clave_actual,\n    perfiles,\n):\n    perfil_actual = perfiles.get(clave_actual)\n\n    actual_servicio = articulo_actual_es_servicio(\n        descripcion,\n        um,\n        perfil_actual,\n    )\n\n    resultado = {}\n\n    for clave, perfil in perfiles.items():\n        if es_servicio(perfil) != actual_servicio:\n            continue\n        resultado[clave] = perfil\n\n    return resultado\n\n\ndef ranking_candidatos(\n    descripcion,\n    um,\n    clave_actual,\n    perfiles,\n):\n    permitidos = candidatos_permitidos(\n        descripcion,\n        um,\n        clave_actual,\n        perfiles,\n    )\n\n    perfil_actual = perfiles.get(clave_actual)\n    resultados = []\n\n    for clave, perfil in permitidos.items():\n        datos = puntuar_perfil(descripcion, perfil)\n\n        if datos["score"] <= 0:\n            continue\n\n        pierde_esp, especializaciones_perdidas = candidato_pierde_especializacion(\n            descripcion,\n            perfil_actual,\n            perfil,\n        )\n\n        cambia_familia, familia_perdida = candidato_cambia_familia_respaldada(\n            descripcion,\n            perfil_actual,\n            perfil,\n        )\n\n        mas_generico, especializacion_funcional = candidato_es_mas_generico(\n            descripcion,\n            perfil_actual,\n            perfil,\n        )\n\n        score = datos["score"]\n\n        if clave != clave_actual and pierde_esp:\n            score *= 0.62\n            datos["evidencias"].append(\n                "PENALIZACION: pierde especializacion "\n                + ", ".join(especializaciones_perdidas)\n            )\n\n        if clave != clave_actual and cambia_familia:\n            score *= 0.58\n            datos["evidencias"].append(\n                "PENALIZACION: cambia familia tecnica respaldada "\n                + ", ".join(familia_perdida[:4])\n            )\n\n        if clave != clave_actual and mas_generico:\n            score *= 0.55\n            datos["evidencias"].append(\n                "PENALIZACION: pierde contexto especializado "\n                + ", ".join(especializacion_funcional)\n            )\n\n        if (\n            clave != clave_actual\n            and objeto_es_herramienta_o_accesorio_funcional(descripcion)\n            and datos["score_objeto"] < 0.62\n        ):\n            score *= 0.60\n            datos["evidencias"].append(\n                "PENALIZACION: termino tecnico pertenece al objeto de uso, "\n                "no necesariamente al articulo principal"\n            )\n\n        contexto_fuerte, senales_contexto = contexto_actual_fuerte(\n            descripcion,\n            clave_actual,\n        )\n\n        if clave != clave_actual and contexto_fuerte:\n            score *= 0.42\n            datos["evidencias"].append(\n                "PENALIZACION: contexto tecnico actual fuertemente respaldado"\n            )\n\n        if (\n            clave != clave_actual\n            and termino_candidato_es_unidad_o_atributo(\n                descripcion,\n                perfil,\n            )\n        ):\n            score *= 0.25\n            datos["evidencias"].append(\n                "PENALIZACION: candidato detectado como unidad, material "\n                "o atributo secundario"\n            )\n\n        resultados.append(\n            {\n                "clave": clave,\n                "perfil": perfil,\n                **datos,\n                "score": score,\n            }\n        )\n\n    resultados.sort(\n        key=lambda x: x["score"],\n        reverse=True,\n    )\n\n    return resultados\n\n\ndef evaluar_articulo(\n    descripcion,\n    grupo_actual,\n    subgrupo_actual,\n    um,\n    perfiles,\n    indice_historico,\n):\n    clave_actual = (\n        normalizar_clave(grupo_actual),\n        normalizar_clave(subgrupo_actual),\n    )\n\n    perfil_actual = perfiles.get(clave_actual)\n\n    hist = evaluar_evidencia_historica(\n        descripcion,\n        clave_actual,\n        indice_historico,\n    )\n\n    # --------------------------------------------------------\n    # REGLAS DE NEGOCIO DIRECTAS\n    # --------------------------------------------------------\n    clave_directa, evidencia_directa = regla_negocio_directa(\n        descripcion\n    )\n\n    if clave_directa:\n        perfil_directo = perfiles.get(clave_directa)\n\n        if perfil_directo:\n            nombre_directo = (\n                f\'{perfil_directo["nombre_grupo"]} / \'\n                f\'{perfil_directo["nombre_subgrupo"]}\'\n            )\n\n            if clave_actual == clave_directa:\n                return {\n                    "resultado": "COINCIDE",\n                    "observacion": "OK",\n                    "subobservacion": "OK",\n                    "score_actual": 1.0,\n                    "score_sugerido": 1.0,\n                    "grupo_sugerido": clave_directa[0],\n                    "subgrupo_sugerido": clave_directa[1],\n                    "nombre_sugerido": nombre_directo,\n                    "evidencia": evidencia_directa,\n                    "detalle": (\n                        "Regla directa de clasificación."\n                    ),\n                }\n\n            subobs = (\n                "GRUPO INCORRECTO"\n                if clave_actual[0] != clave_directa[0]\n                else "SUBGRUPO INCORRECTO"\n            )\n\n            return {\n                "resultado": "CLASIFICACION INCORRECTA",\n                "observacion": "CLASIFICACION",\n                "subobservacion": subobs,\n                "score_actual": 0.0,\n                "score_sugerido": 1.0,\n                "grupo_sugerido": clave_directa[0],\n                "subgrupo_sugerido": clave_directa[1],\n                "nombre_sugerido": nombre_directo,\n                "evidencia": evidencia_directa,\n                "detalle": (\n                    "Regla directa de clasificación."\n                ),\n            }\n\n    ranking = ranking_candidatos(\n        descripcion,\n        um,\n        clave_actual,\n        perfiles,\n    )\n\n    actual = next(\n        (\n            r for r in ranking\n            if r["clave"] == clave_actual\n        ),\n        None,\n    )\n\n    score_actual = actual["score"] if actual else 0.0\n\n    if not ranking:\n        respaldo_actual, evidencias_actual = evidencia_actual_suficiente(\n            descripcion,\n            perfil_actual,\n            clave_actual,\n        )\n\n        historico_confirma_actual = (\n            hist["actual_score"] >= HIST_CONSENSO_FUERTE\n            and hist["actual_count"] >= 1\n            and hist["neg_grupo_actual"] < 0.55\n            and hist["neg_subgrupo_actual"] < 0.55\n        )\n\n        if (respaldo_actual or historico_confirma_actual) and perfil_actual:\n            return {\n                "resultado": "COINCIDE",\n                "observacion": "OK",\n                "subobservacion": "OK",\n                "score_actual": 0.0,\n                "score_sugerido": 0.0,\n                "grupo_sugerido": clave_actual[0],\n                "subgrupo_sugerido": clave_actual[1],\n                "nombre_sugerido": (\n                    f\'{perfil_actual["nombre_grupo"]} / \'\n                    f\'{perfil_actual["nombre_subgrupo"]}\'\n                ),\n                "evidencia": "; ".join(\n                    evidencias_actual\n                    + ([hist["detalle"]] if hist["detalle"] else [])\n                ),\n                "detalle": (\n                    "No apareció una alternativa competitiva y la "\n                    "clasificación actual está respaldada por la "\n                    "descripción y/o antecedentes manualmente revisados."\n                ),\n            }\n\n        # Si no hay candidatos del catálogo/histórico suficientemente\n        # competitivos, no se considera un error: se conserva la\n        # clasificación actual, de acuerdo con la regla de negocio validada.\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": 0.0,\n            "score_sugerido": 0.0,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": hist["detalle"],\n            "detalle": (\n                "No se encontró evidencia suficiente de una clasificación "\n                "incorrecta. Se conserva y valida el Grupo/Subgrupo actual."\n            ),\n        }\n\n    mejor = ranking[0]\n    segundo = ranking[1] if len(ranking) > 1 else None\n\n    score_mejor = mejor["score"]\n    score_segundo = segundo["score"] if segundo else 0.0\n\n    grupo_sugerido, subgrupo_sugerido = mejor["clave"]\n    perfil_mejor = mejor["perfil"]\n\n    nombre_sugerido = (\n        f\'{perfil_mejor["nombre_grupo"]} / \'\n        f\'{perfil_mejor["nombre_subgrupo"]}\'\n    )\n\n    if mejor["clave"] == clave_actual:\n        respaldo_actual, evidencias_actual = evidencia_actual_suficiente(\n            descripcion,\n            perfil_actual,\n            clave_actual,\n        )\n\n        if (\n            score_mejor >= UMBRAL_REVISAR\n            or (\n                mejor["ancla"]\n                and score_mejor >= 0.20\n            )\n            or respaldo_actual\n            or (\n                hist["actual_score"] >= HIST_CONSENSO_FUERTE\n                and hist["neg_grupo_actual"] < 0.55\n                and hist["neg_subgrupo_actual"] < 0.55\n            )\n        ):\n            return {\n                "resultado": "COINCIDE",\n                "observacion": "OK",\n                "subobservacion": "OK",\n                "score_actual": score_actual,\n                "score_sugerido": score_mejor,\n                "grupo_sugerido": grupo_sugerido,\n                "subgrupo_sugerido": subgrupo_sugerido,\n                "nombre_sugerido": nombre_sugerido,\n                "evidencia": "; ".join(\n                    mejor["evidencias"]\n                    + evidencias_actual\n                    + ([hist["detalle"]] if hist["detalle"] else [])\n                ),\n                "detalle": (\n                    "La clasificación actual es la mejor respaldada "\n                    "por objeto, contexto, plantilla o familia técnica."\n                ),\n            }\n\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "La clasificación actual es la mejor disponible. "\n                "La evidencia limitada no constituye un conflicto real; "\n                "se conserva como correcta."\n            ),\n        }\n\n    diferencia = score_mejor - score_actual\n    margen = score_mejor - score_segundo\n\n    origen_generico = clave_actual in CLASIFICACIONES_GENERICAS\n\n    # --------------------------------------------------------\n    # EVIDENCIA HISTORICA CONSERVADORA\n    # --------------------------------------------------------\n    historico_actual_fuerte = (\n        hist["actual_score"] >= HIST_CONSENSO_FUERTE\n        and hist["actual_score"] >= hist["mejor_score"] - 0.05\n        and hist["neg_grupo_actual"] < 0.55\n        and hist["neg_subgrupo_actual"] < 0.55\n    )\n\n    historico_alternativa_fuerte = (\n        hist["mejor_clave"] is not None\n        and hist["mejor_clave"] != clave_actual\n        and hist["mejor_score"] >= HIST_CONSENSO_FUERTE\n        and (\n            hist["mejor_score"] - hist["actual_score"]\n            >= HIST_MARGEN_MINIMO\n        )\n        and (\n            hist["mejor_score"] - hist["segundo_score"]\n            >= 0.05\n        )\n    )\n\n    historico_actual_negativo = (\n        hist["neg_grupo_actual"] >= HIST_SIM_FUERTE\n        or hist["neg_subgrupo_actual"] >= HIST_SIM_FUERTE\n    )\n\n    if historico_actual_fuerte:\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": max(score_actual, hist["actual_score"]),\n            "score_sugerido": max(score_actual, hist["actual_score"]),\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": hist["detalle"],\n            "detalle": (\n                "Antecedentes manualmente revisados y suficientemente "\n                "similares respaldan la clasificación actual."\n            ),\n        }\n\n    # El histórico por sí solo no marca error salvo que, además de existir\n    # un consenso positivo para otra clasificación, existan antecedentes\n    # negativos parecidos contra la clasificación actual.\n    if (\n        historico_alternativa_fuerte\n        and historico_actual_negativo\n        and hist["mejor_count"] >= 1\n    ):\n        clave_hist = hist["mejor_clave"]\n        perfil_hist = perfiles.get(clave_hist)\n\n        if perfil_hist:\n            subobs_hist = (\n                "GRUPO INCORRECTO"\n                if clave_hist[0] != clave_actual[0]\n                else "SUBGRUPO INCORRECTO"\n            )\n\n            return {\n                "resultado": "CLASIFICACION INCORRECTA",\n                "observacion": "CLASIFICACION",\n                "subobservacion": subobs_hist,\n                "score_actual": score_actual,\n                "score_sugerido": hist["mejor_score"],\n                "grupo_sugerido": clave_hist[0],\n                "subgrupo_sugerido": clave_hist[1],\n                "nombre_sugerido": (\n                    f\'{perfil_hist["nombre_grupo"]} / \'\n                    f\'{perfil_hist["nombre_subgrupo"]}\'\n                ),\n                "evidencia": hist["detalle"],\n                "detalle": (\n                    "El histórico contiene antecedentes similares que "\n                    "respaldan otra clasificación y, simultáneamente, "\n                    "antecedentes que rechazan la clasificación actual."\n                ),\n            }\n\n    pierde_esp, perdidas = candidato_pierde_especializacion(\n        descripcion,\n        perfil_actual,\n        perfil_mejor,\n    )\n\n    cambia_familia, familia_perdida = candidato_cambia_familia_respaldada(\n        descripcion,\n        perfil_actual,\n        perfil_mejor,\n    )\n\n    mas_generico, contexto_perdido = candidato_es_mas_generico(\n        descripcion,\n        perfil_actual,\n        perfil_mejor,\n    )\n\n    if pierde_esp:\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "La alternativa perdería una especialización presente "\n                "en la descripción: "\n                + ", ".join(perdidas)\n                + ". Se conserva la clasificación actual."\n            ),\n        }\n\n    if cambia_familia or mas_generico:\n        motivos = []\n        if cambia_familia:\n            motivos.append(\n                "familia tecnica actual respaldada: "\n                + ", ".join(familia_perdida[:4])\n            )\n        if mas_generico:\n            motivos.append(\n                "especializacion actual: "\n                + ", ".join(contexto_perdido)\n            )\n\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "La alternativa coincide con parte del objeto, pero la "\n                "clasificación actual conserva contexto técnico relevante ("\n                + "; ".join(motivos)\n                + "). Se conserva como correcta."\n            ),\n        }\n\n    contexto_fuerte, senales_contexto = contexto_actual_fuerte(\n        descripcion,\n        clave_actual,\n    )\n\n    if contexto_fuerte:\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_mejor,\n            "grupo_sugerido": grupo_sugerido,\n            "subgrupo_sugerido": subgrupo_sugerido,\n            "nombre_sugerido": nombre_sugerido,\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "La clasificación actual contiene contexto técnico "\n                "específico respaldado por la descripción; la alternativa "\n                "detectada es más genérica y no sustituye esa especialización."\n            ),\n        }\n\n    if termino_candidato_es_unidad_o_atributo(\n        descripcion,\n        perfil_mejor,\n    ):\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "La alternativa se apoya en una unidad, material, "\n                "aplicación o atributo secundario y no en el artículo "\n                "principal. Se conserva la clasificación actual."\n            ),\n        }\n\n    fuerte_general = (\n        mejor["ancla"]\n        and mejor["score_objeto"] >= 0.48\n        and score_mejor >= UMBRAL_MARCAR\n        and diferencia >= MARGEN_MINIMO\n        and margen >= 0.10\n    )\n\n    fuerte_desde_generico = (\n        origen_generico\n        and mejor["ancla"]\n        and mejor["score_objeto"] >= 0.62\n        and score_mejor >= 0.68\n        and diferencia >= 0.18\n    )\n\n    es_fuerte = fuerte_general or fuerte_desde_generico\n\n    if es_fuerte:\n        subobs = (\n            "GRUPO INCORRECTO"\n            if grupo_sugerido != clave_actual[0]\n            else "SUBGRUPO INCORRECTO"\n        )\n\n        return {\n            "resultado": "CLASIFICACION INCORRECTA",\n            "observacion": "CLASIFICACION",\n            "subobservacion": subobs,\n            "score_actual": score_actual,\n            "score_sugerido": score_mejor,\n            "grupo_sugerido": grupo_sugerido,\n            "subgrupo_sugerido": subgrupo_sugerido,\n            "nombre_sugerido": nombre_sugerido,\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "La alternativa identifica claramente el objeto "\n                "principal y supera la clasificación actual sin "\n                "perder especialización relevante."\n            ),\n        }\n\n    if (\n        mejor["ancla"]\n        and mejor["score_objeto"] >= 0.48\n        and score_mejor >= UMBRAL_REVISAR\n    ):\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": "; ".join(mejor["evidencias"]),\n            "detalle": (\n                "Existe una alternativa plausible, pero no alcanza la "\n                "evidencia necesaria para desplazar la clasificación "\n                "actual. Se conserva como correcta."\n            ),\n        }\n\n    respaldo_actual, evidencias_actual = evidencia_actual_suficiente(\n        descripcion,\n        perfil_actual,\n        clave_actual,\n    )\n\n    if (\n        respaldo_actual\n        and (\n            not mejor["ancla"]\n            or mejor["score_objeto"] < 0.48\n            or score_mejor < UMBRAL_REVISAR\n        )\n    ):\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": "; ".join(evidencias_actual),\n            "detalle": (\n                "La clasificación actual está respaldada por la "\n                "descripción y no existe una alternativa suficientemente "\n                "fuerte para desplazarla."\n            ),\n        }\n\n    if (\n        hist["actual_score"] >= HIST_SIM_FUERTE\n        and hist["neg_grupo_actual"] < 0.55\n        and hist["neg_subgrupo_actual"] < 0.55\n        and perfil_actual\n    ):\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": max(score_actual, hist["actual_score"]),\n            "score_sugerido": max(score_actual, hist["actual_score"]),\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n            ),\n            "evidencia": hist["detalle"],\n            "detalle": (\n                "La evidencia técnica directa es limitada, pero existen "\n                "antecedentes manualmente revisados suficientemente "\n                "similares que respaldan la clasificación actual."\n            ),\n        }\n\n    if historico_alternativa_fuerte:\n        clave_hist = hist["mejor_clave"]\n        perfil_hist = perfiles.get(clave_hist)\n\n        return {\n            "resultado": "COINCIDE",\n            "observacion": "OK",\n            "subobservacion": "OK",\n            "score_actual": score_actual,\n            "score_sugerido": score_actual,\n            "grupo_sugerido": clave_actual[0],\n            "subgrupo_sugerido": clave_actual[1],\n            "nombre_sugerido": (\n                f\'{perfil_actual["nombre_grupo"]} / \'\n                f\'{perfil_actual["nombre_subgrupo"]}\'\n                if perfil_actual else ""\n            ),\n            "evidencia": hist["detalle"],\n            "detalle": (\n                "El histórico sugiere otra clasificación, pero no existe "\n                "evidencia negativa suficiente contra la clasificación "\n                "actual. Se conserva la clasificación actual."\n            ),\n        }\n\n    # REGLA DE NEGOCIO FINAL:\n    # Si no existe evidencia suficiente para afirmar que la clasificación\n    # actual es incorrecta ni un conflicto real que amerite REVISAR,\n    # se respeta el Grupo/Subgrupo asignado actualmente.\n    #\n    # En este módulo, la ausencia de evidencia de error NO significa\n    # "NO EVALUABLE"; significa que la clasificación actual se considera\n    # aceptable y pasa a COINCIDE.\n    return {\n        "resultado": "COINCIDE",\n        "observacion": "OK",\n        "subobservacion": "OK",\n        "score_actual": score_actual,\n        "score_sugerido": score_actual,\n        "grupo_sugerido": clave_actual[0],\n        "subgrupo_sugerido": clave_actual[1],\n        "nombre_sugerido": (\n            f\'{perfil_actual["nombre_grupo"]} / \'\n            f\'{perfil_actual["nombre_subgrupo"]}\'\n            if perfil_actual else ""\n        ),\n        "evidencia": hist["detalle"],\n        "detalle": (\n            "No se encontró evidencia suficiente de una clasificación "\n            "incorrecta. Se conserva y valida el Grupo/Subgrupo actual."\n        ),\n    }\n\n\ndef localizar_columnas(df):\n    mapa = {}\n\n    for col in df.columns:\n        mapa[normalizar(col)] = col\n\n    requeridas = [\n        "CODIGO",\n        "ESTADO",\n        "GRUPO",\n        "SUBGRUPO",\n        "DESCRIPCION",\n    ]\n\n    faltantes = [\n        c for c in requeridas\n        if c not in mapa\n    ]\n\n    if faltantes:\n        raise ValueError(\n            "Faltan columnas requeridas: "\n            + ", ".join(faltantes)\n        )\n\n    return mapa\n\n\ndef procesar():\n    entrada = buscar_archivo_resultado()\n    salida = nombre_salida(entrada)\n\n    print("=" * 78)\n    print("DIAGNOSTICO DE CLASIFICACION - CONTEXTUAL + HISTORICO V6.4")\n    print("=" * 78)\n    print(f"Entrada: {entrada}")\n    print(f"Base de datos: {DB_PATH}")\n    print()\n\n    catalogo, campos = cargar_catalogo()\n    perfiles = construir_perfiles(catalogo, campos)\n\n    historico = cargar_revisiones_historicas()\n    indice_historico = construir_indice_historico(historico)\n\n    print(f"Clasificaciones disponibles: {len(perfiles)}")\n    print(f"Revisiones historicas SQLite: {len(historico)}")\n    print(\n        "Excel historicos externos: NO SE CONSULTAN "\n        "(solo base_datos.db)"\n    )\n    print(\n        "Modelo: familia -> objeto principal -> especializacion -> caracteristicas"\n    )\n    print()\n\n    df = pd.read_excel(\n        entrada,\n        dtype=str,\n        engine="openpyxl",\n    )\n\n    mapa = localizar_columnas(df)\n\n    c_codigo = mapa["CODIGO"]\n    c_estado = mapa["ESTADO"]\n    c_grupo = mapa["GRUPO"]\n    c_subgrupo = mapa["SUBGRUPO"]\n    c_desc = mapa["DESCRIPCION"]\n    c_um = mapa.get("UM")\n\n    nuevos = df[\n        df[c_estado]\n        .astype(str)\n        .str.strip()\n        .str.upper()\n        .eq("NUEVO")\n    ].copy()\n\n    resultados = []\n\n    for _, fila in nuevos.iterrows():\n        codigo = normalizar_codigo(fila[c_codigo])\n        grupo = normalizar_clave(fila[c_grupo])\n        subgrupo = normalizar_clave(fila[c_subgrupo])\n\n        descripcion = (\n            ""\n            if pd.isna(fila[c_desc])\n            else str(fila[c_desc])\n        )\n\n        um = (\n            ""\n            if c_um is None or pd.isna(fila[c_um])\n            else str(fila[c_um])\n        )\n\n        evaluacion = evaluar_articulo(\n            descripcion,\n            grupo,\n            subgrupo,\n            um,\n            perfiles,\n            indice_historico,\n        )\n\n        perfil_actual = perfiles.get(\n            (grupo, subgrupo),\n            {},\n        )\n\n        hist_fila = evaluar_evidencia_historica(\n            descripcion,\n            (grupo, subgrupo),\n            indice_historico,\n        )\n\n        especializaciones = detectar_especializaciones(\n            descripcion\n        )\n\n        resultados.append(\n            {\n                "Codigo": codigo,\n                "Grupo actual": grupo,\n                "Subgrupo actual": subgrupo,\n                "Nombre grupo actual": perfil_actual.get(\n                    "nombre_grupo",\n                    "",\n                ),\n                "Nombre subgrupo actual": perfil_actual.get(\n                    "nombre_subgrupo",\n                    "",\n                ),\n                "UM": um,\n                "Objeto principal detectado": objeto_principal(\n                    descripcion\n                ),\n                "Especializaciones detectadas": ", ".join(\n                    especializaciones\n                ),\n                "Descripción": descripcion,\n                "Resultado": evaluacion["resultado"],\n                "Observación propuesta": evaluacion["observacion"],\n                "Subobservación propuesta": evaluacion["subobservacion"],\n                "Grupo sugerido": evaluacion["grupo_sugerido"],\n                "Subgrupo sugerido": evaluacion["subgrupo_sugerido"],\n                "Clasificación sugerida": evaluacion["nombre_sugerido"],\n                "Puntaje actual": round(\n                    evaluacion["score_actual"] * 100,\n                    1,\n                ),\n                "Puntaje sugerido": round(\n                    evaluacion["score_sugerido"] * 100,\n                    1,\n                ),\n                "Histórico respalda actual": round(\n                    hist_fila["actual_score"] * 100,\n                    1,\n                ),\n                "Mejor histórico": (\n                    (\n                        f\'{hist_fila["mejor_clave"][0]}/\'\n                        f\'{hist_fila["mejor_clave"][1]}\'\n                    )\n                    if hist_fila["mejor_clave"]\n                    else ""\n                ),\n                "Puntaje mejor histórico": round(\n                    hist_fila["mejor_score"] * 100,\n                    1,\n                ),\n                "Histórico contra grupo actual": round(\n                    hist_fila["neg_grupo_actual"] * 100,\n                    1,\n                ),\n                "Histórico contra subgrupo actual": round(\n                    hist_fila["neg_subgrupo_actual"] * 100,\n                    1,\n                ),\n                "Ejemplos históricos": (\n                    hist_fila.get("ejemplos_mejor_txt", "")\n                ),\n                "Evidencia": evaluacion["evidencia"],\n                "Detalle": evaluacion["detalle"],\n            }\n        )\n\n    resultado_df = pd.DataFrame(resultados)\n\n    incorrectos = resultado_df[\n        resultado_df["Resultado"]\n        .eq("CLASIFICACION INCORRECTA")\n    ].copy()\n\n    revisar = resultado_df[\n        resultado_df["Resultado"]\n        .eq("REVISAR")\n    ].copy()\n\n    coincide = resultado_df[\n        resultado_df["Resultado"]\n        .eq("COINCIDE")\n    ].copy()\n\n    no_evaluable = resultado_df[\n        resultado_df["Resultado"]\n        .eq("NO EVALUABLE")\n    ].copy()\n\n    conteos = Counter(\n        resultado_df["Resultado"]\n    )\n\n    grupo_incorrecto = int(\n        (\n            resultado_df["Subobservación propuesta"]\n            == "GRUPO INCORRECTO"\n        ).sum()\n    )\n\n    subgrupo_incorrecto = int(\n        (\n            resultado_df["Subobservación propuesta"]\n            == "SUBGRUPO INCORRECTO"\n        ).sum()\n    )\n\n    resumen_df = pd.DataFrame(\n        [\n            ["Articulos NUEVO analizados", len(resultado_df)],\n            [\n                "CLASIFICACION INCORRECTA",\n                conteos.get("CLASIFICACION INCORRECTA", 0),\n            ],\n            ["GRUPO INCORRECTO", grupo_incorrecto],\n            ["SUBGRUPO INCORRECTO", subgrupo_incorrecto],\n            ["COINCIDE", conteos.get("COINCIDE", 0)],\n            ["REVISAR", conteos.get("REVISAR", 0)],\n            ["NO EVALUABLE", conteos.get("NO EVALUABLE", 0)],\n        ],\n        columns=["Concepto", "Resultado"],\n    )\n\n    with pd.ExcelWriter(\n        salida,\n        engine="openpyxl",\n    ) as writer:\n        resumen_df.to_excel(\n            writer,\n            sheet_name="RESUMEN",\n            index=False,\n        )\n        incorrectos.to_excel(\n            writer,\n            sheet_name="CLASIFICACION INCORRECTA",\n            index=False,\n        )\n        revisar.to_excel(\n            writer,\n            sheet_name="REVISAR",\n            index=False,\n        )\n        coincide.to_excel(\n            writer,\n            sheet_name="COINCIDE",\n            index=False,\n        )\n        no_evaluable.to_excel(\n            writer,\n            sheet_name="NO EVALUABLE",\n            index=False,\n        )\n        resultado_df.to_excel(\n            writer,\n            sheet_name="DIAGNOSTICO",\n            index=False,\n        )\n\n        for hoja in writer.book.worksheets:\n            hoja.freeze_panes = "A2"\n            hoja.auto_filter.ref = hoja.dimensions\n\n            for columna in hoja.columns:\n                letra = columna[0].column_letter\n                max_len = 0\n\n                for celda in columna:\n                    valor = (\n                        ""\n                        if celda.value is None\n                        else str(celda.value)\n                    )\n                    max_len = max(\n                        max_len,\n                        min(len(valor), 80),\n                    )\n\n                hoja.column_dimensions[letra].width = max(\n                    12,\n                    min(max_len + 2, 60),\n                )\n\n    print("Diagnostico terminado correctamente.")\n    print("-" * 78)\n    print(\n        f"Articulos NUEVO analizados:          {len(resultado_df)}"\n    )\n    print(\n        "CLASIFICACION INCORRECTA:           "\n        f"{conteos.get(\'CLASIFICACION INCORRECTA\', 0)}"\n    )\n    print(\n        f"  - GRUPO INCORRECTO:                {grupo_incorrecto}"\n    )\n    print(\n        f"  - SUBGRUPO INCORRECTO:             {subgrupo_incorrecto}"\n    )\n    print(\n        "COINCIDE:                            "\n        f"{conteos.get(\'COINCIDE\', 0)}"\n    )\n    print(\n        "REVISAR:                             "\n        f"{conteos.get(\'REVISAR\', 0)}"\n    )\n    print(\n        "NO EVALUABLE:                        "\n        f"{conteos.get(\'NO EVALUABLE\', 0)}"\n    )\n    print()\n    print("Archivo generado:")\n    print(salida)\n    print("=" * 78)\n\n\nif __name__ == "__main__":\n    procesar()\n'

ORTO = preparar_modulo(_SOURCE_ORTOGRAFIA, "ortografia")
PLANT = preparar_modulo(_SOURCE_PLANTILLAS, "plantillas")
DUP = preparar_modulo(_SOURCE_DUPLICADOS, "duplicados")
RED = preparar_modulo(_SOURCE_REDACCION, "redaccion")
CLAS = preparar_modulo(_SOURCE_CLASIFICACION, "clasificacion")


# ============================================================
# LECTURA Y COLUMNAS
# ============================================================

def cargar_entrada(ruta_entrada, periodo, anio):
    entrada, hoja, df_original, mapa_original, periodo = cargar_archivo_mensual_original(ruta_entrada, periodo)
    df, mapa, nuevos_insertados = preparar_nuevos_desde_sqlite(df_original, mapa_original, periodo, anio)
    return entrada, hoja, df, mapa, periodo, nuevos_insertados


# ============================================================
# ORTOGRAFIA
# ============================================================

def ejecutar_ortografia(nuevos, mapa):
    resultados = []
    hallazgos = []

    c_codigo = mapa["CODIGO"]
    c_desc = mapa["DESCRIPCION"]

    for _, fila in nuevos.iterrows():
        codigo = normalizar_codigo_general(fila[c_codigo])
        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])

        duplicadas = ORTO["detectar_palabras_duplicadas"](descripcion)
        minusculas = ORTO["detectar_minusculas"](descripcion)
        invalidos = ORTO["detectar_caracteres_invalidos"](descripcion)
        missing = ORTO["detectar_missing_units"](descripcion)

        tipos = []

        if duplicadas:
            tipos.append("PALABRA DUPLICADA")
            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "ORTOGRAFIA",
                "Observacion": "ORTOGRAFIA",
                "Subobservacion": "PALABRA DUPLICADA",
                "Detalle": ", ".join(duplicadas),
                "Confiabilidad": 98.0,
            })

        if minusculas:
            tipos.append("USO DE MINUSCULAS")
            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "ORTOGRAFIA",
                "Observacion": "ORTOGRAFIA",
                "Subobservacion": "USO DE MINUSCULAS",
                "Detalle": ", ".join(minusculas),
                "Confiabilidad": 95.0,
            })

        if missing:
            tipos.append("FALTA DE CARACTERES DE UNIDADES DE MEDIDA")
            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "ORTOGRAFIA",
                "Observacion": "ORTOGRAFIA",
                "Subobservacion": "FALTA DE CARACTERES DE UNIDADES DE MEDIDA",
                "Detalle": ", ".join(missing),
                "Confiabilidad": 90.0,
            })

        if invalidos:
            tipos.append("USO INCORRECTO DE CARACTERES")
            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "ORTOGRAFIA",
                "Observacion": "ORTOGRAFIA",
                "Subobservacion": "USO INCORRECTO DE CARACTERES",
                "Detalle": ", ".join(invalidos),
                "Confiabilidad": 98.0,
            })

        resultados.append({
            "Codigo": codigo,
            "ORTOGRAFIA": "OK" if not tipos else "ERROR",
            "SUBOBSERVACIONES ORTOGRAFIA": " | ".join(tipos),
            "DETALLE ORTOGRAFIA": " | ".join(
                [
                    ("DUPLICADAS: " + ", ".join(duplicadas)) if duplicadas else "",
                    ("MINUSCULAS: " + ", ".join(minusculas)) if minusculas else "",
                    ("MISSING UNITS: " + ", ".join(missing)) if missing else "",
                    ("INVALIDOS: " + ", ".join(invalidos)) if invalidos else "",
                ]
            ).strip(" |"),
        })

    return pd.DataFrame(resultados), hallazgos


# ============================================================
# REDACCION INCORRECTA
# ============================================================

def ejecutar_redaccion(nuevos, mapa):
    RED["preparar_diccionario"]()
    diccionario = RED["cargar_diccionario"]()

    resultados = []
    hallazgos = []
    c_codigo = mapa["CODIGO"]
    c_desc = mapa["DESCRIPCION"]

    for _, fila in nuevos.iterrows():
        codigo = normalizar_codigo_general(fila[c_codigo])
        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])
        encontrados = RED["analizar_redaccion"](descripcion, diccionario)

        if encontrados:
            detalle = "; ".join(h["detalle"] for h in encontrados)
            correccion = "; ".join(h["correccion"] for h in encontrados)

            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "REDACCION",
                "Observacion": "ORTOGRAFIA",
                "Subobservacion": "REDACCION INCORRECTA",
                "Detalle": detalle,
                "Confiabilidad": 95.0,
            })
        else:
            detalle = ""
            correccion = ""

        resultados.append({
            "Codigo": codigo,
            "REDACCION": "ERROR" if encontrados else "OK",
            "DETALLE REDACCION": detalle,
            "CORRECCION SUGERIDA": correccion,
        })

    return pd.DataFrame(resultados), hallazgos


# ============================================================
# PLANTILLAS
# ============================================================

def ejecutar_plantillas(nuevos, mapa):
    conn = sqlite3.connect(DB_PATH)
    try:
        catalogo, campos = PLANT["cargar_plantillas"](conn)
    finally:
        conn.close()

    catalogo_idx = catalogo.set_index(["grupo", "subgrupo"])
    grupos_campos = {
        k: g.copy()
        for k, g in campos.groupby(["grupo", "subgrupo"], sort=False)
    }

    resultados = []
    hallazgos = []
    revisar = []

    c_codigo = mapa["CODIGO"]
    c_grupo = mapa["GRUPO"]
    c_subgrupo = mapa["SUBGRUPO"]
    c_desc = mapa["DESCRIPCION"]

    for _, fila in nuevos.iterrows():
        codigo = normalizar_codigo_general(fila[c_codigo])
        grupo = PLANT["codigo_2d"](fila[c_grupo])
        subgrupo = PLANT["codigo_2d"](fila[c_subgrupo])
        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])
        clave = (grupo, subgrupo)

        if clave not in catalogo_idx.index or clave not in grupos_campos:
            # La ausencia de plantilla NO obliga a revisión manual.
            # Plantillas solo genera desviaciones cuando existe evidencia
            # automática suficiente; de lo contrario queda neutral.
            resultados.append({
                "Codigo": codigo,
                "PLANTILLA": "OK",
                "SUBOBSERVACION PLANTILLA": "OK",
                "DETALLE PLANTILLA": "Sin plantilla evaluable; el modulo no genera REVISAR",
            })
            continue

        gcampos = grupos_campos[clave]
        campos_reales = gcampos[
            gcampos["tipo_elemento"] == "CAMPO"
        ]["elemento"].tolist()

        obligatorios = gcampos[
            (gcampos["tipo_elemento"] == "CAMPO")
            & (gcampos["obligatorio"] == 1)
        ]["elemento"].tolist()

        detectados = []
        faltantes = []
        no_evaluables = []

        for campo in obligatorios:
            estado, _ = PLANT["detectar_campo"](campo, descripcion)
            if estado == "DETECTADO":
                detectados.append(campo)
            elif estado == "FALTANTE":
                faltantes.append(campo)
            else:
                no_evaluables.append(campo)

        errores_llenado = PLANT["detectar_campo_mal_llenado"](
            descripcion, campos_reales
        )

        if errores_llenado:
            estado_final = "ERROR"
            subobs = "LLENADO INADECUADO DE PLANTILLA"
            detalle = "; ".join(errores_llenado)
            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "PLANTILLAS",
                "Observacion": "ESPECIFICACION TECNICA",
                "Subobservacion": subobs,
                "Detalle": detalle,
                "Confiabilidad": 95.0,
            })
        elif faltantes or no_evaluables:
            # SUB-ESPECIFICADO está completamente desactivado.
            # La ausencia de campos obligatorios NO genera desviación,
            # REVISAR ni hallazgo oficial.
            estado_final = "OK"
            subobs = "OK"
            partes = []
            if faltantes:
                partes.append(
                    "Campos sin evidencia ignorados por regla de negocio: "
                    + ", ".join(faltantes)
                )
            if no_evaluables:
                partes.append(
                    "Campos no evaluables ignorados: "
                    + ", ".join(no_evaluables)
                )
            detalle = "; ".join(partes) or "Sin error automatico"
        else:
            estado_final = "OK"
            subobs = "OK"
            detalle = "Todos los campos obligatorios evaluables fueron detectados"

        resultados.append({
            "Codigo": codigo,
            "PLANTILLA": estado_final,
            "SUBOBSERVACION PLANTILLA": subobs,
            "DETALLE PLANTILLA": detalle,
        })

    return pd.DataFrame(resultados), hallazgos, revisar


# ============================================================
# DUPLICADOS
# ============================================================

def ejecutar_duplicados(df):
    resultado, duplicados, total_nuevos, total_pares = DUP["detectar_duplicados"](df)

    hallazgos = []
    for _, fila in duplicados.iterrows():
        hallazgos.append({
            "Codigo": normalizar_codigo_general(fila["Codigo"]),
            "Modulo": "DUPLICADOS",
            "Observacion": "DUPLICADO",
            "Subobservacion": "ARTICULO DUPLICADO",
            "Detalle": (
                f'Duplica con codigo {fila["Código duplicado"]}. '
                f'{fila["Detalle"]}'
            ),
            "Confiabilidad": float(fila["Similitud %"]) if pd.notna(fila["Similitud %"]) else 0.0,
        })

    diagnostico = resultado.rename(columns={
        "Observación propuesta": "DUPLICADO",
        "Subobservación propuesta": "SUBOBSERVACION DUPLICADO",
        "Código duplicado": "CODIGO DUPLICADO",
        "Descripción duplicada": "DESCRIPCION DUPLICADA",
        "Similitud %": "SIMILITUD DUPLICADO %",
        "Detalle": "DETALLE DUPLICADO",
    })

    columnas = [
        "Codigo",
        "DUPLICADO",
        "SUBOBSERVACION DUPLICADO",
        "CODIGO DUPLICADO",
        "DESCRIPCION DUPLICADA",
        "SIMILITUD DUPLICADO %",
        "DETALLE DUPLICADO",
    ]
    diagnostico = diagnostico[[c for c in columnas if c in diagnostico.columns]]

    return diagnostico, hallazgos, total_nuevos, total_pares


# ============================================================
# CLASIFICACION
# ============================================================

def ejecutar_clasificacion(nuevos, mapa):
    catalogo, campos = CLAS["cargar_catalogo"]()
    perfiles = CLAS["construir_perfiles"](catalogo, campos)

    historico = CLAS["cargar_revisiones_historicas"]()
    indice_historico = CLAS["construir_indice_historico"](historico)

    resultados = []
    hallazgos = []
    revisar = []

    c_codigo = mapa["CODIGO"]
    c_grupo = mapa["GRUPO"]
    c_subgrupo = mapa["SUBGRUPO"]
    c_desc = mapa["DESCRIPCION"]
    c_um = mapa.get("UM")

    for _, fila in nuevos.iterrows():
        codigo = CLAS["normalizar_codigo"](fila[c_codigo])
        grupo = CLAS["normalizar_clave"](fila[c_grupo])
        subgrupo = CLAS["normalizar_clave"](fila[c_subgrupo])
        descripcion = "" if pd.isna(fila[c_desc]) else str(fila[c_desc])
        um = "" if c_um is None or pd.isna(fila[c_um]) else str(fila[c_um])

        evaluacion = CLAS["evaluar_articulo"](
            descripcion,
            grupo,
            subgrupo,
            um,
            perfiles,
            indice_historico,
        )

        hist = CLAS["evaluar_evidencia_historica"](
            descripcion,
            (grupo, subgrupo),
            indice_historico,
        )

        resultado = evaluacion["resultado"]
        observacion = evaluacion["observacion"]
        subobservacion = evaluacion["subobservacion"]

        if resultado == "CLASIFICACION INCORRECTA":
            hallazgos.append({
                "Codigo": codigo,
                "Modulo": "CLASIFICACION",
                "Observacion": "CLASIFICACION",
                "Subobservacion": subobservacion,
                "Detalle": evaluacion["detalle"],
                "Confiabilidad": round(
                    max(
                        float(evaluacion["score_sugerido"]) * 100,
                        float(hist["mejor_score"]) * 100,
                    ),
                    1,
                ),
            })
        elif resultado == "REVISAR":
            revisar.append({
                "Codigo": codigo,
                "Modulo": "CLASIFICACION",
                "Motivo": "REVISAR CLASIFICACION",
                "Detalle": evaluacion["detalle"],
            })

        resultados.append({
            "Codigo": codigo,
            "CLASIFICACION": resultado,
            "SUBOBSERVACION CLASIFICACION": subobservacion,
            "GRUPO SUGERIDO": evaluacion["grupo_sugerido"],
            "SUBGRUPO SUGERIDO": evaluacion["subgrupo_sugerido"],
            "CLASIFICACION SUGERIDA": evaluacion["nombre_sugerido"],
            "PUNTAJE ACTUAL": round(evaluacion["score_actual"] * 100, 1),
            "PUNTAJE SUGERIDO": round(evaluacion["score_sugerido"] * 100, 1),
            "HISTORICO RESPALDA ACTUAL": round(hist["actual_score"] * 100, 1),
            "MEJOR HISTORICO": (
                f'{hist["mejor_clave"][0]}/{hist["mejor_clave"][1]}'
                if hist["mejor_clave"] else ""
            ),
            "PUNTAJE MEJOR HISTORICO": round(hist["mejor_score"] * 100, 1),
            "DETALLE CLASIFICACION": evaluacion["detalle"],
        })

    return pd.DataFrame(resultados), hallazgos, revisar


# ============================================================
# CONSOLIDACION
# ============================================================

PRIORIDAD_HALLAZGOS = {
    ("CLASIFICACION", "GRUPO INCORRECTO"): 1,
    ("CLASIFICACION", "SUBGRUPO INCORRECTO"): 2,
    ("DUPLICADO", "ARTICULO DUPLICADO"): 3,
    ("ESPECIFICACION TECNICA", "LLENADO INADECUADO DE PLANTILLA"): 4,
    ("ORTOGRAFIA", "USO DE MINUSCULAS"): 6,
    ("ORTOGRAFIA", "USO INCORRECTO DE CARACTERES"): 7,
    ("ORTOGRAFIA", "PALABRA DUPLICADA"): 8,
    ("ORTOGRAFIA", "FALTA DE CARACTERES DE UNIDADES DE MEDIDA"): 9,
    ("ORTOGRAFIA", "REDACCION INCORRECTA"): 10,
}


def confianza_clasificacion_fila(fila):
    """
    Índice de respaldo del resultado de clasificación.
    No es una probabilidad estadística: combina el mejor puntaje técnico
    con el respaldo histórico disponible.
    """
    candidatos = []

    for columna in [
        "PUNTAJE SUGERIDO",
        "HISTORICO RESPALDA ACTUAL",
        "PUNTAJE MEJOR HISTORICO",
    ]:
        valor = fila.get(columna, 0)
        try:
            if pd.notna(valor):
                candidatos.append(float(valor))
        except (TypeError, ValueError):
            pass

    return round(max(candidatos), 1) if candidatos else 0.0


def consolidar_resultado(nuevos, mapa, diagnosticos, hallazgos, revisar):
    """
    Genera exclusivamente las columnas finales solicitadas:
    Codigo, Estado, Grupo, Subgrupo, Descripción, Usuario, Nombre de Usuario, UM,
    Observaciones, Subobservaciones, Detalle General,
    Clasificacion Sugerida y Porcentaje de Confiabilidad.

    Antes de conservar un REVISAR, aplica una segunda capa histórica
    conservadora basada en revisiones manuales anteriores.
    """

    motor_historico = MotorRevisionHistorica(DB_PATH)

    columnas_base = []
    claves_base = [
        "CODIGO",
        "ESTADO",
        "GRUPO",
        "SUBGRUPO",
        "DESCRIPCION",
        "USUARIO",
        "UM",
    ]

    for clave in claves_base:
        if clave in mapa:
            columnas_base.append(mapa[clave])

    final = nuevos[columnas_base].copy()

    # Estandarizar exactamente los nombres solicitados.
    renombres_base = {}
    for clave in claves_base:
        if clave in mapa and mapa[clave] in final.columns:
            nombre_final = {
                "CODIGO": "Codigo",
                "ESTADO": "Estado",
                "GRUPO": "Grupo",
                "SUBGRUPO": "Subgrupo",
                "DESCRIPCION": "Descripción",
                "USUARIO": "Usuario",
                "UM": "UM",
            }[clave]
            renombres_base[mapa[clave]] = nombre_final

    final.rename(columns=renombres_base, inplace=True)

    # Relacionar el número de usuario con su nombre almacenado en SQLite.
    mapa_usuarios = cargar_mapa_usuarios()
    final["Nombre de Usuario"] = (
        final["Usuario"]
        .map(normalizar_usuario)
        .map(mapa_usuarios)
        .fillna("")
    )

    final["__CODIGO_LLAVE"] = final["Codigo"].map(normalizar_codigo_general)

    # Solo necesitamos conservar del diagnóstico de clasificación
    # la clasificación sugerida y sus puntajes para calcular confianza.
    diag_clas = diagnosticos[-1].copy()

    if not diag_clas.empty:
        diag_clas["__CODIGO_CLAS"] = diag_clas["Codigo"].map(
            normalizar_codigo_general
        )

        columnas_clas = [
            "__CODIGO_CLAS",
            "CLASIFICACION SUGERIDA",
            "PUNTAJE SUGERIDO",
            "HISTORICO RESPALDA ACTUAL",
            "PUNTAJE MEJOR HISTORICO",
        ]

        columnas_clas = [
            c for c in columnas_clas
            if c in diag_clas.columns
        ]

        final = final.merge(
            diag_clas[columnas_clas],
            how="left",
            left_on="__CODIGO_LLAVE",
            right_on="__CODIGO_CLAS",
        )

        if "__CODIGO_CLAS" in final.columns:
            final.drop(columns=["__CODIGO_CLAS"], inplace=True)

    # Protección global: SUB-ESPECIFICADO está desactivado por decisión
    # de negocio. Aunque algún módulo antiguo llegara a generarlo, se descarta
    # antes de construir Observación, Subobservación y DETALLE GENERAL.
    hallazgos = [
        h for h in hallazgos
        if str(h.get("Subobservacion", "")).strip().upper() != "SUB-ESPECIFICADO"
    ]

    # Agrupar todos los hallazgos por código.
    por_codigo = defaultdict(list)
    for h in hallazgos:
        por_codigo[normalizar_codigo_general(h["Codigo"])].append(h)

    # Señales de incertidumbre generadas por los módulos.
    # Estas señales NO convierten automáticamente el artículo en REVISAR.
    # Solo se usan cuando no existe una observación oficial y tampoco
    # hay suficiente certeza para considerarlo OK.
    revisar_por_codigo = defaultdict(list)
    for r in revisar:
        revisar_por_codigo[
            normalizar_codigo_general(r["Codigo"])
        ].append(r)

    observaciones_finales = []
    subobservaciones_finales = []
    detalles_generales = []
    porcentajes_confianza = []

    for _, fila in final.iterrows():
        codigo = fila["__CODIGO_LLAVE"]
        lista = por_codigo.get(codigo, [])

        if lista:
            # Ordenar por la jerarquía oficial Observación + Subobservación.
            ordenados = sorted(
                lista,
                key=lambda h: PRIORIDAD_HALLAZGOS.get(
                    (
                        str(h.get("Observacion", "")).strip().upper(),
                        str(h.get("Subobservacion", "")).strip().upper(),
                    ),
                    999,
                ),
            )

            # Solo se asigna el hallazgo de MAYOR PRIORIDAD.
            principal = ordenados[0]

            observaciones_finales.append(
                principal["Observacion"]
            )
            subobservaciones_finales.append(
                principal["Subobservacion"]
            )

            # DETALLE GENERAL conserva todos los hallazgos encontrados,
            # aunque solo uno sea el asignado por jerarquía.
            detalles_generales.append(
                " || ".join(
                    f'{h["Observacion"]} / '
                    f'{h["Subobservacion"]}: '
                    f'{h["Detalle"]}'
                    for h in ordenados
                )
            )

            # La confiabilidad corresponde al hallazgo finalmente asignado.
            try:
                confianza_principal = float(
                    principal.get("Confiabilidad", 0)
                )
            except (TypeError, ValueError):
                confianza_principal = 0.0

            porcentajes_confianza.append(
                round(confianza_principal, 1)
            )

        else:
            # No existe ninguna de las 10 Observaciones/Subobservaciones
            # oficiales para este artículo.
            #
            # A partir de aquí solo quedan dos posibilidades:
            #   A) existe incertidumbre real -> REVISAR / REVISAR
            #   B) no existe incertidumbre -> OK / OK

            casos_revisar = revisar_por_codigo.get(codigo, [])

            if casos_revisar:
                # Segunda capa: consultar decisiones manuales históricas del
                # mismo Grupo/Subgrupo antes de mandar el caso a revisión.
                evidencia_historica = motor_historico.evaluar(
                    descripcion=fila.get("Descripción", ""),
                    grupo=fila.get("Grupo", ""),
                    subgrupo=fila.get("Subgrupo", ""),
                    casos_revisar=casos_revisar,
                )

                if evidencia_historica.get("resolver"):
                    observaciones_finales.append("OK")
                    subobservaciones_finales.append("OK")
                    detalles_generales.append(
                        "REVISION HISTORICA / OK: "
                        + evidencia_historica.get("detalle", "")
                    )
                    porcentajes_confianza.append(
                        float(evidencia_historica.get("confianza", 0.0))
                    )
                else:
                    # Si el histórico no es suficientemente fuerte o existe
                    # evidencia contradictoria, conservar REVISAR.
                    observaciones_finales.append("REVISAR")
                    subobservaciones_finales.append("REVISAR")

                    detalle_revisar = " || ".join(
                        f'{r["Modulo"]} / REVISAR: '
                        f'{r.get("Motivo", "")}. '
                        f'{r.get("Detalle", "")}'
                        for r in casos_revisar
                    )

                    detalle_hist = evidencia_historica.get("detalle", "")
                    if detalle_hist:
                        detalle_revisar += (
                            " || REVISION HISTORICA / SIN RESOLVER: "
                            + detalle_hist
                        )
                    detalles_generales.append(detalle_revisar)

                    # 0 indica que el sistema no tomó una decisión automática.
                    porcentajes_confianza.append(0.0)

            else:
                # Ninguna observación oficial fue detectada y ningún módulo
                # dejó incertidumbre pendiente: se considera OK / OK.
                observaciones_finales.append("OK")
                subobservaciones_finales.append("OK")
                detalles_generales.append("")

                confianza_ok = confianza_clasificacion_fila(fila)
                if confianza_ok <= 0:
                    confianza_ok = 90.0

                porcentajes_confianza.append(
                    round(min(95.0, confianza_ok), 1)
                )

    final["Observaciones"] = observaciones_finales
    final["Subobservaciones"] = subobservaciones_finales
    final["DETALLE GENERAL"] = detalles_generales

    if "CLASIFICACION SUGERIDA" in final.columns:
        final.rename(
            columns={
                "CLASIFICACION SUGERIDA": "Clasificacion Sugerida"
            },
            inplace=True,
        )
    else:
        final["Clasificacion Sugerida"] = ""

    # Mostrar la clasificación sugerida únicamente cuando el resultado
    # final requiera revisar la clasificación:
    #   - CLASIFICACION
    #   - REVISAR
    # Para ORTOGRAFIA, DUPLICADO, ESPECIFICACION TECNICA y OK se deja vacío.
    mostrar_clasificacion = final["Observaciones"].isin(
        ["CLASIFICACION", "REVISAR"]
    )
    final.loc[
        ~mostrar_clasificacion,
        "Clasificacion Sugerida"
    ] = ""

    final["PORCENTAJE DE CONFIABILIDAD"] = porcentajes_confianza

    columnas_finales = [
        "Codigo",
        "Estado",
        "Grupo",
        "Subgrupo",
        "Descripción",
        "Usuario",
        "Nombre de Usuario",
        "UM",
        "Observaciones",
        "Subobservaciones",
        "DETALLE GENERAL",
        "Clasificacion Sugerida",
        "PORCENTAJE DE CONFIABILIDAD",
    ]

    # Eliminar cualquier columna técnica que se haya usado para el cálculo.
    final = final[
        [c for c in columnas_finales if c in final.columns]
    ].copy()

    return final


def crear_resumen(final, hallazgos, revisar, total_pares):
    filas = [
        ["Articulos NUEVO analizados", len(final)],
        [
            "Articulos con resultado OK",
            int((final["Observaciones"] == "OK").sum()),
        ],
        [
            "Articulos con observacion asignada",
            int(
                (
                    (final["Observaciones"] != "OK")
                    & (final["Observaciones"] != "REVISAR")
                ).sum()
            ),
        ],
        [
            "Articulos marcados REVISAR",
            int((final["Observaciones"] == "REVISAR").sum()),
        ],
        [
            "REVISAR resueltos por historico",
            int(
                final["DETALLE GENERAL"]
                .fillna("")
                .astype(str)
                .str.startswith("REVISION HISTORICA / OK:")
                .sum()
            ),
        ],
        ["Pares candidatos de duplicados", total_pares],
        ["SOBRE-ESPECIFICADO", "NO CONFIGURADO"],
    ]

    for obs in [
        "CLASIFICACION",
        "DUPLICADO",
        "ESPECIFICACION TECNICA",
        "ORTOGRAFIA",
    ]:
        cantidad = sum(
            1 for h in hallazgos
            if h["Observacion"] == obs
        )
        filas.append(
            [f"Hallazgos - {obs}", cantidad]
        )

    subobs_oficiales = [
        "GRUPO INCORRECTO",
        "SUBGRUPO INCORRECTO",
        "ARTICULO DUPLICADO",
        "LLENADO INADECUADO DE PLANTILLA",
        "PALABRA DUPLICADA",
        "USO DE MINUSCULAS",
        "FALTA DE CARACTERES DE UNIDADES DE MEDIDA",
        "REDACCION INCORRECTA",
        "USO INCORRECTO DE CARACTERES",
    ]

    for sub in subobs_oficiales:
        cantidad = sum(
            1 for h in hallazgos
            if h["Subobservacion"] == sub
        )
        filas.append([sub, cantidad])

    return pd.DataFrame(
        filas,
        columns=["Indicador", "Cantidad"],
    )


# ============================================================
# EXCEL FINAL
# ============================================================

def ajustar_hojas(writer):
    for hoja in writer.book.worksheets:
        hoja.freeze_panes = "A2"
        hoja.auto_filter.ref = hoja.dimensions

        for columna in hoja.columns:
            letra = columna[0].column_letter
            max_len = 0
            for celda in list(columna)[:300]:
                valor = "" if celda.value is None else str(celda.value)
                max_len = max(max_len, min(len(valor), 80))
            hoja.column_dimensions[letra].width = max(
                12,
                min(max_len + 2, 60),
            )



# ============================================================
# REPORTE MENSUAL CON FORMATO HISTORICO
# ============================================================

PLANTILLA_REPORTE = os.path.join(BASE_DIR, "plantilla_reporte_mensual.xlsx")

MESES_TITULO = {
    "ENERO": "Enero",
    "FEBRERO": "Febrero",
    "MARZO": "Marzo",
    "ABRIL": "Abril",
    "MAYO": "Mayo",
    "JUNIO": "Junio",
    "JULIO": "Julio",
    "AGOSTO": "Agosto",
    "SEPTIEMBRE": "Septiembre",
    "OCTUBRE": "Octubre",
    "NOVIEMBRE": "Noviembre",
    "DICIEMBRE": "Diciembre",
}

# Valores validados de la hoja "Tablas Desviaciones-Mensual".
DATOS_MENSUALES_OFICIALES_2026 = {
    "ENERO":      {"codificaciones": 876,  "ORTOGRAFIA": 185, "ESPECIFICACION TECNICA": 20,  "DUPLICADO": 4,  "CLASIFICACION": 1},
    "FEBRERO":    {"codificaciones": 1885, "ORTOGRAFIA": 256, "ESPECIFICACION TECNICA": 30,  "DUPLICADO": 2,  "CLASIFICACION": 1},
    "MARZO":      {"codificaciones": 1480, "ORTOGRAFIA": 123, "ESPECIFICACION TECNICA": 168, "DUPLICADO": 21, "CLASIFICACION": 2},
    "ABRIL":      {"codificaciones": 1527, "ORTOGRAFIA": 194, "ESPECIFICACION TECNICA": 304, "DUPLICADO": 46, "CLASIFICACION": 11},
    "MAYO":       {"codificaciones": 1175, "ORTOGRAFIA": 110, "ESPECIFICACION TECNICA": 154, "DUPLICADO": 20, "CLASIFICACION": 8},
    "JUNIO":      {"codificaciones": 928,  "ORTOGRAFIA": 113, "ESPECIFICACION TECNICA": 133, "DUPLICADO": 10, "CLASIFICACION": 11},
    "JULIO":      {"codificaciones": 2108, "ORTOGRAFIA": 309, "ESPECIFICACION TECNICA": 231, "DUPLICADO": 32, "CLASIFICACION": 27},
    "AGOSTO":     {"codificaciones": 1693, "ORTOGRAFIA": 241, "ESPECIFICACION TECNICA": 46,  "DUPLICADO": 2,  "CLASIFICACION": 439},
}


def _normalizar_grupo_reporte(valor):
    texto = "" if pd.isna(valor) else str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    if texto.isdigit():
        texto = texto.zfill(2)
    return texto


def _copiar_estilo(celda_origen, celda_destino):
    if celda_origen.has_style:
        celda_destino._style = copy(celda_origen._style)
    if celda_origen.number_format:
        celda_destino.number_format = celda_origen.number_format
    celda_destino.alignment = copy(celda_origen.alignment)
    celda_destino.font = copy(celda_origen.font)
    celda_destino.fill = copy(celda_origen.fill)
    celda_destino.border = copy(celda_origen.border)


def _limpiar_valores(ws, min_row=1, max_row=None, min_col=1, max_col=None):
    max_row = max_row or ws.max_row
    max_col = max_col or ws.max_column
    for fila in ws.iter_rows(
        min_row=min_row,
        max_row=max_row,
        min_col=min_col,
        max_col=max_col,
    ):
        for celda in fila:
            celda.value = None


def _mapa_catalogo_reporte():
    if not os.path.exists(DB_PATH):
        return {}

    con = sqlite3.connect(DB_PATH)
    try:
        columnas = [
            r[1].lower()
            for r in con.execute("PRAGMA table_info(catalogo_subgrupos)").fetchall()
        ]
        if not {"grupo", "subgrupo"}.issubset(columnas):
            return {}

        campos = ["grupo", "subgrupo"]
        for opcional in ["nombre_grupo", "nombre_subgrupo"]:
            if opcional in columnas:
                campos.append(opcional)

        filas = con.execute(
            f"SELECT {', '.join(campos)} FROM catalogo_subgrupos"
        ).fetchall()
    except Exception:
        return {}
    finally:
        con.close()

    resultado = {}
    for fila in filas:
        grupo = _normalizar_grupo_reporte(fila[0])
        subgrupo = _normalizar_grupo_reporte(fila[1])
        nombre_grupo = str(fila[2] or "").strip() if len(fila) > 2 else ""
        nombre_subgrupo = str(fila[3] or "").strip() if len(fila) > 3 else ""
        resultado[(grupo, subgrupo)] = {
            "nombre_grupo": nombre_grupo,
            "nombre_subgrupo": nombre_subgrupo,
        }
    return resultado


def _preparar_articulos_reporte(final, nuevos, mapa):
    base = final.copy()
    catalogo = _mapa_catalogo_reporte()

    # Intentar recuperar datos originales por código cuando existan.
    originales = {}
    if "CODIGO" in mapa and mapa["CODIGO"] in nuevos.columns:
        for _, fila in nuevos.iterrows():
            codigo = normalizar_codigo_general(fila.get(mapa["CODIGO"], ""))
            if codigo and codigo not in originales:
                originales[codigo] = fila

    filas = []
    for _, fila in base.iterrows():
        codigo = normalizar_codigo_general(fila.get("Codigo", ""))
        grupo = _normalizar_grupo_reporte(fila.get("Grupo", ""))
        subgrupo = _normalizar_grupo_reporte(fila.get("Subgrupo", ""))

        origen = originales.get(codigo)
        nombre_grupo = ""
        nombre_subgrupo = ""
        clave = ""

        if origen is not None:
            for clave_origen, destino in [
                ("NOMBRE GRUPO", "nombre_grupo"),
                ("NOMBRE SUBGRUPO", "nombre_subgrupo"),
                ("CLAVE", "clave"),
            ]:
                col = mapa.get(clave_origen)
                valor = ""
                if col and col in origen.index:
                    valor = "" if pd.isna(origen[col]) else str(origen[col]).strip()
                if destino == "nombre_grupo":
                    nombre_grupo = valor
                elif destino == "nombre_subgrupo":
                    nombre_subgrupo = valor
                else:
                    clave = valor

        cat = catalogo.get((grupo, subgrupo), {})
        if not nombre_grupo:
            nombre_grupo = cat.get("nombre_grupo", "")
        if not nombre_subgrupo:
            nombre_subgrupo = cat.get("nombre_subgrupo", "")
        if not clave and grupo and subgrupo:
            clave = f"{grupo}-{subgrupo}"

        filas.append({
            "Codigo": codigo,
            "Grupo": grupo,
            "Nombre Grupo": nombre_grupo,
            "Subgrupo": subgrupo,
            "Nombre Subgrupo": nombre_subgrupo,
            "Clave": clave,
            "Descripción": fila.get("Descripción", ""),
            "Usuario": normalizar_usuario(fila.get("Usuario", "")),
            "Nombre de Usuario": fila.get("Nombre de Usuario", ""),
            "UM": fila.get("UM", ""),
            "Observación": fila.get("Observaciones", ""),
            "Subobservación": fila.get("Subobservaciones", ""),
            "DETALLE GENERAL": fila.get("DETALLE GENERAL", ""),
            "Clasificacion Sugerida": fila.get("Clasificacion Sugerida", ""),
        })

    columnas = [
        "Codigo",
        "Grupo",
        "Nombre Grupo",
        "Subgrupo",
        "Nombre Subgrupo",
        "Clave",
        "Descripción",
        "Usuario",
        "Nombre de Usuario",
        "UM",
        "Observación",
        "Subobservación",
        "DETALLE GENERAL",
        "Clasificacion Sugerida",
    ]
    return pd.DataFrame(filas, columns=columnas)


def _metricas_dataframe_reporte(df):
    if df is None or df.empty:
        return {
            "codificaciones": 0,
            "ORTOGRAFIA": 0,
            "ESPECIFICACION TECNICA": 0,
            "DUPLICADO": 0,
            "CLASIFICACION": 0,
        }

    col_obs = None
    for candidata in ["Observación", "Observaciones"]:
        if candidata in df.columns:
            col_obs = candidata
            break

    if col_obs is None:
        return {
            "codificaciones": len(df),
            "ORTOGRAFIA": 0,
            "ESPECIFICACION TECNICA": 0,
            "DUPLICADO": 0,
            "CLASIFICACION": 0,
        }

    obs = df[col_obs].fillna("").astype(str).str.strip().str.upper()
    return {
        "codificaciones": len(df),
        "ORTOGRAFIA": int(obs.eq("ORTOGRAFIA").sum()),
        "ESPECIFICACION TECNICA": int(obs.eq("ESPECIFICACION TECNICA").sum()),
        "DUPLICADO": int(obs.eq("DUPLICADO").sum()),
        "CLASIFICACION": int(obs.eq("CLASIFICACION").sum()),
    }


def _leer_articulos_revision(ruta):
    for hoja in ["Artículos", "REVISION_FINAL"]:
        try:
            df = pd.read_excel(
                ruta,
                sheet_name=hoja,
                dtype=str,
                engine="openpyxl",
            )
            if hoja == "Artículos":
                ren = {}
                if "Observación" in df.columns:
                    ren["Observación"] = "Observaciones"
                if "Subobservación" in df.columns:
                    ren["Subobservación"] = "Subobservaciones"
                if ren:
                    df.rename(columns=ren, inplace=True)
            return df
        except Exception:
            continue
    return pd.DataFrame()


def _datos_mensuales_reporte(periodo_actual, final_actual, salida_actual):
    datos = {
        mes: dict(valores)
        for mes, valores in DATOS_MENSUALES_OFICIALES_2026.items()
    }

    # Incorporar revisiones integradas posteriores a agosto ya existentes.
    for ruta in glob.glob(os.path.join(REVISIONES_DIR, "REVISION_INTEGRADA_*.xlsx")):
        if os.path.abspath(ruta) == os.path.abspath(salida_actual):
            continue
        nombre = normalizar_periodo(os.path.basename(ruta))
        mes = next((m for m in MESES if m in nombre), "")
        if not mes or MESES.index(mes) <= MESES.index("AGOSTO"):
            continue
        df = _leer_articulos_revision(ruta)
        if not df.empty:
            datos[mes] = _metricas_dataframe_reporte(df)

    datos[periodo_actual] = _metricas_dataframe_reporte(final_actual)

    limite = MESES.index(periodo_actual)
    return {
        mes: datos[mes]
        for mes in MESES[: limite + 1]
        if mes in datos
    }


def _top_usuarios_df(df, n=5):
    if df is None or df.empty or "Usuario" not in df.columns:
        return []

    col_obs = "Observaciones" if "Observaciones" in df.columns else "Observación"
    if col_obs not in df.columns:
        return []

    obs = df[col_obs].fillna("").astype(str).str.strip().str.upper()
    mascara = obs.isin(
        ["ORTOGRAFIA", "ESPECIFICACION TECNICA", "DUPLICADO", "CLASIFICACION"]
    )
    trabajo = df.loc[mascara].copy()
    trabajo["__usuario"] = trabajo["Usuario"].map(normalizar_usuario)
    trabajo = trabajo[trabajo["__usuario"].ne("")]

    nombres = {}
    if "Nombre de Usuario" in trabajo.columns:
        for u, nom in zip(
            trabajo["__usuario"],
            trabajo["Nombre de Usuario"].fillna("").astype(str),
        ):
            if u and str(nom).strip() and u not in nombres:
                nombres[u] = str(nom).strip()

    conteo = trabajo["__usuario"].value_counts().head(n)
    return [
        {
            "usuario": str(u),
            "nombre": nombres.get(str(u), ""),
            "desviaciones": int(c),
        }
        for u, c in conteo.items()
    ]


def _top_usuarios_historicos(periodo_actual, final_actual, salida_actual):
    por_mes = {}

    if os.path.exists(DB_PATH):
        con = sqlite3.connect(DB_PATH)
        try:
            existe = con.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='revisiones_historicas'"
            ).fetchone()
            if existe:
                filas = con.execute(
                    """
                    SELECT
                        UPPER(TRIM(COALESCE(mes,''))) AS mes,
                        usuario,
                        MAX(COALESCE(nombre_usuario,'')) AS nombre,
                        COUNT(*) AS cantidad
                    FROM revisiones_historicas
                    WHERE anio = 2026
                      AND UPPER(TRIM(COALESCE(observacion,''))) IN (
                        'ORTOGRAFIA',
                        'ESPECIFICACION TECNICA',
                        'DUPLICADO',
                        'CLASIFICACION'
                      )
                    GROUP BY UPPER(TRIM(COALESCE(mes,''))), usuario
                    """
                ).fetchall()

                agrupado = defaultdict(list)
                for mes, usuario, nombre, cantidad in filas:
                    if mes in MESES and usuario:
                        agrupado[mes].append({
                            "usuario": normalizar_usuario(usuario),
                            "nombre": str(nombre or "").strip(),
                            "desviaciones": int(cantidad or 0),
                        })
                for mes, items in agrupado.items():
                    por_mes[mes] = sorted(
                        items,
                        key=lambda x: (-x["desviaciones"], x["usuario"]),
                    )[:5]
        except Exception:
            pass
        finally:
            con.close()

    # Revisiones integradas de meses posteriores sustituyen al histórico.
    for ruta in glob.glob(os.path.join(REVISIONES_DIR, "REVISION_INTEGRADA_*.xlsx")):
        if os.path.abspath(ruta) == os.path.abspath(salida_actual):
            continue
        nombre = normalizar_periodo(os.path.basename(ruta))
        mes = next((m for m in MESES if m in nombre), "")
        if not mes:
            continue
        df = _leer_articulos_revision(ruta)
        if not df.empty:
            por_mes[mes] = _top_usuarios_df(df)

    por_mes[periodo_actual] = _top_usuarios_df(final_actual)

    limite = MESES.index(periodo_actual)
    resultado = []
    for mes in MESES[: limite + 1]:
        for item in por_mes.get(mes, [])[:5]:
            resultado.append({
                "mes": MESES_TITULO[mes],
                **item,
            })
    return resultado


def _escribir_dataframe_en_hoja(ws, df, fila_inicio=1, col_inicio=1):
    for j, nombre in enumerate(df.columns, start=col_inicio):
        ws.cell(fila_inicio, j, nombre)

    for i, fila in enumerate(df.itertuples(index=False, name=None), start=fila_inicio + 1):
        for j, valor in enumerate(fila, start=col_inicio):
            if pd.isna(valor):
                valor = ""
            ws.cell(i, j, valor)


def _preparar_hoja_articulos(wb, articulos):
    ws = wb["Artículos"]

    # Eliminar F1, F2, F3...F24 del archivo histórico.
    encabezados = {
        str(ws.cell(1, c).value or "").strip(): c
        for c in range(1, ws.max_column + 1)
    }
    columnas_f = [
        c for nombre, c in encabezados.items()
        if re.fullmatch(r"F\d+", nombre.upper())
    ]
    for c in sorted(columnas_f, reverse=True):
        ws.delete_cols(c, 1)

    # Limpiar datos existentes y dejar la estructura/estilo de la plantilla.
    if ws.max_row > 1:
        _limpiar_valores(ws, min_row=2, max_row=ws.max_row, min_col=1, max_col=max(ws.max_column, 16))

    # Cabeceras definitivas.
    for c, nombre in enumerate(articulos.columns, start=1):
        destino = ws.cell(1, c)
        # Copiar estilo del encabezado anterior más cercano si se agregan columnas nuevas.
        if c > ws.max_column:
            _copiar_estilo(ws.cell(1, max(1, c - 1)), destino)
        destino.value = nombre

    # Borrar cualquier encabezado residual a la derecha.
    for c in range(len(articulos.columns) + 1, ws.max_column + 1):
        ws.cell(1, c).value = None

    # Cargar filas.
    for r_idx, fila in enumerate(
        articulos.itertuples(index=False, name=None),
        start=2,
    ):
        for c_idx, valor in enumerate(fila, start=1):
            celda = ws.cell(r_idx, c_idx)
            if r_idx > 2:
                _copiar_estilo(ws.cell(2, min(c_idx, max(1, ws.max_column))), celda)
            celda.value = "" if pd.isna(valor) else valor

    # Formatos.
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:N{max(2, len(articulos) + 1)}"

    anchos = {
        "A": 13, "B": 8, "C": 28, "D": 10, "E": 32, "F": 12,
        "G": 70, "H": 13, "I": 34, "J": 9, "K": 23, "L": 34,
        "M": 70, "N": 35,
    }
    for letra, ancho in anchos.items():
        ws.column_dimensions[letra].width = ancho

    # DETALLE GENERAL y Clasificacion Sugerida deben verse como columnas
    # normales de la misma tabla: mismo encabezado, bordes, fuente,
    # alineación y ajuste de texto que Observación/Subobservación.
    if ws.max_column >= 14:
        _copiar_estilo(ws["L1"], ws["M1"])
        _copiar_estilo(ws["L1"], ws["N1"])

    for r in range(2, len(articulos) + 2):
        ws.cell(r, 7).alignment = Alignment(wrap_text=True, vertical="top")

        # Copiar exactamente el estilo de Subobservación a las dos columnas
        # añadidas del análisis integrado.
        _copiar_estilo(ws.cell(r, 12), ws.cell(r, 13))
        _copiar_estilo(ws.cell(r, 12), ws.cell(r, 14))
        ws.cell(r, 13).alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )
        ws.cell(r, 14).alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )

    # Eliminar físicamente las filas sobrantes que venían de la plantilla
    # (por ejemplo, las 1,693 filas de agosto) para que cada reporte mensual
    # contenga únicamente los artículos reales del mes procesado.
    ultima_fila_datos = len(articulos) + 1
    if ws.max_row > ultima_fila_datos:
        ws.delete_rows(
            ultima_fila_datos + 1,
            ws.max_row - ultima_fila_datos,
        )


def _preparar_analisis_desviaciones(wb, articulos, periodo):
    ws = wb["Análisis de desviaciones"]
    _limpiar_valores(ws, min_row=1, max_row=max(ws.max_row, 60), min_col=1, max_col=16)

    obs = articulos["Observación"].fillna("").astype(str).str.strip().str.upper()
    oficiales = ["ORTOGRAFIA", "ESPECIFICACION TECNICA", "DUPLICADO", "CLASIFICACION"]

    ws["A3"] = "Observación"
    ws["B3"] = "Cantidad"
    fila = 4
    total_desv = 0
    for categoria in oficiales:
        cantidad = int(obs.eq(categoria).sum())
        total_desv += cantidad
        ws.cell(fila, 1, categoria.title())
        ws.cell(fila, 2, cantidad)
        fila += 1

    ws.cell(fila, 1, "Total general")
    ws.cell(fila, 2, total_desv)

    sub = (
        articulos.loc[obs.isin(oficiales), "Subobservación"]
        .fillna("")
        .astype(str)
        .str.strip()
    )
    conteo_sub = sub[sub.ne("")].value_counts()

    ws["D3"] = "Subobservación"
    ws["E3"] = "Cantidad"
    for i, (nombre, cantidad) in enumerate(conteo_sub.items(), start=4):
        ws.cell(i, 4, nombre)
        ws.cell(i, 5, int(cantidad))

    total = len(articulos)
    porcentaje = (total_desv / total) if total else 0
    ws["M4"] = (
        f"De las {total:,} codificaciones del mes de "
        f"{MESES_TITULO.get(periodo, periodo).lower()}, "
        f"el {porcentaje:.0%} presentó desviaciones"
    )
    ws["M4"].alignment = Alignment(wrap_text=True)

    # Aplicar tonos verdes equivalentes al formato del reporte.
    fill = PatternFill("solid", fgColor="548235")
    font = Font(color="FFFFFF", bold=True)
    for rng in ["A3:B3", "D3:E3"]:
        for row in ws[rng]:
            for cell in row:
                cell.fill = fill
                cell.font = font


def _preparar_distribucion(wb, articulos):
    ws = wb["Distribución de desviaciones"]
    _limpiar_valores(ws, min_row=1, max_row=max(ws.max_row, 100), min_col=1, max_col=15)

    usuarios = articulos["Usuario"].fillna("").astype(str).map(normalizar_usuario)
    nombres = articulos["Nombre de Usuario"].fillna("").astype(str)
    obs = articulos["Observación"].fillna("").astype(str).str.strip().str.upper()

    categorias = ["ORTOGRAFIA", "ESPECIFICACION TECNICA", "CLASIFICACION", "DUPLICADO"]
    filas = []
    for usuario in sorted({u for u in usuarios if u}):
        mask_u = usuarios.eq(usuario)
        nombre = next((n for n in nombres[mask_u].tolist() if str(n).strip()), "")
        valores = {cat: int((mask_u & obs.eq(cat)).sum()) for cat in categorias}
        total = sum(valores.values())
        if total:
            filas.append((usuario, nombre, valores, total))
    filas.sort(key=lambda x: (-x[3], x[0]))

    headers = [
        "#", "Usuario", "Nombre de Usuario", "ORTOGRAFIA",
        "ESPECIFICACION TECNICA", "CLASIFICACION", "DUPLICADO",
        "Total general", "PORCENTAJE",
    ]
    for c, h in enumerate(headers, 1):
        ws.cell(1, c, h)

    total_desv = sum(x[3] for x in filas)
    for i, (usuario, nombre, valores, total) in enumerate(filas, start=1):
        r = i + 1
        ws.cell(r, 1, i)
        ws.cell(r, 2, usuario)
        ws.cell(r, 3, nombre)
        ws.cell(r, 4, valores["ORTOGRAFIA"])
        ws.cell(r, 5, valores["ESPECIFICACION TECNICA"])
        ws.cell(r, 6, valores["CLASIFICACION"])
        ws.cell(r, 7, valores["DUPLICADO"])
        ws.cell(r, 8, total)
        ws.cell(r, 9, total / total_desv if total_desv else 0)
        ws.cell(r, 9).number_format = "0%"

    ws["K1"] = "USUARIO"
    ws["L1"] = "CANT. DESVIACIONES"
    for i, fila in enumerate(filas[:5], start=2):
        ws.cell(i, 11, fila[0])
        ws.cell(i, 12, fila[3])
    ws.cell(7, 11, "TOTAL")
    ws.cell(7, 12, sum(f[3] for f in filas[:5]))
    ws.cell(8, 11, "PORCENTAJE")
    ws.cell(8, 12, (sum(f[3] for f in filas[:5]) / total_desv) if total_desv else 0)
    ws.cell(8, 12).number_format = "0%"

    usuarios_general = len({u for u in usuarios if u})
    usuarios_desv = len(filas)
    ws["N1"] = "USUARIOS"
    ws["O1"] = "TOTAL"
    ws["N2"] = "GENERAL"
    ws["O2"] = usuarios_general
    ws["N3"] = "CON DESVIACIONES"
    ws["O3"] = usuarios_desv
    ws["N4"] = "% CON DESVIACIONES"
    ws["O4"] = usuarios_desv / usuarios_general if usuarios_general else 0
    ws["O4"].number_format = "0%"

    verde = PatternFill("solid", fgColor="548235")
    blanco = Font(color="FFFFFF", bold=True)
    for rango in ["A1:I1", "K1:L1", "N1:O1"]:
        for row in ws[rango]:
            for cell in row:
                cell.fill = verde
                cell.font = blanco


def _preparar_codigos_usuario(wb, articulos):
    ws = wb["Códigos por usuario"]
    _limpiar_valores(ws, min_row=1, max_row=max(ws.max_row, 30), min_col=1, max_col=9)

    usuarios = articulos["Usuario"].fillna("").astype(str).map(normalizar_usuario)
    nombres = articulos["Nombre de Usuario"].fillna("").astype(str)
    obs = articulos["Observación"].fillna("").astype(str).str.strip().str.upper()
    mascara = obs.isin(["ORTOGRAFIA", "ESPECIFICACION TECNICA", "DUPLICADO", "CLASIFICACION"])
    conteo = usuarios[mascara & usuarios.ne("")].value_counts().head(5)

    headers = [
        "#", "USUARIO", "NOMBRE DE USUARIO", "TOTAL C/ERROR",
        "TOTAL S/ERROR", "TOTAL GENERADOS", "PORCENTAJE C/ERROR",
        "PORCENTAJE S/ERROR",
    ]
    for c, h in enumerate(headers, 1):
        ws.cell(3, c, h)

    for pos, (usuario, total_error) in enumerate(conteo.items(), start=1):
        r = pos + 3
        mask_u = usuarios.eq(usuario)
        nombre = next((n for n in nombres[mask_u].tolist() if str(n).strip()), "")
        total_generados = int(mask_u.sum())
        total_error = int(total_error)
        total_sin_error = max(total_generados - total_error, 0)

        valores = [
            pos, usuario, nombre, total_error, total_sin_error, total_generados,
            total_error / total_generados if total_generados else 0,
            total_sin_error / total_generados if total_generados else 0,
        ]
        for c, valor in enumerate(valores, 1):
            ws.cell(r, c, valor)
        ws.cell(r, 7).number_format = "0%"
        ws.cell(r, 8).number_format = "0%"

    verde = PatternFill("solid", fgColor="548235")
    blanco = Font(color="FFFFFF", bold=True)
    for cell in ws[3][:8]:
        cell.fill = verde
        cell.font = blanco


def _preparar_tablas_mensuales(wb, datos_mensuales, periodo):
    ws = wb["Tablas Desviaciones-Mensual"]
    _limpiar_valores(ws, min_row=1, max_row=max(ws.max_row, 30), min_col=1, max_col=18)

    meses = [m for m in MESES if m in datos_mensuales]
    col_total = len(meses) + 2

    ws["A1"] = f"Al corte de {MESES_TITULO.get(periodo, periodo)} 2026"

    ws.cell(3, 1, "Mes")
    for i, mes in enumerate(meses, start=2):
        ws.cell(3, i, MESES_TITULO[mes])
    ws.cell(3, col_total, "Total Gral")

    ws.cell(4, 1, "Codificaciones")
    ws.cell(5, 1, "Desviaciones")
    ws.cell(6, 1, "Porcentaje")

    total_cod = 0
    total_desv = 0
    for i, mes in enumerate(meses, start=2):
        d = datos_mensuales[mes]
        desv = sum(d.get(cat, 0) for cat in [
            "ORTOGRAFIA", "ESPECIFICACION TECNICA", "DUPLICADO", "CLASIFICACION"
        ])
        cod = int(d.get("codificaciones", 0))
        total_cod += cod
        total_desv += desv
        ws.cell(4, i, cod)
        ws.cell(5, i, desv)
        ws.cell(6, i, desv / cod if cod else 0)
        ws.cell(6, i).number_format = "0%"

    ws.cell(4, col_total, total_cod)
    ws.cell(5, col_total, total_desv)
    ws.cell(6, col_total, total_desv / total_cod if total_cod else 0)
    ws.cell(6, col_total).number_format = "0%"

    actual = datos_mensuales.get(periodo, {})
    actual_cod = int(actual.get("codificaciones", 0))
    actual_desv = sum(actual.get(cat, 0) for cat in [
        "ORTOGRAFIA", "ESPECIFICACION TECNICA", "DUPLICADO", "CLASIFICACION"
    ])
    actual_pct = actual_desv / actual_cod if actual_cod else 0
    ws["A8"] = (
        f"De las {actual_cod:,} codificaciones del mes de "
        f"{MESES_TITULO.get(periodo, periodo).lower()}, "
        f"el {actual_pct:.0%} presentó desviaciones, de las cuales:"
    )

    ws.cell(10, 1, "Tipo de desviación")
    for i, mes in enumerate(meses, start=2):
        ws.cell(10, i, MESES_TITULO[mes])
    ws.cell(10, col_total, "Total")
    ws.cell(10, col_total + 1, "Porcentaje")

    filas = [
        ("Ortografía", "ORTOGRAFIA"),
        ("Especificación Técnica", "ESPECIFICACION TECNICA"),
        ("Duplicado", "DUPLICADO"),
        ("Clasificación", "CLASIFICACION"),
    ]

    for r, (etiqueta, clave) in enumerate(filas, start=11):
        ws.cell(r, 1, etiqueta)
        total_fila = 0
        for i, mes in enumerate(meses, start=2):
            valor = int(datos_mensuales[mes].get(clave, 0))
            ws.cell(r, i, valor)
            total_fila += valor
        ws.cell(r, col_total, total_fila)
        ws.cell(r, col_total + 1, total_fila / total_desv if total_desv else 0)
        ws.cell(r, col_total + 1).number_format = "0%"

    r_total = 15
    ws.cell(r_total, 1, "Total Gral Desviaciones")
    for i, mes in enumerate(meses, start=2):
        d = datos_mensuales[mes]
        valor = sum(int(d.get(cat, 0)) for cat in [
            "ORTOGRAFIA", "ESPECIFICACION TECNICA", "DUPLICADO", "CLASIFICACION"
        ])
        ws.cell(r_total, i, valor)
    ws.cell(r_total, col_total, total_desv)
    ws.cell(r_total, col_total + 1, 1)
    ws.cell(r_total, col_total + 1).number_format = "0%"

    verde = PatternFill("solid", fgColor="548235")
    blanco = Font(color="FFFFFF", bold=True)
    for fila_header in [3, 10]:
        for c in range(1, col_total + (2 if fila_header == 10 else 1)):
            ws.cell(fila_header, c).fill = verde
            ws.cell(fila_header, c).font = blanco

    ws["A8"].font = Font(bold=True)
    ws.freeze_panes = "B3"


def _preparar_grafica_mensual(wb, datos_mensuales):
    ws = wb["Gráfica desviaciones-Mensual"]
    _limpiar_valores(ws, min_row=1, max_row=max(ws.max_row, 20), min_col=1, max_col=18)

    try:
        ws._charts = []
    except Exception:
        pass

    meses = [m for m in MESES if m in datos_mensuales]
    ws.cell(6, 1, "Etiquetas de fila")
    for i, mes in enumerate(meses, start=2):
        ws.cell(6, i, f"Suma de {MESES_TITULO[mes]}")

    filas = [
        ("Clasificación", "CLASIFICACION"),
        ("Duplicado", "DUPLICADO"),
        ("Especificación Técnica", "ESPECIFICACION TECNICA"),
        ("Ortografía", "ORTOGRAFIA"),
    ]
    for r, (etiqueta, clave) in enumerate(filas, start=7):
        ws.cell(r, 1, etiqueta)
        for c, mes in enumerate(meses, start=2):
            ws.cell(r, c, int(datos_mensuales[mes].get(clave, 0)))

    # Gráfica de columnas agrupadas, manteniendo la identidad verde del archivo.
    chart = BarChart()
    chart.type = "col"
    chart.style = 10
    chart.grouping = "clustered"
    chart.overlap = 0
    chart.title = "Desviaciones mensuales 2026"
    chart.y_axis.title = "Cantidad de desviaciones"
    chart.x_axis.title = "Tipo de desviación"
    chart.height = 9
    chart.width = 18

    data = Reference(
        ws,
        min_col=2,
        max_col=1 + len(meses),
        min_row=6,
        max_row=10,
    )
    cats = Reference(ws, min_col=1, min_row=7, max_row=10)
    chart.add_data(data, titles_from_data=True, from_rows=False)
    chart.set_categories(cats)

    verdes = [
        "375623", "548235", "70AD47", "A9D18E",
        "226B3A", "3F8C54", "65A765", "8FC17A",
        "2F6B3C", "4F8A4C", "73A95A", "A2C98B",
    ]
    for serie, color in zip(chart.series, verdes):
        try:
            serie.graphicalProperties.solidFill = color
            serie.graphicalProperties.line.solidFill = color
        except Exception:
            pass

    ws.add_chart(chart, "A13")


def _preparar_usuarios_2026(wb, top_usuarios):
    ws = wb["Usuarios con desviaciones 2026"]
    _limpiar_valores(ws, min_row=1, max_row=max(ws.max_row, 100), min_col=1, max_col=13)

    headers = ["Mes", "Usuario", "Nombre Usuario", "Desviaciones"]
    for c, h in enumerate(headers, 1):
        ws.cell(1, c, h)

    for r, item in enumerate(top_usuarios, start=2):
        ws.cell(r, 1, item["mes"])
        ws.cell(r, 2, item["usuario"])
        ws.cell(r, 3, item["nombre"])
        ws.cell(r, 4, item["desviaciones"])

    verde = PatternFill("solid", fgColor="548235")
    blanco = Font(color="FFFFFF", bold=True)
    for cell in ws[1][:4]:
        cell.fill = verde
        cell.font = blanco

    ws.auto_filter.ref = f"A1:D{max(2, len(top_usuarios) + 1)}"
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 36
    ws.column_dimensions["D"].width = 16


def generar_reporte_mensual_formateado(
    salida,
    final,
    nuevos,
    mapa,
    periodo,
):
    if not os.path.exists(PLANTILLA_REPORTE):
        raise FileNotFoundError(
            "No se encontró plantilla_reporte_mensual.xlsx junto al sistema."
        )

    wb = load_workbook(PLANTILLA_REPORTE)

    # Hojas que el usuario NO quiere en el archivo descargable.
    for nombre in ["Lista de usuarios", "Observaciones", "Catálogo"]:
        if nombre in wb.sheetnames:
            del wb[nombre]

    # No incluir las hojas antiguas del archivo integrado.
    for nombre in ["RESUMEN", "REVISION_FINAL"]:
        if nombre in wb.sheetnames:
            del wb[nombre]

    articulos = _preparar_articulos_reporte(final, nuevos, mapa)

    _preparar_hoja_articulos(wb, articulos)
    _preparar_analisis_desviaciones(wb, articulos, periodo)
    _preparar_distribucion(wb, articulos)
    _preparar_codigos_usuario(wb, articulos)

    datos_mensuales = _datos_mensuales_reporte(
        periodo,
        final,
        salida,
    )
    _preparar_tablas_mensuales(wb, datos_mensuales, periodo)
    _preparar_grafica_mensual(wb, datos_mensuales)

    top_usuarios = _top_usuarios_historicos(
        periodo,
        final,
        salida,
    )
    _preparar_usuarios_2026(wb, top_usuarios)

    # Orden exacto de hojas deseadas.
    orden = [
        "Artículos",
        "Análisis de desviaciones",
        "Distribución de desviaciones",
        "Códigos por usuario",
        "Tablas Desviaciones-Mensual",
        "Gráfica desviaciones-Mensual",
        "Usuarios con desviaciones 2026",
    ]
    wb._sheets = [wb[n] for n in orden if n in wb.sheetnames]

    wb.save(salida)
    wb.close()

    return salida




def asegurar_formato_reporte_descargable(ruta_revision):
    """
    Convierte automáticamente una revisión antigua
    (RESUMEN + REVISION_FINAL) al nuevo reporte mensual.

    Si el archivo ya contiene las siete hojas nuevas, no se modifica.
    """
    ruta_revision = Path(ruta_revision)

    if not ruta_revision.exists():
        raise FileNotFoundError(str(ruta_revision))

    hojas_deseadas = [
        "Artículos",
        "Análisis de desviaciones",
        "Distribución de desviaciones",
        "Códigos por usuario",
        "Tablas Desviaciones-Mensual",
        "Gráfica desviaciones-Mensual",
        "Usuarios con desviaciones 2026",
    ]

    wb_revision = load_workbook(
        ruta_revision,
        read_only=True,
        data_only=False,
    )
    try:
        hojas_actuales = list(wb_revision.sheetnames)
    finally:
        wb_revision.close()

    # Si ya existe Artículos, el archivo ya cuenta con la estructura base
    # necesaria. app.py reconstruirá las hojas de reporte con los mismos
    # datos que muestra la página web. Esto permite descargarlo varias veces.
    if "Artículos" in hojas_actuales:
        return str(ruta_revision)

    if "REVISION_FINAL" not in hojas_actuales:
        raise ValueError(
            "El archivo no contiene REVISION_FINAL ni el nuevo formato mensual."
        )

    final = pd.read_excel(
        ruta_revision,
        sheet_name="REVISION_FINAL",
        dtype=str,
        engine="openpyxl",
    )

    renombres = {}
    if "Observación" in final.columns and "Observaciones" not in final.columns:
        renombres["Observación"] = "Observaciones"
    if "Subobservación" in final.columns and "Subobservaciones" not in final.columns:
        renombres["Subobservación"] = "Subobservaciones"
    if renombres:
        final.rename(columns=renombres, inplace=True)

    periodo_nombre = normalizar_periodo(ruta_revision.stem)
    periodo = next(
        (mes for mes in MESES if mes in periodo_nombre),
        "",
    )
    if not periodo:
        raise ValueError(
            "No fue posible identificar el mes del archivo para convertirlo."
        )

    temporal = ruta_revision.with_name(
        ruta_revision.stem + "__FORMATO_NUEVO_TEMP.xlsx"
    )

    try:
        generar_reporte_mensual_formateado(
            salida=str(temporal),
            final=final,
            nuevos=pd.DataFrame(),
            mapa={},
            periodo=periodo,
        )

        wb_nuevo = load_workbook(
            temporal,
            read_only=True,
            data_only=False,
        )
        try:
            hojas_nuevas = list(wb_nuevo.sheetnames)
        finally:
            wb_nuevo.close()

        if hojas_nuevas != hojas_deseadas:
            raise ValueError(
                "La conversión no generó exactamente las hojas requeridas."
            )

        os.replace(temporal, ruta_revision)

    finally:
        if temporal.exists():
            try:
                temporal.unlink()
            except Exception:
                pass

    return str(ruta_revision)


def procesar_revision_web(ruta_entrada, periodo, anio, ruta_salida):
    """Procesa solo el archivo, mes y año recibidos explícitamente desde Flask."""
    if not os.path.exists(DB_PATH):
        raise FileNotFoundError("No se encontró base_datos.db junto al sistema.")
    entrada, hoja_entrada, df, mapa, periodo, nuevos_insertados = cargar_entrada(ruta_entrada, periodo, anio)
    c_estado = mapa["ESTADO"]
    nuevos = df[df[c_estado].fillna("").astype(str).str.strip().str.upper().eq("NUEVO")].copy()
    print(f"Archivo recibido desde la web: {os.path.basename(entrada)}")
    print(f"Periodo seleccionado: {periodo.title()} {int(anio)}")
    print(f"Registros leidos: {len(df)} | NUEVOS: {len(nuevos)}")
    print("[1/6] Ortografia...")
    t = time.perf_counter()
    diag_orto, hall_orto = ejecutar_ortografia(nuevos, mapa)
    print(f"      Tiempo Ortografia: {time.perf_counter() - t:.2f} s")
    print("[2/6] Redaccion...")
    t = time.perf_counter()
    diag_red, hall_red = ejecutar_redaccion(nuevos, mapa)
    print(f"      Tiempo Redaccion: {time.perf_counter() - t:.2f} s")
    print("[3/6] Plantillas...")
    t = time.perf_counter()
    diag_plant, hall_plant, rev_plant = ejecutar_plantillas(nuevos, mapa)
    print(f"      Tiempo Plantillas: {time.perf_counter() - t:.2f} s")
    print("[4/6] Duplicados...")
    t = time.perf_counter()
    diag_dup, hall_dup, total_nuevos_dup, total_pares = ejecutar_duplicados(df)
    print(f"      Tiempo Duplicados: {time.perf_counter() - t:.2f} s")
    print("[5/6] Clasificacion...")
    t = time.perf_counter()
    diag_clas, hall_clas, rev_clas = ejecutar_clasificacion(nuevos, mapa)
    print(f"      Tiempo Clasificacion: {time.perf_counter() - t:.2f} s")
    hallazgos = hall_orto + hall_red + hall_plant + hall_dup + hall_clas
    hallazgos = [h for h in hallazgos if str(h.get("Subobservacion", "")).strip().upper() != "SUB-ESPECIFICADO"]
    revisar = rev_plant + rev_clas
    print("[6/6] Revision historica...")
    final = consolidar_resultado(nuevos, mapa, [diag_orto, diag_red, diag_plant, diag_dup, diag_clas], hallazgos, revisar)
    os.makedirs(os.path.dirname(os.path.abspath(str(ruta_salida))), exist_ok=True)
    generar_reporte_mensual_formateado(salida=str(ruta_salida), final=final, nuevos=nuevos, mapa=mapa, periodo=periodo)
    print(f"Articulos NUEVO analizados: {len(final)}")
    print(f"Archivo generado: {ruta_salida}")
    return str(ruta_salida)


def main():
    raise RuntimeError("Este motor funciona desde la aplicación web. Usa Nueva revisión.")


if __name__ == "__main__":
    main()
